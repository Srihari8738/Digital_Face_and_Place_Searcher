// src/main.js
// Main application entry point: state subscription, router, and event attachment

import './style.css';
import { store } from './state.js';
import { renderIcon } from './utils/icons.js';

import { renderNavbar, attachNavbarEvents } from './components/navbar.js';
import { renderLandingPage, attachLandingEvents } from './components/landingPage.js';
import { renderLoadingScreen, initLoadingScreenTransition } from './components/loadingScreen.js';
import { renderSidebar, attachSidebarEvents } from './components/sidebar.js';
import { renderDashboardOverview, attachOverviewEvents } from './components/dashboardOverview.js';
import { renderUploadSection, attachUploadEvents } from './components/uploadSection.js';
import { renderSearchProcessing, attachSearchProcessingEvents } from './components/searchProcessing.js';
import { renderSearchResults, attachSearchResultsEvents } from './components/searchResults.js';
import { renderResultDetailsModal, attachResultDetailsEvents } from './components/resultDetailsModal.js';
import { renderSearchHistory, attachSearchHistoryEvents } from './components/searchHistory.js';
import { renderSavedResults, attachSavedResultsEvents } from './components/savedResults.js';
import { renderSettingsView, attachSettingsEvents } from './components/settingsView.js';
import { renderAuthModal, attachAuthEvents } from './components/authModal.js';
import { renderUpgradeModal, attachUpgradeEvents } from './components/upgradeModal.js';
import {
  renderComingSoonModal,
  renderReportModal,
  renderClearHistoryModal,
  renderAiConfigModal,
  attachModalEvents
} from './components/modals.js';

function renderApp() {
  const appContainer = document.getElementById('app');
  if (!appContainer) return;

  const { view, dashboardTab, currentSearch, activeModal, toast } = store.state;

  let contentHtml = '';

  if (view === 'landing') {
    contentHtml = `
      ${renderLoadingScreen()}
      ${renderNavbar()}
      ${renderLandingPage()}
    `;
  } else {
    // Dashboard Application Shell
    contentHtml = `
      <div class="app-shell">
        ${renderSidebar()}
        <div class="app-main">
          ${renderNavbar()}
          <main class="app-content">
            ${renderDashboardContent(dashboardTab, currentSearch)}
          </main>
        </div>
      </div>
    `;
  }

  // Modals Overlay Container
  const modalsHtml = renderModals(activeModal);

  // Toast Notification Container
  const toastHtml = toast
    ? `
    <div class="toast-container">
      <div class="toast-pill">
        <span style="color: ${toast.type === 'success' ? 'var(--accent-emerald)' : 'var(--primary)'};">
          ${renderIcon(toast.type === 'success' ? 'check-circle' : 'info', 'w-4 h-4', 18)}
        </span>
        <span>${toast.message}</span>
      </div>
    </div>
  `
    : '';

  appContainer.innerHTML = `
    ${contentHtml}
    ${modalsHtml}
    ${toastHtml}
  `;

  // Attach interactive event listeners
  attachAppEvents(view, dashboardTab, currentSearch, activeModal);
}

function renderDashboardContent(tab, currentSearch) {
  switch (tab) {
    case 'overview':
      return renderDashboardOverview();

    case 'search':
      if (currentSearch.status === 'processing') {
        return renderSearchProcessing();
      } else if (currentSearch.status === 'completed') {
        return renderSearchResults();
      }
      return renderUploadSection();

    case 'history':
      return renderSearchHistory();

    case 'saved':
      return renderSavedResults();

    case 'settings':
      return renderSettingsView();

    default:
      return renderDashboardOverview();
  }
}

function renderModals(activeModal) {
  if (!activeModal) return '';

  switch (activeModal) {
    case 'auth':
      return renderAuthModal();
    case 'upgrade':
      return renderUpgradeModal();
    case 'detail':
      return renderResultDetailsModal();
    case 'comingSoon':
      return renderComingSoonModal();
    case 'report':
      return renderReportModal();
    case 'clearHistory':
      return renderClearHistoryModal();
    case 'aiConfig':
      return renderAiConfigModal();
    default:
      return '';
  }
}

function attachAppEvents(view, tab, currentSearch, activeModal) {
  // Navigation
  attachNavbarEvents();

  if (view === 'landing') {
    attachLandingEvents();
  } else {
    attachSidebarEvents();

    switch (tab) {
      case 'overview':
        attachOverviewEvents();
        break;
      case 'search':
        if (currentSearch.status === 'processing') {
          attachSearchProcessingEvents();
        } else if (currentSearch.status === 'completed') {
          attachSearchResultsEvents();
        } else {
          attachUploadEvents();
        }
        break;
      case 'history':
        attachSearchHistoryEvents();
        break;
      case 'saved':
        attachSavedResultsEvents();
        break;
      case 'settings':
        attachSettingsEvents();
        break;
    }
  }

  // Modals
  if (activeModal === 'auth') attachAuthEvents();
  if (activeModal === 'upgrade') attachUpgradeEvents();
  if (activeModal === 'detail') attachResultDetailsEvents();
  if (activeModal === 'comingSoon' || activeModal === 'report' || activeModal === 'clearHistory') {
    attachModalEvents();
  }
}

// Subscribe to state changes
store.subscribe(() => {
  renderApp();
});

// Initial render
document.addEventListener('DOMContentLoaded', () => {
  renderApp();
  initLoadingScreenTransition();
});
