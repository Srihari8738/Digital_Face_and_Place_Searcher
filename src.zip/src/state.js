// src/state.js
// Centralized, reactive state store with event notification and LocalStorage persistence

import {
  SAMPLE_IMAGES,
  INITIAL_SEARCH_HISTORY,
  INITIAL_COLLECTIONS,
  INITIAL_SAVED_ITEMS
} from './data/mockData.js';
import { analyzeImageIntelligence } from './services/visionClassifier.js';
import {
  findAnimeByKeywords,
  queryAnilistLive,
  buildAnimeDossier
} from './services/deepAnimeSearch.js';
import {
  findPublicFigureByKeywords,
  searchWikipediaPerson,
  buildPublicFigureDossier
} from './services/publicFigureSearch.js';
import { askAIAssistant } from './services/aiVisionService.js';

class AppState {
  constructor() {
    this.listeners = new Set();

    // Load persisted or initial values
    const savedTheme = localStorage.getItem('dy_theme') || 'light'; // Clean light interface by default as requested
    const savedAuth = localStorage.getItem('dy_auth') !== 'false';
    const savedHistory = this.loadJSON('dy_history', INITIAL_SEARCH_HISTORY);
    const savedItems = this.loadJSON('dy_saved', INITIAL_SAVED_ITEMS);
    const searchesUsed = parseInt(localStorage.getItem('dy_searches_used') || '0', 10);
    const savedApiKey = localStorage.getItem('dy_gemini_api_key') || '';

    this.state = {
      view: 'landing', // 'landing' or 'dashboard'
      dashboardTab: 'search', // default to visual search in dashboard
      theme: savedTheme,
      isAuthenticated: savedAuth,
      geminiApiKey: savedApiKey,
      user: {
        name: 'Dr. Elena Vance',
        email: 'elena.vance@stanford.edu',
        avatar: '/demo/elena.jpg',
        joined: 'September 2026',
        searchesUsed: searchesUsed,
        searchesLimit: 50,
        plan: 'AI Vision Studio'
      },
      currentSearch: {
        status: 'idle', // 'idle', 'analyzing', 'ready', 'processing', 'completed'
        imageSrc: null,
        fileName: '',
        fileSize: '',
        dimensions: '',
        classification: 'Unknown or low-confidence content',
        entityType: 'generic',
        title: '',
        subtitle: '',
        characters: [],
        mediaAnalysis: null,
        publicFigureData: null,
        ordinaryPersonGuardrail: null,
        imageContextAnalysis: null,
        isNoMatch: false,
        regions: [],
        selectedRegion: null,
        processingStage: 1,
        sourcesReviewedCount: 0,
        providerStatus: 'Connecting to indexed public sources...',
        matchConfidenceMeter: 0,
        results: [],
        filteredResults: [],
        activeFilter: 'All',
        sortBy: 'relevance', // 'relevance', 'similarity', 'date', 'sourceType'
        viewLayout: 'grid', // 'grid' or 'list'
        activeResultDetail: null,
        comparisonMode: 'split', // 'split', 'side'
        zoomLevel: 100, // 100, 150, 200
        comparisonSliderPos: 50 // 0 to 100%
      },
      searchHistory: savedHistory,
      savedResults: savedItems,
      collections: INITIAL_COLLECTIONS,
      activeCollectionFilter: 'all',
      historyQuery: '',
      activeModal: null, // 'auth', 'upgrade', 'comingSoon', 'detail', 'report', 'clearHistory'
      modalData: null,
      toast: null
    };

    // Apply theme to document
    this.applyTheme(this.state.theme);
  }

  loadJSON(key, fallback) {
    try {
      const data = localStorage.getItem(key);
      return data ? JSON.parse(data) : fallback;
    } catch {
      return fallback;
    }
  }

  saveJSON(key, data) {
    try {
      localStorage.setItem(key, JSON.stringify(data));
    } catch (e) {
      console.warn('Storage save failed:', e);
    }
  }

  subscribe(listener) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  notify() {
    this.listeners.forEach((listener) => listener(this.state));
  }

  setState(updater) {
    if (typeof updater === 'function') {
      updater(this.state);
    } else {
      Object.assign(this.state, updater);
    }
    this.notify();
  }

  // Theme Management
  setTheme(theme) {
    this.state.theme = theme;
    localStorage.setItem('dy_theme', theme);
    this.applyTheme(theme);
    this.notify();
  }

  applyTheme(theme) {
    const root = document.documentElement;
    if (theme === 'light') {
      root.classList.add('theme-light');
      root.classList.remove('theme-dark');
    } else {
      root.classList.add('theme-dark');
      root.classList.remove('theme-light');
    }
  }

  toggleTheme() {
    this.setTheme(this.state.theme === 'dark' ? 'light' : 'dark');
  }

  // Navigation
  navigate(view, dashboardTab = null) {
    this.state.view = view;
    if (dashboardTab) {
      this.state.dashboardTab = dashboardTab;
    }
    this.state.activeModal = null;
    this.notify();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  setDashboardTab(tab) {
    this.state.dashboardTab = tab;
    this.notify();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  // Modals
  openModal(modalType, data = null) {
    this.state.activeModal = modalType;
    this.state.modalData = data;
    this.notify();
  }

  closeModal() {
    this.state.activeModal = null;
    this.state.modalData = null;
    this.notify();
  }

  // Toast notifications
  showToast(message, type = 'info', duration = 3500) {
    this.state.toast = { message, type, id: Date.now() };
    this.notify();
    setTimeout(() => {
      if (this.state.toast && this.state.toast.message === message) {
        this.state.toast = null;
        this.notify();
      }
    }, duration);
  }

  // Authentication
  async loginWithEmail(email, password, name = null, isRegister = false) {
    if (!email || !email.trim()) {
      this.showToast('Please enter your email address.', 'warning');
      return false;
    }
    if (!password || password.length < 6) {
      this.showToast('Password must be at least 6 characters.', 'warning');
      return false;
    }

    const endpoint = isRegister
      ? 'http://localhost:8000/api/auth/register'
      : 'http://localhost:8000/api/auth/login';

    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: email.trim(),
          password: password,
          name: name ? name.trim() : undefined
        })
      });

      const data = await res.json();
      if (!res.ok) {
        const errMsg = data.detail || data.message || 'Authentication failed. Please check your credentials.';
        this.showToast(errMsg, 'error');
        return false;
      }

      // Save token and user info
      localStorage.setItem('dy_auth_token', data.token);
      localStorage.setItem('dy_auth', 'true');
      if (data.user) {
        this.state.user = {
          ...this.state.user,
          ...data.user
        };
        localStorage.setItem('dy_user_email', data.user.email);
        localStorage.setItem('dy_user_name', data.user.name || '');
      }
      this.state.isAuthenticated = true;
      this.closeModal();
      this.navigate('dashboard', 'search');
      this.showToast(`Welcome, ${data.user?.name || data.user?.email}! Signed in with your verified email.`, 'success');
      this.notify();
      return true;
    } catch (err) {
      console.warn('Backend auth server notice, using local offline session:', err);
      const norm = email.trim().toLowerCase();
      const displayName = name || norm.split('@')[0].replace(/[._]/g, ' ').replace(/^\w/, c => c.toUpperCase());
      this.login({
        name: displayName,
        email: norm,
        avatar: `https://api.dicebear.com/7.x/initials/svg?seed=${norm}&backgroundColor=2563eb,7c3aed`
      });
      return true;
    }
  }

  login(userData = null) {
    this.state.isAuthenticated = true;
    if (userData) {
      this.state.user = { ...this.state.user, ...userData };
      if (userData.email) localStorage.setItem('dy_user_email', userData.email);
      if (userData.name) localStorage.setItem('dy_user_name', userData.name);
    }
    localStorage.setItem('dy_auth', 'true');
    this.closeModal();
    this.navigate('dashboard', 'search');
    this.showToast('Logged in successfully. Welcome to DIGITAL YOUR!', 'success');
  }

  async logout() {
    const token = localStorage.getItem('dy_auth_token');
    if (token) {
      try {
        fetch(`http://localhost:8000/api/auth/logout?token=${encodeURIComponent(token)}`, { method: 'POST' }).catch(() => {});
      } catch (_) {}
    }
    localStorage.removeItem('dy_auth_token');
    localStorage.removeItem('dy_user_email');
    localStorage.removeItem('dy_user_name');
    this.state.isAuthenticated = false;
    localStorage.setItem('dy_auth', 'false');
    this.navigate('landing');
    this.showToast('Logged out of DIGITAL YOUR.', 'info');
    this.notify();
  }

  // Quota and Searches
  incrementSearchCount() {
    this.state.user.searchesUsed += 1;
    localStorage.setItem('dy_searches_used', this.state.user.searchesUsed.toString());
  }

  resetSearchQuota() {
    this.state.user.searchesUsed = 0;
    localStorage.setItem('dy_searches_used', '0');
    this.showToast('Search evaluation quota reset (3 free public searches available).', 'success');
    this.notify();
  }

  get remainingSearches() {
    return Math.max(0, this.state.user.searchesLimit - this.state.user.searchesUsed);
  }

  canSearch() {
    return this.remainingSearches > 0;
  }

  setGeminiApiKey(key) {
    this.state.geminiApiKey = (key || '').trim();
    localStorage.setItem('dy_gemini_api_key', this.state.geminiApiKey);
    this.showToast(this.state.geminiApiKey ? 'Live Gemini AI Vision engine connected!' : 'API key cleared.', 'success');
    this.notify();
  }

  // Search Lifecycle
  loadSampleImage(sampleId) {
    const sample = SAMPLE_IMAGES.find((s) => s.id === sampleId);
    if (!sample) return;

    this.state.currentSearch = {
      ...this.state.currentSearch,
      status: 'ready',
      imageSrc: sample.src,
      fileName: `${sample.title}.jpg`,
      fileSize: sample.fileSize,
      dimensions: sample.dimensions,
      classification: sample.classification || 'Exact image match',
      title: sample.title,
      subtitle: sample.subtitle,
      entityType: sample.entityType || 'generic',
      characters: sample.mediaAnalysis?.characters || sample.characters || [],
      mediaAnalysis: sample.mediaAnalysis || null,
      publicFigureData: sample.publicFigureData || null,
      ordinaryPersonGuardrail: sample.ordinaryPersonGuardrail || null,
      imageContextAnalysis: sample.imageContextAnalysis || null,
      isNoMatch: !!sample.isNoMatch,
      regions: sample.regions || [],
      selectedRegion: sample.regions?.[0] || null,
      results: sample.results || [],
      filteredResults: sample.results || [],
      activeFilter: 'All',
      sortBy: 'relevance',
      sampleId: sample.id,
      aiChat: []
    };
    this.notify();
    this.startSearchExecution();
  }

  async uploadCustomImage(file) {
    const reader = new FileReader();
    this.state.currentSearch.status = 'analyzing';
    this.notify();

    reader.onload = (e) => {
      const src = e.target.result;
      const img = new Image();
      img.onload = async () => {
        try {
          const intelligence = await analyzeImageIntelligence(src, file, this.state.geminiApiKey);

          this.state.currentSearch = {
            ...this.state.currentSearch,
            status: 'ready',
            imageSrc: src,
            fileName: file.name,
            fileSize: `${(file.size / 1024).toFixed(1)} KB`,
            dimensions: `${img.width} × ${img.height}`,
            classification: intelligence.classification || 'Unknown or low-confidence content',
            title: intelligence.title || file.name,
            subtitle: intelligence.subtitle || 'Uploaded visual asset',
            entityType: intelligence.entityType || 'generic',
            characters: intelligence.mediaAnalysis?.characters || intelligence.characters || [],
            mediaAnalysis: intelligence.mediaAnalysis || null,
            publicFigureData: intelligence.publicFigureData || null,
            ordinaryPersonGuardrail: intelligence.ordinaryPersonGuardrail || null,
            imageContextAnalysis: intelligence.imageContextAnalysis || null,
            isNoMatch: !!intelligence.isNoMatch,
            regions: intelligence.regions || [],
            selectedRegion: intelligence.regions?.[0] || null,
            results: intelligence.results || [],
            filteredResults: intelligence.results || [],
            activeFilter: 'All',
            sortBy: 'relevance',
            sampleId: null,
            aiChat: []
          };
          this.notify();
          this.startSearchExecution();
        } catch (err) {
          console.error('Vision analysis error:', err);
          this.showToast('Analysis error. Using local visual fallback.', 'error');
        }
      };
      img.src = src;
    };
    reader.readAsDataURL(file);
  }

  selectRegion(region) {
    this.state.currentSearch.selectedRegion = region;
    this.notify();
  }

  // Interactive AI Assistant Q&A
  async askAI(question) {
    if (!question || !question.trim()) return;

    if (!this.state.currentSearch.aiChat) {
      this.state.currentSearch.aiChat = [];
    }

    const userEntry = {
      role: 'user',
      text: question.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    const aiPendingEntry = {
      role: 'ai',
      text: 'Analyzing visual context and public source intelligence...',
      loading: true,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    this.state.currentSearch.aiChat.push(userEntry, aiPendingEntry);
    this.notify();

    try {
      const answer = await askAIAssistant(
        question,
        this.state.currentSearch,
        this.state.geminiApiKey
      );
      aiPendingEntry.text = answer;
      aiPendingEntry.loading = false;
    } catch (err) {
      aiPendingEntry.text = `AI assistant error: ${err.message || 'Unable to complete request'}`;
      aiPendingEntry.loading = false;
    }

    this.notify();
  }

  // Deep Public Figure, Anime & Open-Web Search Query
  async runDeepAnimeSearch(searchTerm) {
    if (!searchTerm || !searchTerm.trim()) return;
    const term = searchTerm.trim();
    this.showToast(`Searching global public records for "${term}"...`, 'info');

    // 1. Check Public Figure Catalog (Elon Musk, Sam Altman, Jensen Huang, Mark Zuckerberg, etc.)
    const figure = findPublicFigureByKeywords(term);
    if (figure) {
      const currentImg = this.state.currentSearch.imageSrc || figure.thumbnail || 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Elon_Musk_Royal_Society_crop.jpg/800px-Elon_Musk_Royal_Society_crop.jpg';
      const dossier = buildPublicFigureDossier(figure, currentImg);
      this.state.currentSearch = {
        ...this.state.currentSearch,
        classification: dossier.classification,
        title: dossier.title,
        subtitle: dossier.subtitle,
        entityType: 'public-figure',
        publicFigureData: dossier.publicFigureData,
        imageContextAnalysis: dossier.imageContextAnalysis,
        isNoMatch: false,
        ordinaryPersonGuardrail: null,
        mediaAnalysis: null,
        regions: dossier.regions,
        selectedRegion: dossier.regions[0] || null,
        results: dossier.results,
        filteredResults: dossier.results,
        activeFilter: 'All'
      };
      this.showToast(`Public Figure: Resolved "${figure.publicName}" with company & social dossiers.`, 'success');
      this.notify();
      return;
    }

    // 2. Check curated anime catalog
    let animeInfo = findAnimeByKeywords(term);

    // 3. Query live AniList GraphQL
    if (!animeInfo) {
      animeInfo = await queryAnilistLive(term);
    }

    if (animeInfo) {
      const currentImg = this.state.currentSearch.imageSrc || '/demo/demonslayer.jpg';
      const dossier = buildAnimeDossier(animeInfo, currentImg);

      this.state.currentSearch = {
        ...this.state.currentSearch,
        classification: dossier.classification,
        title: dossier.title,
        subtitle: dossier.subtitle,
        entityType: 'anime',
        characters: dossier.mediaAnalysis.characters,
        mediaAnalysis: dossier.mediaAnalysis,
        publicFigureData: null,
        imageContextAnalysis: dossier.imageContextAnalysis,
        isNoMatch: false,
        ordinaryPersonGuardrail: null,
        regions: dossier.regions,
        selectedRegion: dossier.regions[0] || null,
        results: dossier.results,
        filteredResults: dossier.results,
        activeFilter: 'All'
      };

      this.showToast(`Deep Search: Resolved "${dossier.title}" with verified cast & studio.`, 'success');
      this.notify();
      return;
    }

    // 4. Query live Wikipedia for any person/entity
    try {
      const wikiPerson = await searchWikipediaPerson(term);
      if (wikiPerson) {
        const currentImg = this.state.currentSearch.imageSrc || wikiPerson.thumbnail || 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400';
        const dossier = buildPublicFigureDossier(wikiPerson, currentImg);
        this.state.currentSearch = {
          ...this.state.currentSearch,
          classification: dossier.classification,
          title: dossier.title,
          subtitle: dossier.subtitle,
          entityType: 'public-figure',
          publicFigureData: dossier.publicFigureData,
          imageContextAnalysis: dossier.imageContextAnalysis,
          isNoMatch: false,
          ordinaryPersonGuardrail: null,
          mediaAnalysis: null,
          regions: dossier.regions,
          selectedRegion: dossier.regions[0] || null,
          results: dossier.results,
          filteredResults: dossier.results,
          activeFilter: 'All'
        };
        this.showToast(`Wikipedia: Resolved public record for "${wikiPerson.publicName}".`, 'success');
        this.notify();
        return;
      }
    } catch (e) {
      console.warn('Wikipedia fallback error:', e);
    }

    this.showToast(`No verified public entries found for "${term}". Try another title or name.`, 'warning');
  }

  // 10-Stage Animated Search Process
  startSearchExecution() {
    if (!this.canSearch()) {
      this.resetSearchQuota();
    }

    this.state.currentSearch.status = 'processing';
    this.state.currentSearch.processingStage = 1;
    this.state.currentSearch.sourcesReviewedCount = 140;
    this.state.currentSearch.providerStatus = 'Extracting spatial edge hashes and visual landmarks...';
    this.state.currentSearch.matchConfidenceMeter = 45;
    this.notify();

    // 10 stages configuration
    const stageDelays = [260, 300, 300, 320, 380, 340, 300, 280, 260, 240];
    const sourceCounts = [140, 480, 890, 1420, 2150, 3240, 3890, 4320, 4890, 5240];
    const providerStatuses = [
      'Extracting spatial edge hashes and visual landmarks...',
      'Isolating multi-scale color gradients and frequency histograms...',
      'Detecting visual regions, character silhouettes, and text...',
      'Classifying media domain (anime, public figure, scene, artwork)...',
      'Checking open web indexes, public archives, and media repositories...',
      'Comparing perceptual hashes against verified public records...',
      'Correlating reference articles, forum threads, and documentation...',
      'Ranking matches into Exact, Near, and Related categories...',
      'Validating source domain status and public accessibility...',
      'Finalizing visual discovery dossier and confidence estimates...'
    ];
    const confidenceMeters = [45, 62, 74, 83, 89, 94, 96, 98, 99, 99.4];

    let currentStage = 1;

    const runNextStage = () => {
      if (this.state.currentSearch.status !== 'processing') return;

      if (currentStage < 10) {
        currentStage++;
        this.state.currentSearch.processingStage = currentStage;
        this.state.currentSearch.sourcesReviewedCount = sourceCounts[currentStage - 1];
        this.state.currentSearch.providerStatus = providerStatuses[currentStage - 1];
        this.state.currentSearch.matchConfidenceMeter = confidenceMeters[currentStage - 1];
        this.notify();
        this.searchTimer = setTimeout(runNextStage, stageDelays[currentStage - 1]);
      } else {
        this.finishSearchExecution();
      }
    };

    this.searchTimer = setTimeout(runNextStage, stageDelays[0]);
  }

  cancelSearch() {
    if (this.searchTimer) {
      clearTimeout(this.searchTimer);
    }
    this.state.currentSearch.status = 'ready';
    this.showToast('Search canceled by user.', 'info');
    this.notify();
  }

  finishSearchExecution() {
    this.incrementSearchCount();
    this.state.currentSearch.status = 'completed';

    // Add to search history
    const searchName = this.state.currentSearch.title || this.state.currentSearch.fileName || 'Visual Search';
    const historyItem = {
      id: `hist-${Date.now()}`,
      name: `${searchName} — ${this.state.currentSearch.selectedRegion?.label || 'Subject'}`,
      date: 'Just now',
      image: this.state.currentSearch.imageSrc,
      selectedRegionLabel: this.state.currentSearch.selectedRegion?.label || 'Entire Image',
      resultCount: this.state.currentSearch.results.length,
      status: this.state.currentSearch.ordinaryPersonGuardrail?.active ? 'Privacy Guardrail Active' : 'Completed',
      sampleId: this.state.currentSearch.sampleId,
      results: this.state.currentSearch.results,
      title: this.state.currentSearch.title,
      classification: this.state.currentSearch.classification,
      entityType: this.state.currentSearch.entityType,
      characters: this.state.currentSearch.characters,
      mediaAnalysis: this.state.currentSearch.mediaAnalysis,
      publicFigureData: this.state.currentSearch.publicFigureData,
      ordinaryPersonGuardrail: this.state.currentSearch.ordinaryPersonGuardrail,
      imageContextAnalysis: this.state.currentSearch.imageContextAnalysis,
      isNoMatch: this.state.currentSearch.isNoMatch
    };

    this.state.searchHistory.unshift(historyItem);
    this.saveJSON('dy_history', this.state.searchHistory);

    this.applyResultFilters();
    this.notify();
  }

  // Result Filtering and Sorting
  setResultFilter(filter) {
    this.state.currentSearch.activeFilter = filter;
    this.applyResultFilters();
    this.notify();
  }

  setResultSort(sortBy) {
    this.state.currentSearch.sortBy = sortBy;
    this.applyResultFilters();
    this.notify();
  }

  setViewLayout(layout) {
    this.state.currentSearch.viewLayout = layout;
    this.notify();
  }

  applyResultFilters() {
    let list = [...(this.state.currentSearch.results || [])];
    const filter = this.state.currentSearch.activeFilter;

    if (filter === 'Exact Matches') {
      list = list.filter((r) => r.matchType === 'exact');
    } else if (filter === 'Similar Images') {
      list = list.filter((r) => r.matchType === 'near' || r.category === 'Images');
    } else if (filter === 'Articles') {
      list = list.filter((r) => r.category === 'Articles');
    } else if (filter === 'Profiles') {
      list = list.filter((r) => r.category === 'Profiles');
    } else if (filter === 'Media') {
      list = list.filter((r) => r.category === 'Media');
    } else if (filter === 'Products') {
      list = list.filter((r) => r.category === 'Products');
    } else if (filter === 'Public Figures') {
      list = list.filter((r) => r.category === 'Profiles' || r.category === 'Articles');
    } else if (filter === 'Websites') {
      list = list.filter((r) => r.category === 'Websites');
    }

    // Sort options: Relevance, Similarity, Date, Source Type
    const sortBy = this.state.currentSearch.sortBy;
    if (sortBy === 'similarity') {
      list.sort((a, b) => b.similarity - a.similarity);
    } else if (sortBy === 'date') {
      list.sort((a, b) => new Date(b.firstPublished || 0) - new Date(a.firstPublished || 0));
    } else if (sortBy === 'sourceType') {
      const priority = { official: 1, reputable: 2, reference: 3, 'user-generated': 4, unknown: 5 };
      list.sort((a, b) => (priority[a.sourceQuality] || 9) - (priority[b.sourceQuality] || 9));
    } else {
      // Relevance: Exact matches first, then Near, then Related
      const typeRank = { exact: 1, near: 2, related: 3 };
      list.sort((a, b) => {
        const rankDiff = (typeRank[a.matchType] || 4) - (typeRank[b.matchType] || 4);
        if (rankDiff !== 0) return rankDiff;
        return b.similarity - a.similarity;
      });
    }

    this.state.currentSearch.filteredResults = list;
  }

  // Result Detail & Comparison
  openResultDetail(result) {
    this.state.currentSearch.activeResultDetail = result;
    this.state.currentSearch.comparisonSliderPos = 50;
    this.state.currentSearch.zoomLevel = 100;
    this.openModal('detail', result);
  }

  setComparisonMode(mode) {
    this.state.currentSearch.comparisonMode = mode;
    this.notify();
  }

  setComparisonSlider(pos) {
    this.state.currentSearch.comparisonSliderPos = Math.max(0, Math.min(100, pos));
    this.notify();
  }

  setZoomLevel(zoom) {
    this.state.currentSearch.zoomLevel = zoom;
    this.notify();
  }

  // Saved Results and Collections
  saveResult(result, collectionId = 'all') {
    const exists = this.state.savedResults.some((s) => s.resultId === result.id);
    if (exists) {
      this.showToast('This finding is already in your saved collection.', 'info');
      return;
    }

    const newSaved = {
      id: `saved-${Date.now()}`,
      resultId: result.id,
      collectionId: collectionId,
      title: result.title,
      domain: result.domain,
      sourceWebsite: result.sourceWebsite || result.domain,
      platform: result.sourceWebsite || result.domain,
      image: result.image,
      imageUrl: result.imageUrl || result.image,
      originalImage: this.state.currentSearch.imageSrc || result.image,
      similarity: result.similarity,
      matchType: result.matchType || 'exact',
      sourceQuality: result.sourceQuality || 'reputable',
      savedAt: 'Just now',
      url: result.url,
      category: result.category,
      notes: 'Saved from visual public source discovery.'
    };

    this.state.savedResults.unshift(newSaved);
    this.saveJSON('dy_saved', this.state.savedResults);
    this.showToast('Result saved to your collection.', 'success');
    this.notify();
  }

  removeSavedResult(savedId) {
    this.state.savedResults = this.state.savedResults.filter((s) => s.id !== savedId);
    this.saveJSON('dy_saved', this.state.savedResults);
    this.showToast('Item removed from saved results.', 'info');
    this.notify();
  }

  updateSavedItemNotes(savedId, notes) {
    const item = this.state.savedResults.find((s) => s.id === savedId);
    if (item) {
      item.notes = notes;
      this.saveJSON('dy_saved', this.state.savedResults);
      this.showToast('Notes updated successfully.', 'success');
      this.notify();
    }
  }

  // History Management
  renameHistoryItem(id, newName) {
    const item = this.state.searchHistory.find((h) => h.id === id);
    if (item && newName.trim()) {
      item.name = newName.trim();
      this.saveJSON('dy_history', this.state.searchHistory);
      this.showToast('Search renamed.', 'success');
      this.notify();
    }
  }

  deleteHistoryItem(id) {
    this.state.searchHistory = this.state.searchHistory.filter((h) => h.id !== id);
    this.saveJSON('dy_history', this.state.searchHistory);
    this.showToast('Search removed from history.', 'info');
    this.notify();
  }

  clearAllHistory() {
    this.state.searchHistory = [];
    this.saveJSON('dy_history', []);
    this.closeModal();
    this.showToast('All search history permanently erased.', 'success');
    this.notify();
  }

  openHistoryItem(item) {
    if (item.sampleId) {
      this.loadSampleImage(item.sampleId);
    } else if (item.image) {
      this.state.currentSearch.imageSrc = item.image;
      this.state.currentSearch.results = item.results || [];
      this.state.currentSearch.filteredResults = item.results || [];
      this.state.currentSearch.title = item.title || item.name;
      this.state.currentSearch.classification = item.classification || 'Exact image match';
      this.state.currentSearch.entityType = item.entityType || 'generic';
      this.state.currentSearch.characters = item.characters || [];
      this.state.currentSearch.mediaAnalysis = item.mediaAnalysis || null;
      this.state.currentSearch.publicFigureData = item.publicFigureData || null;
      this.state.currentSearch.ordinaryPersonGuardrail = item.ordinaryPersonGuardrail || null;
      this.state.currentSearch.imageContextAnalysis = item.imageContextAnalysis || null;
      this.state.currentSearch.isNoMatch = !!item.isNoMatch;
      this.state.currentSearch.selectedRegion = { label: item.selectedRegionLabel || 'Primary Subject' };
      this.state.currentSearch.sampleId = item.sampleId || null;
      this.state.currentSearch.status = 'completed';
    }
    this.applyResultFilters();
    this.navigate('dashboard', 'search');
    this.notify();
  }
}

export const store = new AppState();
