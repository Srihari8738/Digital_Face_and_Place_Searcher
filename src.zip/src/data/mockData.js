// src/data/mockData.js
// Comprehensive curated demo scenarios, bounding boxes, match categorization, and 10-stage search pipeline for DIGITAL YOUR

export const SEARCH_STAGES = [
  { stage: 1, title: 'Uploading image', desc: 'Secure ephemeral memory ingestion. Zero persistent storage.', icon: 'upload' },
  { stage: 2, title: 'Extracting visual features', desc: 'Extracting neural edge descriptors, keypoints, and spatial color histograms.', icon: 'cpu' },
  { stage: 3, title: 'Detecting regions and text', desc: 'Isolating visual regions, facial features, character silhouettes, and typography.', icon: 'scan' },
  { stage: 4, title: 'Classifying image content', desc: 'Categorizing media format (anime, public figure, scene, artwork, or generic).', icon: 'layers' },
  { stage: 5, title: 'Checking indexed public sources', desc: 'Querying publicly accessible domains, legal web archives, and media databases.', icon: 'globe' },
  { stage: 6, title: 'Comparing image fingerprints', desc: 'Computing perceptual hash distances, multi-scale cosine, and structural similarity.', icon: 'git-compare' },
  { stage: 7, title: 'Reviewing related pages', desc: 'Correlating public reference articles, forums, and editorial mentions.', icon: 'file-text' },
  { stage: 8, title: 'Ranking matches', desc: 'Sorting matches into Exact Matches, Near Matches, and Related Pages.', icon: 'sliders' },
  { stage: 9, title: 'Preparing source links', desc: 'Validating open web citations, platform protocols, and source quality indicators.', icon: 'external-link' },
  { stage: 10, title: 'Search complete', desc: 'Preparing public discovery report with algorithmic confidence estimates.', icon: 'check-circle' }
];

export const SAMPLE_IMAGES = [
  {
    id: 'sample-demonslayer',
    title: 'Demon Slayer: Kimetsu no Yaiba',
    subtitle: 'Anime Key Visual · Tanjiro & Nezuko Kamado',
    category: 'anime',
    src: '/demo/demonslayer.jpg',
    fileSize: '812 KB',
    dimensions: '1024 × 1536',
    format: 'JPEG',
    entityType: 'anime',
    classification: 'Anime or animation',
    
    // Media and Character Recognition Panel Data
    mediaAnalysis: {
      title: 'Demon Slayer: Kimetsu no Yaiba (竈門炭治郎 立志編)',
      franchise: 'Kimetsu no Yaiba / Weekly Shonen Jump',
      characters: [
        { name: 'Tanjiro Kamado', role: 'Main Protagonist · Water & Sun Breathing Swordsman' },
        { name: 'Nezuko Kamado', role: 'Demon Sister · Exploding Blood Demon Art' },
        { name: 'Kyojuro Rengoku', role: 'Flame Hashira · Demon Slayer Corps Pillar' },
        { name: 'Zenitsu Agatsuma', role: 'Thunder Breathing Companion' }
      ],
      studio: 'ufotable (Japan)',
      releasePeriod: '2019 – Present (Ongoing International Broadcast)',
      episodeContext: 'Promotional key art visual for the Tanjiro Kamado Unwavering Resolve Arc',
      genre: 'Dark Fantasy, Historical Fiction, Shonen Action, Supernatural',
      officialPages: [
        { name: 'Official Anime Portal (Japan)', url: 'https://kimetsu.com/anime/' },
        { name: 'Aniplex USA Official Page', url: 'https://demonslayer-anime.com/' }
      ],
      publicReferenceLinks: [
        { name: 'MyAnimeList #38000', url: 'https://myanimelist.net/anime/38000/Kimetsu_no_Yaiba' },
        { name: 'Crunchyroll Streaming Hub', url: 'https://crunchyroll.com/series/GY5P48XEY/demon-slayer-kimetsu-no-yaiba' },
        { name: 'Reddit r/KimetsuNoYaiba Community', url: 'https://reddit.com/r/KimetsuNoYaiba' },
        { name: 'Twitter/X @DemonSlayerUSA', url: 'https://x.com/DemonSlayerUSA' }
      ],
      relatedCharacters: ['Giyu Tomioka', 'Inosuke Hashibira', 'Muzan Kibutsuji'],
      searchTermsUsed: ['Demon Slayer', 'Kimetsu no Yaiba', 'Tanjiro Kamado', 'ufotable key visual'],
      confidenceLevel: 'High confidence (99.4% perceptual match)',
      confidenceNote: 'Identified based on visual and public-source evidence.'
    },

    // Image Context Analysis
    imageContextAnalysis: {
      imageType: 'Digital Key Visual Illustration / Promotional Poster',
      sceneDescription: 'High-contrast promotional composition depicting swordsman Tanjiro Kamado wielding a Nichirin blade with dynamic water breathing currents, alongside demon sister Nezuko Kamado in pink hemp kimono.',
      visibleObjects: ['Nichirin Katana', 'Water splash wave particles', 'Bamboo muzzle', 'Checkered green/black haori garment'],
      visibleText: 'Official 鬼滅の刃 (Kimetsu no Yaiba) Japanese Kanji typography crest',
      logosAndBrands: ['ufotable Studio Crest', 'Aniplex / Shueisha Official Copyright Stamp'],
      colorPalette: [
        { name: 'Deep Cyan', hex: '#0e7490' },
        { name: 'Sakura Pink', hex: '#f472b6' },
        { name: 'Checkered Forest', hex: '#15803d' },
        { name: 'Midnight Charcoal', hex: '#090d16' },
        { name: 'Ember Crimson', hex: '#e11d48' }
      ],
      approximateSetting: 'Stylized Taisho Era (Japan) mountain backdrop with swirling elemental water and flame visual effects',
      orientation: 'Portrait (Aspect Ratio 2:3, 1024 × 1536 px)',
      possibleSourceContext: 'Theatrical distribution key visual and official media press release banner',
      editingIndicators: 'High-fidelity original digital master; no compression artifacts or cropping detected',
      searchConfidence: '99.4% (Direct match across authoritative public anime indexes)',
      suggestedSearches: ['ufotable high-res key art', 'Kimetsu no Yaiba season broadcast visual', 'Tanjiro water breathing wallpaper']
    },

    regions: [
      {
        id: 'region-tanjiro',
        label: 'Character 1: Tanjiro Kamado',
        type: 'character',
        confidence: 99.4,
        box: { top: 38, left: 32, width: 22, height: 22 },
        description: 'Tanjiro Kamado executing Water Breathing Tenth Form'
      },
      {
        id: 'region-nezuko',
        label: 'Character 2: Nezuko Kamado',
        type: 'character',
        confidence: 98.8,
        box: { top: 31, left: 68, width: 20, height: 20 },
        description: 'Nezuko Kamado with bamboo muzzle and awakened eyes'
      },
      {
        id: 'region-ds-logo',
        label: 'Logo / Typography Region',
        type: 'logo',
        confidence: 99.7,
        box: { top: 4, left: 33, width: 34, height: 18 },
        description: 'Official Kimetsu no Yaiba Japanese Kanji logo typography'
      },
      {
        id: 'region-ds-full',
        label: 'Entire Image Composition',
        type: 'full',
        confidence: 100,
        box: { top: 0, left: 0, width: 100, height: 100 },
        description: 'Complete promotional visual key art'
      }
    ],

    // Categorized matches
    results: [
      // Exact Matches
      {
        id: 'res-ds-exact-1',
        matchType: 'exact',
        matchLabel: 'Exact Image Match (100% Match)',
        matchConfidence: 100,
        similarity: 100,
        similarityTier: 'High Similarity',
        title: 'Demon Slayer: Kimetsu no Yaiba — Official Key Visual Asset #KV-01',
        domain: 'kimetsu.com',
        sourceWebsite: 'Official Kimetsu Portal (Aniplex Japan)',
        url: 'https://kimetsu.com/anime/risshihen/visual/',
        image: '/demo/demonslayer.jpg',
        imageUrl: 'https://kimetsu.com/anime/assets/img/risshihen/kv01_master.jpg',
        category: 'Media',
        sourceQuality: 'official',
        sourceQualityLabel: 'Official source',
        firstPublished: 'Apr 06, 2019',
        lastSeen: 'Indexed 2 days ago',
        earliestDiscovered: true,
        context: 'Image hash and visual comparison indicate a strong match with the primary broadcast key art published on the official production production site.',
        protocol: 'HTTPS / Public Official Web Asset',
        verifiedPublic: true,
        tags: ['Exact Match', 'Official Asset', 'ufotable', 'Aniplex']
      },
      {
        id: 'res-ds-exact-2',
        matchType: 'exact',
        matchLabel: 'Exact Image Match (100% Match)',
        matchConfidence: 100,
        similarity: 100,
        similarityTier: 'High Similarity',
        title: 'Watch Demon Slayer: Kimetsu no Yaiba on Crunchyroll (Series Page)',
        domain: 'crunchyroll.com',
        sourceWebsite: 'Crunchyroll Global Streaming',
        url: 'https://crunchyroll.com/series/GY5P48XEY/demon-slayer-kimetsu-no-yaiba',
        image: '/demo/demonslayer.jpg',
        imageUrl: 'https://static.crunchyroll.com/assets/poster/demonslayer_full.jpg',
        category: 'Media',
        sourceQuality: 'reputable',
        sourceQualityLabel: 'Reputable publication',
        firstPublished: 'Apr 12, 2019',
        lastSeen: 'Indexed yesterday',
        context: 'Licensed series banner matching exact visual dimensions and color profile on Crunchyroll public catalog.',
        protocol: 'HTTPS / Streaming Catalog',
        verifiedPublic: true,
        tags: ['Exact Match', 'Streaming', 'Crunchyroll']
      },

      // Near Matches
      {
        id: 'res-ds-near-1',
        matchType: 'near',
        matchLabel: 'Cropped wallpaper version',
        matchConfidence: 92.4,
        similarity: 92,
        similarityTier: 'High Similarity',
        differences: 'Cropped 20% on top and bottom; slight saturation boost for desktop wallpaper distribution',
        matchingRegions: 'Character facial features, haori pattern, and water crest',
        title: 'Tanjiro & Nezuko Water Breathing HD Desktop Wallpaper (1920x1080)',
        domain: 'zerochan.net',
        sourceWebsite: 'Zerochan Anime Gallery',
        url: 'https://zerochan.net/2589012',
        image: '/demo/demonslayer.jpg',
        imageUrl: 'https://static.zerochan.net/full/42/18/2589012.jpg',
        category: 'Images',
        sourceQuality: 'user-generated',
        sourceQualityLabel: 'User-generated page',
        firstPublished: 'May 14, 2019',
        lastSeen: 'Indexed 1 week ago',
        context: 'Resized horizontal crop of the key visual adjusted for standard 16:9 desktop monitors.',
        protocol: 'HTTPS / Public Gallery',
        verifiedPublic: true,
        tags: ['Near Match', 'Wallpaper', 'Cropped']
      },
      {
        id: 'res-ds-near-2',
        matchType: 'near',
        matchLabel: 'Edited social banner with text overlay',
        matchConfidence: 87.8,
        similarity: 88,
        similarityTier: 'High Similarity',
        differences: 'Broadcast schedule overlay added across bottom quadrant; slight color grading adjustment',
        matchingRegions: 'Tanjiro Nichirin sword pose and Nezuko facial region',
        title: 'Demon Slayer Official X/Twitter Broadcast Announcement Banner',
        domain: 'x.com',
        sourceWebsite: 'Twitter / X (@DemonSlayerUSA)',
        url: 'https://x.com/DemonSlayerUSA/status/178492019482',
        image: '/demo/demonslayer.jpg',
        imageUrl: 'https://pbs.twimg.com/media/demonslayer_banner.jpg',
        category: 'Profiles',
        sourceQuality: 'official',
        sourceQualityLabel: 'Official source',
        firstPublished: 'Oct 02, 2020',
        lastSeen: 'Indexed 3 days ago',
        context: 'Social media card containing the key visual formatted with North American airdate timestamps.',
        protocol: 'HTTPS / Public Social Post',
        verifiedPublic: true,
        tags: ['Near Match', 'Twitter/X', 'Edited Overlay']
      },

      // Related Pages
      {
        id: 'res-ds-rel-1',
        matchType: 'related',
        matchLabel: 'Public reference database entry',
        matchConfidence: 84.5,
        similarity: 84,
        similarityTier: 'Moderate Similarity',
        title: 'Kimetsu no Yaiba (Demon Slayer) — MyAnimeList Encyclopedia & Roster',
        domain: 'myanimelist.net',
        sourceWebsite: 'MyAnimeList Reference Database',
        url: 'https://myanimelist.net/anime/38000/Kimetsu_no_Yaiba',
        image: '/demo/demonslayer.jpg',
        imageUrl: 'https://cdn.myanimelist.net/images/anime/1286/99889.jpg',
        category: 'Websites',
        sourceQuality: 'reference',
        sourceQualityLabel: 'Public reference database',
        firstPublished: 'Dec 2018',
        lastSeen: 'Indexed today',
        context: 'Authoritative anime encyclopedia page discussing production staff, character voice actors, episode breakdown, and studio history.',
        protocol: 'HTTPS / Public Reference Index',
        verifiedPublic: true,
        tags: ['Related Page', 'MyAnimeList', 'Encyclopedia']
      },
      {
        id: 'res-ds-rel-2',
        matchType: 'related',
        matchLabel: 'Community analysis thread',
        matchConfidence: 78.2,
        similarity: 78,
        similarityTier: 'Moderate Similarity',
        title: 'Official Key Visual Release & Animation Technique Breakdown — r/KimetsuNoYaiba',
        domain: 'reddit.com',
        sourceWebsite: 'Reddit (r/KimetsuNoYaiba)',
        url: 'https://reddit.com/r/KimetsuNoYaiba/comments/official_key_visual',
        image: '/demo/demonslayer.jpg',
        imageUrl: 'https://i.redd.it/demonslayer_kv_discussion.jpg',
        category: 'Articles',
        sourceQuality: 'user-generated',
        sourceQualityLabel: 'User-generated page',
        firstPublished: 'Apr 08, 2019',
        lastSeen: 'Active thread',
        context: 'Public community forum discussion breaking down the 2D hand-drawn character lines blended with 3D digital CGI water effects.',
        protocol: 'HTTPS / Public Forum',
        verifiedPublic: true,
        tags: ['Related Page', 'Reddit', 'Discussion']
      }
    ]
  },

  {
    id: 'sample-jujutsu',
    title: 'Jujutsu Kaisen',
    subtitle: 'Anime Key Visual · Satoru Gojo & Yuji Itadori',
    category: 'anime',
    src: '/demo/jujutsu.jpg',
    fileSize: '798 KB',
    dimensions: '1024 × 1536',
    format: 'JPEG',
    entityType: 'anime',
    classification: 'Anime or animation',

    mediaAnalysis: {
      title: 'Jujutsu Kaisen (呪術廻戦)',
      franchise: 'Jujutsu Kaisen / Shueisha Weekly Shonen Jump',
      characters: [
        { name: 'Satoru Gojo', role: 'Special Grade Sorcerer · Limitless & Six Eyes' },
        { name: 'Yuji Itadori', role: 'Jujutsu High Student · Vessel of Ryomen Sukuna' },
        { name: 'Megumi Fushiguro', role: 'Ten Shadows Technique Sorcerer' },
        { name: 'Ryomen Sukuna', role: 'King of Curses' }
      ],
      studio: 'MAPPA (Japan)',
      releasePeriod: '2020 – Present (TV Series & Feature Film)',
      episodeContext: 'Promotional key visual for the Shibuya Incident / Tokyo Jujutsu High Arc',
      genre: 'Dark Fantasy, Urban Supernatural, Action, Sorcery',
      officialPages: [
        { name: 'Jujutsu Kaisen Official Portal (Japan)', url: 'https://jujutsukaisen.jp/' }
      ],
      publicReferenceLinks: [
        { name: 'MyAnimeList #40748', url: 'https://myanimelist.net/anime/40748/Jujutsu_Kaisen' },
        { name: 'Reddit r/JuJutsuKaisen Community', url: 'https://reddit.com/r/JuJutsuKaisen' },
        { name: 'Twitter/X @animejujutsu', url: 'https://x.com/animejujutsu' },
        { name: 'Instagram @mappa_official', url: 'https://instagram.com/mappa_official' }
      ],
      relatedCharacters: ['Nobara Kugisaki', 'Kento Nanami', 'Suguru Geto'],
      searchTermsUsed: ['Jujutsu Kaisen', 'Gojo Satoru', 'Yuji Itadori', 'MAPPA visual'],
      confidenceLevel: 'High confidence (99.1% perceptual match)',
      confidenceNote: 'Identified based on visual and public-source evidence.'
    },

    imageContextAnalysis: {
      imageType: 'Digital Key Visual Illustration / Promotional Poster',
      sceneDescription: 'Dark urban cityscape setting featuring special grade sorcerer Satoru Gojo with iconic blindfold and white hair, alongside Yuji Itadori channeling red and purple cursed energy sparks.',
      visibleObjects: ['Gojo blindfold', 'Cursed energy aura sparks', 'Tokyo skyscraper skyline silhouettes', 'Jujutsu High uniform'],
      visibleText: 'Official 呪術廻戦 (Jujutsu Kaisen) Kanji title insignia',
      logosAndBrands: ['MAPPA Studio Crest', 'TOHO Animation Production Logo'],
      colorPalette: [
        { name: 'Electric Violet', hex: '#8b5cf6' },
        { name: 'Neon Crimson', hex: '#ef4444' },
        { name: 'Tokyo Navy', hex: '#0f172a' },
        { name: 'Ghost Silver', hex: '#e2e8f0' },
        { name: 'Abyssal Black', hex: '#020617' }
      ],
      approximateSetting: 'Nocturnal Shibuya urban rooftop against a glowing metropolis skyline',
      orientation: 'Portrait (Aspect Ratio 2:3, 1024 × 1536 px)',
      possibleSourceContext: 'Television broadcast promotion and theatrical release campaign',
      editingIndicators: 'Original uncompressed digital release art',
      searchConfidence: '99.1% (High confidence match across public anime archives)',
      suggestedSearches: ['MAPPA official Jujutsu Kaisen art', 'Gojo Satoru key visual wallpaper', 'Jujutsu Kaisen Shibuya visual']
    },

    regions: [
      {
        id: 'region-gojo',
        label: 'Character 1: Satoru Gojo',
        type: 'character',
        confidence: 99.6,
        box: { top: 12, left: 28, width: 22, height: 20 },
        description: 'Satoru Gojo with white hair, black blindfold, and Infinity aura'
      },
      {
        id: 'region-itadori',
        label: 'Character 2: Yuji Itadori',
        type: 'character',
        confidence: 99.1,
        box: { top: 26, left: 64, width: 20, height: 18 },
        description: 'Yuji Itadori channeling Divergent Fist cursed energy'
      },
      {
        id: 'region-jk-logo',
        label: 'Logo / Title Crest',
        type: 'logo',
        confidence: 99.5,
        box: { top: 72, left: 3, width: 44, height: 18 },
        description: 'Official 呪術廻戦 Kanji crest with glowing purple accent'
      },
      {
        id: 'region-jk-full',
        label: 'Entire Image Composition',
        type: 'full',
        confidence: 100,
        box: { top: 0, left: 0, width: 100, height: 100 },
        description: 'Full composition with Tokyo skyline and cursed energy'
      }
    ],

    results: [
      {
        id: 'res-jk-exact',
        matchType: 'exact',
        matchLabel: 'Exact Image Match (100% Match)',
        matchConfidence: 100,
        similarity: 100,
        similarityTier: 'High Similarity',
        title: 'TV Anime Jujutsu Kaisen: Official Shibuya Incident Visual Release',
        domain: 'jujutsukaisen.jp',
        sourceWebsite: 'Official Jujutsu Kaisen Portal (TOHO Animation)',
        url: 'https://jujutsukaisen.jp/visual/shibuya/',
        image: '/demo/jujutsu.jpg',
        imageUrl: 'https://jujutsukaisen.jp/img/visual_shibuya_hq.jpg',
        category: 'Media',
        sourceQuality: 'official',
        sourceQualityLabel: 'Official source',
        firstPublished: 'Aug 24, 2023',
        lastSeen: 'Indexed 4 days ago',
        earliestDiscovered: true,
        context: 'Image hash and visual comparison indicate an exact match with the primary key visual asset released by MAPPA and TOHO.',
        protocol: 'HTTPS / Public Official Web Asset',
        verifiedPublic: true,
        tags: ['Exact Match', 'MAPPA', 'Key Visual']
      },
      {
        id: 'res-jk-near',
        matchType: 'near',
        matchLabel: 'Resized official promotional announcement',
        matchConfidence: 95.5,
        similarity: 96,
        similarityTier: 'High Similarity',
        differences: 'Resized for social media feed card; compressed for web preview delivery',
        matchingRegions: 'Gojo blindfold and Itadori fist silhouette',
        title: 'Jujutsu Kaisen Official PR on X/Twitter: TV Anime Broadcast Visual',
        domain: 'x.com',
        sourceWebsite: 'Twitter / X (@animejujutsu)',
        url: 'https://x.com/animejujutsu/status/1693829104',
        image: '/demo/jujutsu.jpg',
        imageUrl: 'https://pbs.twimg.com/media/jk_pr_post.jpg',
        category: 'Profiles',
        sourceQuality: 'official',
        sourceQualityLabel: 'Official source',
        firstPublished: 'Aug 24, 2023',
        lastSeen: 'Indexed yesterday',
        context: 'Official production account publishing high-res promotional visual to 2.1M followers.',
        protocol: 'HTTPS / Public Social Post',
        verifiedPublic: true,
        tags: ['Near Match', 'Twitter/X', 'Official']
      },
      {
        id: 'res-jk-rel-1',
        matchType: 'related',
        matchLabel: 'Studio gallery post',
        matchConfidence: 91.0,
        similarity: 91,
        similarityTier: 'High Similarity',
        title: 'MAPPA Official Instagram: Jujutsu Kaisen Animation Art Showcase',
        domain: 'instagram.com',
        sourceWebsite: 'Instagram (@mappa_official)',
        url: 'https://instagram.com/mappa_official',
        image: '/demo/jujutsu.jpg',
        imageUrl: 'https://instagram.com/p/mappa_art_display',
        category: 'Images',
        sourceQuality: 'reputable',
        sourceQualityLabel: 'Reputable publication',
        firstPublished: 'Sep 01, 2023',
        lastSeen: 'Indexed 1 week ago',
        context: 'Production art showcase post celebrating the visual directors and background art team at MAPPA Tokyo.',
        protocol: 'HTTPS / Public Photo Post',
        verifiedPublic: true,
        tags: ['Related Page', 'Instagram', 'MAPPA']
      },
      {
        id: 'res-jk-rel-2',
        matchType: 'related',
        matchLabel: 'Public encyclopedia entry',
        matchConfidence: 89.0,
        similarity: 89,
        similarityTier: 'High Similarity',
        title: 'Jujutsu Kaisen — MyAnimeList Official Profile & Staff Registry',
        domain: 'myanimelist.net',
        sourceWebsite: 'MyAnimeList Reference Database',
        url: 'https://myanimelist.net/anime/40748/Jujutsu_Kaisen',
        image: '/demo/jujutsu.jpg',
        imageUrl: 'https://cdn.myanimelist.net/images/anime/1171/109222.jpg',
        category: 'Websites',
        sourceQuality: 'reference',
        sourceQualityLabel: 'Public reference database',
        firstPublished: 'Dec 2019',
        lastSeen: 'Indexed today',
        context: 'Public database profile detailing voice talent, production companies, and episode ratings.',
        protocol: 'HTTPS / Public Index',
        verifiedPublic: true,
        tags: ['Related Page', 'MyAnimeList', 'Directory']
      }
    ]
  },

  {
    id: 'sample-elon',
    title: 'Elon Musk (Verified Public Figure)',
    subtitle: 'CEO & Chief Engineer of SpaceX · CEO of Tesla · Owner & CTO of X',
    category: 'public-figure',
    src: '/demo/elon.jpg',
    fileSize: '428 KB',
    dimensions: '1024 × 1280',
    format: 'JPEG',
    entityType: 'public-figure',
    classification: 'Public figure',

    publicFigureData: {
      publicName: 'Elon Musk',
      profession: 'CEO & Chief Engineer of SpaceX · CEO of Tesla · Owner & CTO of X · Founder of xAI & Neuralink',
      netWorth: '~$260 Billion USD (World’s Wealthiest Individual)',
      officialWebsite: 'https://x.com/elonmusk',
      publicWork: 'Pioneered commercial orbital rocketry, electrified global automotive transport, founded implantable neurotechnology, and leads frontier AI development.',
      whatTheyDo: 'Directs spacecraft engineering and reusable orbital launch systems at SpaceX (Starship, Falcon 9). Oversees automotive design, AI Autopilot, and Optimus humanoid robotics at Tesla. Directs frontier model training (Grok) at xAI and technological direction at X (formerly Twitter).',
      howTheyDoIt: 'Applies first-principles physics reasoning, extreme vertical integration across hardware/software, and flat organizational hierarchies with rapid iterative prototyping. Operates between Starbase Boca Chica, Giga Texas Austin, and San Francisco.',
      companies: [
        {
          name: 'SpaceX',
          role: 'Founder, CEO & Chief Engineer',
          description: 'Commercial aerospace manufacturing, reusable Falcon 9 & Starship orbital launch systems, and Starlink global satellite internet constellation.',
          url: 'https://spacex.com'
        },
        {
          name: 'Tesla, Inc.',
          role: 'Technoking of Tesla & CEO',
          description: 'Electric passenger vehicles (Model S/3/X/Y, Cybertruck), utility-scale battery energy storage (Megapack), Full Self-Driving AI, and Optimus humanoid robot.',
          url: 'https://tesla.com'
        },
        {
          name: 'X Corp. (formerly Twitter)',
          role: 'Owner, Chairman & Chief Technology Officer',
          description: 'Global real-time public town square, live audio/video communication, creator monetization, and integration hub for xAI.',
          url: 'https://x.com'
        },
        {
          name: 'xAI',
          role: 'Founder',
          description: 'Frontier artificial intelligence company developing the Grok family of models, powered by the 100,000 H100 Colossus GPU cluster in Memphis.',
          url: 'https://x.ai'
        },
        {
          name: 'Neuralink',
          role: 'Co-Founder',
          description: 'High-bandwidth implantable brain-computer interfaces designed to restore motor, speech, and sensory autonomy.',
          url: 'https://neuralink.com'
        },
        {
          name: 'The Boring Company',
          role: 'Founder',
          description: 'Underground tunneling infrastructure and zero-emission transit loops (e.g. Las Vegas Convention Center Loop).',
          url: 'https://boringcompany.com'
        }
      ],
      socialProfiles: [
        { platform: 'X (Twitter)', handle: '@elonmusk', followers: '200M+ Followers (Official)', url: 'https://x.com/elonmusk' },
        { platform: 'Instagram', handle: '@elonmusk', followers: 'Public Figure Profile', url: 'https://instagram.com/elonmusk' },
        { platform: 'Snapchat', handle: 'Elon Musk Public Stories', followers: 'Verified Public Profile', url: 'https://www.snapchat.com' },
        { platform: 'LinkedIn', handle: 'Elon Musk Executive Record', followers: 'Corporate Leadership', url: 'https://www.linkedin.com' },
        { platform: 'Wikipedia', handle: 'Elon Musk (Comprehensive Biography)', followers: 'Verified Open Archive', url: 'https://en.wikipedia.org/wiki/Elon_Musk' },
        { platform: 'Tesla Corporate Bio', handle: 'Leadership Directory', followers: 'Executive Listing', url: 'https://ir.tesla.com/corporate/elon-musk' },
        { platform: 'SpaceX Leadership', handle: 'spacex.com/about', followers: 'Chief Engineer Bio', url: 'https://spacex.com/about' },
        { platform: 'YouTube Broadcasts', handle: '@SpaceX Official & Tesla Keynotes', followers: '7M+ Subscribers', url: 'https://youtube.com/@SpaceX' },
        { platform: 'Reddit Community', handle: 'r/elonmusk & r/spacex', followers: '2.5M+ Members', url: 'https://reddit.com/r/elonmusk' },
        { platform: 'Bloomberg Index', handle: 'Elon R. Musk', followers: '#1 Global Wealth (~$260B)', url: 'https://bloomberg.com/billionaires/profiles/elon-r-musk' },
        { platform: 'Forbes Profile', handle: 'Elon Musk', followers: 'Billionaires Roster', url: 'https://forbes.com/profile/elon-musk' }
      ],
      documentedAppearances: [
        { event: 'SpaceX Starship Integrated Flight Test (IFT) Launch', date: 'Starbase Boca Chica, TX' },
        { event: 'Tesla "We, Robot" Cybercab & Optimus Keynote', date: 'Warner Bros. Studios, Burbank, CA' },
        { event: 'International Astronautical Congress (IAC) Keynote Address', date: 'Global Aerospace Assembly' },
        { event: 'US Senate AI Insight Forum', date: 'Capitol Hill, Washington, D.C.' }
      ],
      reputableNewsSources: [
        { title: 'Bloomberg: Elon Musk Corporate Footprint & Ventures', url: 'https://bloomberg.com' },
        { title: 'Reuters: SpaceX Starship Commercial & Orbital Milestones', url: 'https://reuters.com' },
        { title: 'Wall Street Journal: Inside the Multi-Company Empire of Elon Musk', url: 'https://wsj.com' }
      ],
      disclaimer: 'Exact public-figure match. Verified against corporate regulatory filings (SEC), documented press conferences, and verified social accounts across the open web.'
    },

    imageContextAnalysis: {
      imageType: 'High-Resolution Photographic Portrait / Media Capture',
      sceneDescription: 'Verified public photograph of Elon Musk. Subject is a prominent public figure and corporate executive.',
      visibleObjects: ['Formal or business attire', 'Keynote stage / institutional setting', 'Clean facial geometry'],
      visibleText: 'Elon Musk',
      logosAndBrands: ['SpaceX', 'Tesla', 'X Corp', 'xAI', 'Neuralink', 'The Boring Company'],
      colorPalette: [
        { name: 'Executive Obsidian', hex: '#0f172a' },
        { name: 'Corporate Steel', hex: '#334155' },
        { name: 'Accent Sapphire', hex: '#2563eb' },
        { name: 'Contrast Frost', hex: '#f8fafc' }
      ],
      approximateSetting: 'Corporate headquarters, global conference keynote, or press briefing',
      orientation: 'Portrait orientation',
      possibleSourceContext: 'Verified corporate press kit, international media feature, or official directory',
      editingIndicators: 'Standard professional photographic capture',
      searchConfidence: '99.8% (Verified across multiple corporate, media, and encyclopedic databases)',
      suggestedSearches: [
        'Elon Musk career timeline',
        'Elon Musk companies and investments',
        'Elon Musk latest keynote speech'
      ]
    },

    regions: [
      {
        id: 'region-elon-face',
        label: 'Elon Musk (Facial Identification)',
        type: 'face',
        confidence: 99.8,
        box: { top: 12, left: 30, width: 40, height: 42 },
        description: 'Prominent facial geometry matching verified public image database for Elon Musk'
      },
      {
        id: 'region-elon-full',
        label: 'Entire Portrait Composition',
        type: 'full',
        confidence: 100,
        box: { top: 0, left: 0, width: 100, height: 100 },
        description: 'Complete high-resolution visual asset'
      }
    ],

    results: [
      {
        id: 'res-elon-exact-1',
        matchType: 'exact',
        matchLabel: 'Exact Image Match (100% Match)',
        matchConfidence: 100,
        similarity: 100,
        similarityTier: 'High Similarity',
        title: 'Official Profile & Executive Records: Elon Musk',
        domain: 'x.com',
        sourceWebsite: 'X Corp. Official Profile',
        url: 'https://x.com/elonmusk',
        image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Elon_Musk_Royal_Society_crop.jpg/800px-Elon_Musk_Royal_Society_crop.jpg',
        imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Elon_Musk_Royal_Society_crop.jpg/800px-Elon_Musk_Royal_Society_crop.jpg',
        category: 'Profiles',
        sourceQuality: 'official',
        sourceQualityLabel: 'Official source',
        firstPublished: 'Primary Public Record',
        lastSeen: 'Indexed today',
        earliestDiscovered: true,
        context: 'Perceptual hash match (pHash distance: 0). Exact bitwise duplicate found on verified official domain.',
        protocol: 'HTTPS / Public Verified Domain',
        verifiedPublic: true,
        tags: ['Exact Match', '100% Match', 'Executive Profile', 'Elon Musk']
      },
      {
        id: 'res-elon-near-1',
        matchType: 'near',
        matchLabel: 'Verified Media Article & Coverage',
        matchConfidence: 97.5,
        similarity: 98,
        similarityTier: 'High Similarity',
        differences: 'Cropped and resized for international news broadcast banner',
        matchingRegions: 'Facial landmarks, signature hairstyle, and upper torso attire',
        title: 'Elon Musk: Key Ventures, Executive Leadership & Net Worth Overview',
        domain: 'bloomberg.com',
        sourceWebsite: 'Bloomberg Markets',
        url: 'https://bloomberg.com',
        image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Elon_Musk_Royal_Society_crop.jpg/800px-Elon_Musk_Royal_Society_crop.jpg',
        imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Elon_Musk_Royal_Society_crop.jpg/800px-Elon_Musk_Royal_Society_crop.jpg',
        category: 'Articles',
        sourceQuality: 'reputable',
        sourceQualityLabel: 'Reputable publication',
        firstPublished: 'Recent editorial feature',
        lastSeen: 'Indexed 4 hours ago',
        context: 'Detailed financial analysis, corporate ownership breakdown, and global industry impact of Elon Musk.',
        protocol: 'HTTPS / Reputable Financial News',
        verifiedPublic: true,
        tags: ['Near Match', 'Bloomberg', 'Industry Leadership']
      },
      {
        id: 'res-elon-rel-1',
        matchType: 'related',
        matchLabel: 'Open Encyclopedic Biography Record',
        matchConfidence: 94.0,
        similarity: 94,
        similarityTier: 'High Similarity',
        title: 'Wikipedia: Comprehensive Career & Biography of Elon Musk',
        domain: 'wikipedia.org',
        sourceWebsite: 'Wikipedia, the Free Encyclopedia',
        url: 'https://en.wikipedia.org/wiki/Elon_Musk',
        image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Elon_Musk_Royal_Society_crop.jpg/800px-Elon_Musk_Royal_Society_crop.jpg',
        imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Elon_Musk_Royal_Society_crop.jpg/800px-Elon_Musk_Royal_Society_crop.jpg',
        category: 'Websites',
        sourceQuality: 'reference',
        sourceQualityLabel: 'Public reference database',
        firstPublished: 'Open Collaborative Archive',
        lastSeen: 'Active thread',
        context: 'Comprehensive public encyclopedia documentation covering early life, education, founding of companies, and major public milestones.',
        protocol: 'HTTPS / Public Knowledge Repository',
        verifiedPublic: true,
        tags: ['Related Page', 'Wikipedia', 'Biography']
      }
    ]
  },

  {
    id: 'sample-elena',
    title: 'Dr. Elena Vance (Academic Keynote Speaker)',
    subtitle: 'Widely Known Public Figure · Computer Science Professor',
    category: 'public-figure',
    src: '/demo/elena.jpg',
    fileSize: '614 KB',
    dimensions: '1024 × 1024',
    format: 'JPEG',
    entityType: 'public-figure',
    classification: 'Public figure',

    // Public Figure Handling (Strictly Reputable & Non-Sensitive)
    publicFigureData: {
      publicName: 'Dr. Elena Vance, Ph.D.',
      profession: 'Professor of Computer Science · Research Director in AI Accountability',
      officialWebsite: 'https://hai.stanford.edu/people/elena-vance',
      publicWork: 'Author of 18 peer-reviewed papers on cryptographic privacy safeguards, zero-knowledge verification, and perceptual similarity bounds.',
      whatTheyDo: 'Directs frontier research on AI transparency, algorithmic auditing, and mathematical privacy guarantees for visual neural networks.',
      howTheyDoIt: 'Leads a team of 24 Ph.D. researchers at Stanford HAI, collaborating with open-source communities, regulatory advisory boards, and international standards consortiums (IEEE/ACM).',
      socialProfiles: [
        { platform: 'Instagram', handle: '@elena.vance.ai', url: 'https://instagram.com' },
        { platform: 'Twitter / X', handle: '@elenavance_phd', url: 'https://x.com' },
        { platform: 'LinkedIn', handle: 'in/elena-vance-ai', url: 'https://linkedin.com' },
        { platform: 'Wikipedia', handle: 'Elena Vance (Academic)', url: 'https://wikipedia.org' },
        { platform: 'YouTube', handle: 'Stanford HAI Keynotes', url: 'https://youtube.com' }
      ],
      documentedAppearances: [
        { event: 'Global Tech Summit 2025 Keynote Plenary', date: 'Nov 2025', location: 'San Francisco, CA' },
        { event: 'IEEE Symposium on Security and Privacy', date: 'May 2025', location: 'San Jose, CA' },
        { event: 'ACM Conference on Fairness, Accountability, and Transparency (FAccT)', date: 'Jan 2026' }
      ],
      officialProfiles: [
        { platform: 'Stanford HAI Academic Profile', url: 'https://hai.stanford.edu/people/elena-vance' },
        { platform: 'IEEE Computer Society Author Index', url: 'https://computer.org/profiles/e-vance-ieee' },
        { platform: 'GitHub Open Source Maintainer', url: 'https://github.com/elena-vance-research' }
      ],
      reputableNewsSources: [
        { title: 'WIRED Ideas: Balancing Privacy and Machine Perception in Open Systems', url: 'https://wired.com/story/privacy-perceptual-hash-limits' }
      ],
      disclaimer: 'Exact public-figure match. Verified against open university faculty directories, peer-reviewed publications, and documented conference keynotes.'
    },

    imageContextAnalysis: {
      imageType: 'Professional Photographic Studio Headshot',
      sceneDescription: 'Centered high-resolution professional portrait of a woman in dark tailored blazer with natural indoor office illumination and softly defocused research laboratory background.',
      visibleObjects: ['Dark tailored wool blazer', 'Silver pendant necklace', 'Optical eyewear frames in background depth'],
      visibleText: 'None detected in query frame',
      logosAndBrands: 'None visible on apparel',
      colorPalette: [
        { name: 'Warm Amber Ochre', hex: '#d97706' },
        { name: 'Graphite Charcoal', hex: '#1e293b' },
        { name: 'Alabaster Ivory', hex: '#f8fafc' },
        { name: 'Slate Gray', hex: '#64748b' }
      ],
      approximateSetting: 'Modern academic research building or university conference atrium',
      orientation: 'Square (Aspect Ratio 1:1, 1024 × 1024 px)',
      possibleSourceContext: 'Institutional faculty directory, academic symposium speaker biography, or press release headshot',
      editingIndicators: 'Professional studio color balance and subtle depth-of-field grading',
      searchConfidence: '94.2% (Correlated with verified institutional web listings)',
      suggestedSearches: ['Stanford HAI faculty directory Elena Vance', 'IEEE Computer Society Elena Vance', 'Tech Summit 2025 keynote speaker']
    },

    regions: [
      {
        id: 'region-elena-primary',
        label: 'Face Region: Primary Subject',
        type: 'face',
        confidence: 98.7,
        box: { top: 13, left: 32, width: 34, height: 38 },
        description: 'Centered facial geometry with 68 landmark points detected'
      },
      {
        id: 'region-elena-attire',
        label: 'Visual Element: Lapel & Attire',
        type: 'object',
        confidence: 86.4,
        box: { top: 51, left: 40, width: 20, height: 16 },
        description: 'Dark tailored blazer lapel structure'
      },
      {
        id: 'region-elena-full',
        label: 'Entire Image Composition',
        type: 'full',
        confidence: 100,
        box: { top: 0, left: 0, width: 100, height: 100 },
        description: 'Full studio portrait composition'
      }
    ],

    results: [
      {
        id: 'res-elena-exact',
        matchType: 'exact',
        matchLabel: 'Exact Image Match (100% Match)',
        matchConfidence: 100,
        similarity: 100,
        similarityTier: 'High Similarity',
        title: 'Faculty & Research Affiliates Directory 2025–2026',
        domain: 'hai.stanford.edu',
        sourceWebsite: 'Stanford University Institute for Human-Centered AI',
        url: 'https://hai.stanford.edu/people/elena-vance',
        image: '/demo/elena.jpg',
        imageUrl: 'https://hai.stanford.edu/sites/default/files/faculty/vance_elena_2025.jpg',
        category: 'Profiles',
        sourceQuality: 'official',
        sourceQualityLabel: 'Official source',
        firstPublished: 'Aug 14, 2025',
        lastSeen: 'Indexed 3 days ago',
        earliestDiscovered: true,
        context: 'Exact source headshot asset embedded in official Stanford University academic faculty roster.',
        protocol: 'HTTPS / Public University Index',
        verifiedPublic: true,
        tags: ['Exact Match', 'Stanford HAI', 'Academic']
      },
      {
        id: 'res-elena-near',
        matchType: 'near',
        matchLabel: 'Different photograph from same keynote event',
        matchConfidence: 89.1,
        similarity: 89,
        similarityTier: 'High Similarity',
        differences: 'Different camera angle, conference stage lighting, and microphone headset visible',
        matchingRegions: 'Facial structural geometry and matching eyewear',
        title: 'Keynote Plenary: Balancing Privacy and Machine Perception in Open Systems',
        domain: 'techsummit2025.org',
        sourceWebsite: 'Global Tech Summit Press Center',
        url: 'https://techsummit2025.org/speakers/elena-vance',
        image: '/demo/elena_talk.jpg',
        imageUrl: 'https://techsummit2025.org/media/gallery/keynote_elena_vance.jpg',
        category: 'Articles',
        sourceQuality: 'reputable',
        sourceQualityLabel: 'Reputable publication',
        firstPublished: 'Nov 04, 2025',
        lastSeen: 'Indexed 2 weeks ago',
        context: 'Conference live photography of the opening morning address at the Moscone Center.',
        protocol: 'HTTPS / Public Press Kit',
        verifiedPublic: true,
        tags: ['Near Match', 'Conference', 'Keynote']
      },
      {
        id: 'res-elena-rel',
        matchType: 'related',
        matchLabel: 'Peer-reviewed editorial commentary',
        matchConfidence: 81.5,
        similarity: 82,
        similarityTier: 'Moderate Similarity',
        title: 'WIRED Ideas: The Myth of Absolute Facial Uniqueness in Web Search',
        domain: 'wired.com',
        sourceWebsite: 'WIRED Magazine',
        url: 'https://wired.com/story/privacy-perceptual-hash-limits',
        image: '/demo/elena_talk.jpg',
        imageUrl: 'https://media.wired.com/photos/vance_editorial_opener.jpg',
        category: 'Articles',
        sourceQuality: 'reputable',
        sourceQualityLabel: 'Reputable publication',
        firstPublished: 'Dec 09, 2025',
        lastSeen: 'Indexed 1 month ago',
        context: 'Featured guest essay discussing mathematical limits in automated visual matching systems.',
        protocol: 'HTTPS / Editorial Column',
        verifiedPublic: true,
        tags: ['Related Page', 'WIRED', 'Editorial']
      }
    ]
  },

  {
    id: 'sample-ordinary',
    title: 'Private Individual (Street Photography Subject)',
    subtitle: 'Ordinary Person · Strict Privacy Guardrail Demo',
    category: 'ordinary-person',
    src: '/demo/chen.jpg',
    fileSize: '642 KB',
    dimensions: '1024 × 1024',
    format: 'JPEG',
    entityType: 'ordinary-person',
    classification: 'Unknown or low-confidence content',

    // Strict Ordinary Person Privacy Guardrail
    ordinaryPersonGuardrail: {
      active: true,
      mandatoryNotice: 'We can describe visible, non-sensitive image details, but we do not identify private individuals or search for personal profiles.',
      nonIdentifyingDetails: {
        visiblePeopleCount: 1,
        approximateComposition: 'Chest-up medium close-up portrait, subject positioned in center foreground with direct eye gaze.',
        clothingColors: 'Charcoal black turtleneck knit sweater with uniform dark weave.',
        accessories: 'Dark acetate optical eyewear frames with circular silhouette; no visible jewelry.',
        pose: 'Neutral front-facing posture with chin slightly elevated toward key light source.',
        lighting: 'Diffused studio softbox key light from upper camera-right; low-fill ratio creating gentle facial shadow.',
        background: 'Shallow depth of field showing softly blurred ambient indoor architectural elements with cool daylight tones.',
        generalScene: 'Indoor professional or creative workspace environment.',
        visibleTextOrLogos: 'None detected across clothing or background.',
        imageQuality: 'High clarity, sharp focal plane across glasses and eyes, minimal sensor noise.',
        editingStatus: 'Standard digital RAW camera development; no aggressive filters, generative synthesis, or heavy composite manipulation detected.'
      }
    },

    imageContextAnalysis: {
      imageType: 'Portrait Photography (Unidentified Private Subject)',
      sceneDescription: 'A single individual photographed in studio lighting wearing dark sweater and spectacles. The subject appears to be a private citizen or non-celebrity individual.',
      visibleObjects: ['Dark knit turtleneck', 'Dark circular acetate eyeglasses'],
      visibleText: 'None detected',
      logosAndBrands: 'None detected',
      colorPalette: [
        { name: 'Warm Tawny Skin', hex: '#ca8a04' },
        { name: 'Onyx Black', hex: '#0f172a' },
        { name: 'Cool Slate Gray', hex: '#64748b' },
        { name: 'Soft Linen White', hex: '#f8fafc' }
      ],
      approximateSetting: 'Modern studio or office interior with neutral blurred backdrop',
      orientation: 'Square (Aspect Ratio 1:1, 1024 × 1024 px)',
      possibleSourceContext: 'Personal photograph, creative portfolio portrait, or unindexed stock photography capture',
      editingIndicators: 'Natural photographic development; no synthetic distortion or composite staging',
      searchConfidence: 'Non-identifying mode active (Strict privacy enforcement: zero personal profiling)',
      suggestedSearches: ['Studio portrait lighting techniques', 'Minimalist black turtleneck portrait', 'Acetate optical frame styles']
    },

    regions: [
      {
        id: 'region-ordinary-face',
        label: 'Face Region (Non-Identifying Visual Region)',
        type: 'face',
        confidence: 99.1,
        box: { top: 15, left: 33, width: 35, height: 40 },
        description: 'Visual facial geometry used solely for non-identifying lighting and composition analysis'
      },
      {
        id: 'region-ordinary-glasses',
        label: 'Object: Eyewear Frame',
        type: 'object',
        confidence: 93.2,
        box: { top: 29, left: 35, width: 31, height: 11 },
        description: 'Dark acetate optical eyewear frames'
      },
      {
        id: 'region-ordinary-full',
        label: 'Entire Image Composition',
        type: 'full',
        confidence: 100,
        box: { top: 0, left: 0, width: 100, height: 100 },
        description: 'Full composition framing'
      }
    ],

    // Empty or non-identifying matches to enforce strict privacy
    results: []
  },

  {
    id: 'sample-nomatch',
    title: 'Abstract Architectural Geometry',
    subtitle: 'Zero Public-Source Matches Demo',
    category: 'no-match',
    src: '/demo/conference.jpg',
    fileSize: '786 KB',
    dimensions: '1024 × 1024',
    format: 'JPEG',
    entityType: 'no-match',
    classification: 'Unknown or low-confidence content',

    isNoMatch: true,

    imageContextAnalysis: {
      imageType: 'Auditorium Interior Architecture / Stage Photography',
      sceneDescription: 'Wide-angle capture of a large indoor conference hall with ambient blue stage wash and distant audience seating.',
      visibleObjects: ['Stage platform', 'Audio podium', 'Overhead truss lighting'],
      visibleText: 'Indistinct distant stage lettering',
      logosAndBrands: 'None definitively matched in public indexes',
      colorPalette: [
        { name: 'Indigo Stage Wash', hex: '#4338ca' },
        { name: 'Deep Navy', hex: '#1e1b4b' },
        { name: 'Auditorium Cyan', hex: '#06b6d4' }
      ],
      approximateSetting: 'Large auditorium or convention hall',
      orientation: 'Square (Aspect Ratio 1:1, 1024 × 1024 px)',
      possibleSourceContext: 'Private event photography or unindexed internal corporate seminar',
      editingIndicators: 'Standard wide lens compression',
      searchConfidence: 'Low confidence (0 verified public-source matches located)',
      suggestedSearches: ['Crop specific stage banner', 'Search audio equipment model', 'Adjust image contrast']
    },

    regions: [
      {
        id: 'region-nomatch-full',
        label: 'Entire Scene Composition',
        type: 'full',
        confidence: 100,
        box: { top: 0, left: 0, width: 100, height: 100 },
        description: 'Full scene framing with zero index correlation'
      }
    ],

    results: []
  },

  {
    id: 'sample-conference',
    title: 'Global Tech Summit 2024 (Keynote Stage)',
    subtitle: 'Multi-Element Keynote Scene · Stage Banner, Microphones & Panelists',
    category: 'landmark',
    src: '/demo/conference.jpg',
    fileSize: '786 KB',
    dimensions: '1024 × 1024',
    format: 'JPEG',
    entityType: 'stage-scene',
    classification: 'Landmark',

    imageContextAnalysis: {
      imageType: 'Event Photography / Public Keynote Stage Scene',
      sceneDescription: 'Wide-angle presentation stage with multiple keynote speakers, digital backdrop reading "GLOBAL TECH SUMMIT 2024", and auditorium lighting.',
      visibleObjects: ['Headset microphones', 'Auditorium seating', 'Stage display monitor', 'Branded stage banner'],
      visibleText: '"GLOBAL TECH SUMMIT 2024"',
      logosAndBrands: ['TechSummit Official Brand Crest', 'Google Cloud Sponsor Logo', 'Adobe Enterprise Stamp'],
      colorPalette: [
        { name: 'Conference Blue', hex: '#2563eb' },
        { name: 'Deep Royal Navy', hex: '#1e3a8a' },
        { name: 'Auditorium White', hex: '#ffffff' },
        { name: 'Cyan Glow', hex: '#06b6d4' }
      ],
      approximateSetting: 'Convention center main plenary auditorium in San Francisco, CA',
      orientation: 'Square (Aspect Ratio 1:1, 1024 × 1024 px)',
      possibleSourceContext: 'Official conference press kit and international technology journalism coverage',
      editingIndicators: 'Professional event photojournalism grading; no composite manipulation',
      searchConfidence: '97.5% (High correlation across public tech news and conference archives)',
      suggestedSearches: ['Global Tech Summit 2024 press gallery', 'TechSummit keynote day 1 liveblog', 'San Francisco convention center plenary 2024']
    },

    regions: [
      {
        id: 'region-conf-speaker1',
        label: 'Face Region: Left Keynote Speaker',
        type: 'face',
        confidence: 97.5,
        box: { top: 32, left: 23, width: 12, height: 14 },
        description: 'Keynote presenter speaking with headset microphone'
      },
      {
        id: 'region-conf-speaker2',
        label: 'Face Region: Right Panelist Host',
        type: 'face',
        confidence: 96.8,
        box: { top: 34, left: 71, width: 12, height: 14 },
        description: 'Panel host seated with tablet and microphone'
      },
      {
        id: 'region-conf-banner',
        label: 'Logo / Object: Stage Banner & Text',
        type: 'logo',
        confidence: 99.0,
        box: { top: 3, left: 4, width: 86, height: 23 },
        description: 'Digital display reading "GLOBAL TECH SUMMIT 2024"'
      },
      {
        id: 'region-conf-full',
        label: 'Entire Image Composition',
        type: 'full',
        confidence: 100,
        box: { top: 0, left: 0, width: 100, height: 100 },
        description: 'Wide shot of auditorium, stage seating, and audience'
      }
    ],

    results: [
      {
        id: 'res-conf-exact',
        matchType: 'exact',
        matchLabel: 'Exact Image Match (100% Match)',
        matchConfidence: 100,
        similarity: 100,
        similarityTier: 'High Similarity',
        title: 'Global Tech Summit 2024: Official Keynote Media Kit & Highlights',
        domain: 'techsummit2024.com',
        sourceWebsite: 'TechSummit Media Center',
        url: 'https://techsummit2024.com/press/day-1-gallery',
        image: '/demo/conference.jpg',
        imageUrl: 'https://techsummit2024.com/assets/gallery/plenary_opening.jpg',
        category: 'Images',
        sourceQuality: 'official',
        sourceQualityLabel: 'Official source',
        firstPublished: 'Oct 12, 2024',
        lastSeen: 'Indexed 1 week ago',
        earliestDiscovered: true,
        context: 'Primary press release photograph distributed to international media covering the opening day proceedings.',
        protocol: 'HTTPS / Public Gallery',
        verifiedPublic: true,
        tags: ['Exact Match', 'Press Release', 'Keynote', 'San Francisco']
      },
      {
        id: 'res-conf-near',
        matchType: 'near',
        matchLabel: 'Cropped editorial companion photograph',
        matchConfidence: 91.2,
        similarity: 91,
        similarityTier: 'High Similarity',
        differences: 'Cropped tightly on stage banner and podium speaker; audience seating removed',
        matchingRegions: 'Stage banner typography and speaker headset position',
        title: 'Adobe Enterprise Blog: Partnering for Ethical Next-Gen Interfaces',
        domain: 'blog.adobe.com',
        sourceWebsite: 'Adobe Enterprise Blog',
        url: 'https://blog.adobe.com/en/publish/2024/10/tech-summit-sponsorship',
        image: '/demo/conference.jpg',
        imageUrl: 'https://blog.adobe.com/media_1920_summit.jpg',
        category: 'Articles',
        sourceQuality: 'reputable',
        sourceQualityLabel: 'Reputable publication',
        firstPublished: 'Oct 15, 2024',
        lastSeen: 'Indexed 3 weeks ago',
        context: 'Corporate sponsor retrospective detailing main-stage product demonstrations and design system announcements.',
        protocol: 'HTTPS / Public PR',
        verifiedPublic: true,
        tags: ['Near Match', 'Corporate Blog', 'Adobe']
      },
      {
        id: 'res-conf-rel',
        matchType: 'related',
        matchLabel: 'Live journal reporting page',
        matchConfidence: 82.5,
        similarity: 83,
        similarityTier: 'Moderate Similarity',
        title: 'TechCrunch Livewire: What Happened on Day 1 of Global Tech Summit',
        domain: 'techcrunch.com',
        sourceWebsite: 'TechCrunch',
        url: 'https://techcrunch.com/2024/10/12/livewire-tech-summit-day-1/',
        image: '/demo/conference.jpg',
        imageUrl: 'https://techcrunch.com/wp-content/uploads/2024/10/tech-summit-stage.jpg',
        category: 'Articles',
        sourceQuality: 'reputable',
        sourceQualityLabel: 'Reputable publication',
        firstPublished: 'Oct 12, 2024',
        lastSeen: 'Indexed 1 month ago',
        context: 'Journalistic live-blog summarizing key announcements from Google Cloud, Adobe, and Salesforce on enterprise machine learning.',
        protocol: 'HTTPS / News Article',
        verifiedPublic: true,
        tags: ['Related Page', 'News', 'TechCrunch']
      }
    ]
  }
];

export const INITIAL_SEARCH_HISTORY = [
  {
    id: 'hist-0',
    name: 'Anime Poster — Demon Slayer: Kimetsu no Yaiba',
    date: 'Sep 19, 2026 · 11:30',
    image: '/demo/demonslayer.jpg',
    selectedRegionLabel: 'Character 1: Tanjiro Kamado',
    resultCount: 6,
    status: 'Completed',
    sampleId: 'sample-demonslayer',
    entityType: 'anime',
    title: 'Demon Slayer: Kimetsu no Yaiba',
    characters: [
      { name: 'Tanjiro Kamado', role: 'Main Protagonist · Water & Sun Breathing' },
      { name: 'Nezuko Kamado', role: 'Demon Sister · Exploding Blood Art' }
    ],
    filtersApplied: ['All']
  },
  {
    id: 'hist-1',
    name: 'Public Figure Search — Dr. Elena Vance',
    date: 'Sep 18, 2026 · 14:22',
    image: '/demo/elena.jpg',
    selectedRegionLabel: 'Face Region: Primary Subject',
    resultCount: 3,
    status: 'Completed',
    sampleId: 'sample-elena',
    entityType: 'public-figure',
    title: 'Dr. Elena Vance, Ph.D.',
    filtersApplied: ['All']
  },
  {
    id: 'hist-2',
    name: 'Ordinary Person Strict Privacy Demo',
    date: 'Sep 17, 2026 · 16:45',
    image: '/demo/chen.jpg',
    selectedRegionLabel: 'Face Region (Non-Identifying)',
    resultCount: 0,
    status: 'Privacy Guardrail Active',
    sampleId: 'sample-ordinary',
    entityType: 'ordinary-person',
    title: 'Private Individual (Non-Identifying Analysis)',
    filtersApplied: ['All']
  },
  {
    id: 'hist-3',
    name: 'Keynote Stage Scene — Global Tech Summit',
    date: 'Sep 15, 2026 · 09:41',
    image: '/demo/conference.jpg',
    selectedRegionLabel: 'Entire Image Composition',
    resultCount: 3,
    status: 'Completed',
    sampleId: 'sample-conference',
    entityType: 'stage-scene',
    title: 'Global Tech Summit 2024',
    filtersApplied: ['All']
  }
];

export const INITIAL_COLLECTIONS = [
  { id: 'all', name: 'All Saved Results', count: 3, description: 'All bookmarked public source findings' },
  { id: 'media', name: 'Anime & Media Assets', count: 1, description: 'Official series key visuals and studio announcements' },
  { id: 'academic', name: 'Academic & Faculty', count: 1, description: 'University directories and peer-reviewed journals' },
  { id: 'press', name: 'Press & Media Mentions', count: 1, description: 'Conference media kits, blogs, and guest articles' }
];

export const INITIAL_SAVED_ITEMS = [
  {
    id: 'saved-1',
    resultId: 'res-ds-exact-1',
    collectionId: 'media',
    title: 'Demon Slayer: Kimetsu no Yaiba — Official Key Visual Asset #KV-01',
    domain: 'kimetsu.com',
    platform: 'Official Kimetsu Portal (Aniplex Japan)',
    image: '/demo/demonslayer.jpg',
    originalImage: '/demo/demonslayer.jpg',
    similarity: 99,
    savedAt: 'Sep 19, 2026 · 11:35',
    url: 'https://kimetsu.com/anime/risshihen/visual/',
    category: 'Media',
    notes: 'Official key visual asset on ufotable Japan website.'
  },
  {
    id: 'saved-2',
    resultId: 'res-elena-exact',
    collectionId: 'academic',
    title: 'Faculty & Research Affiliates Directory 2025–2026',
    domain: 'hai.stanford.edu',
    platform: 'Stanford University HAI',
    image: '/demo/elena.jpg',
    originalImage: '/demo/elena.jpg',
    similarity: 96,
    savedAt: 'Sep 18, 2026 · 14:25',
    url: 'https://hai.stanford.edu/people/elena-vance',
    category: 'Profiles',
    notes: 'Verified academic faculty page. High similarity with query image.'
  },
  {
    id: 'saved-3',
    resultId: 'res-conf-exact',
    collectionId: 'press',
    title: 'Global Tech Summit 2024: Official Keynote Media Kit & Highlights',
    domain: 'techsummit2024.com',
    platform: 'TechSummit Media Center',
    image: '/demo/conference.jpg',
    originalImage: '/demo/conference.jpg',
    similarity: 99,
    savedAt: 'Sep 15, 2026 · 09:44',
    url: 'https://techsummit2024.com/press/day-1-gallery',
    category: 'Images',
    notes: 'Identical public press photo in official media distribution kit.'
  }
];

export const COMING_SOON_FEATURES = [
  {
    id: 'cs-digital-identity',
    title: 'Digital Identity Footprint',
    badge: 'Q4 2026',
    description: 'Monitor when public images containing your verified face or likeness appear on newly indexed open web pages with automated privacy alerts.',
    highlights: ['Opt-in cryptographic ownership verification', 'Automated takedown request generator (DMCA / GDPR Right to Erasure)', 'New public appearance notifications']
  },
  {
    id: 'cs-ai-assistant',
    title: 'Visual Research Assistant',
    badge: 'Beta',
    description: 'Interactive AI analyst that answers contextual questions about where and when an image was published, checking publication timelines and citation chains.',
    highlights: ['Reverse image timeline reconstruction', 'Publisher metadata extraction', 'Context shift detection (misinformation flagging)']
  },
  {
    id: 'cs-timeline',
    title: 'Public Appearance Timeline',
    badge: 'In Development',
    description: 'Chronological visual graph charting the earliest known public indexed date of an image across open press, forums, and archives.',
    highlights: ['Earliest indexed web record discovery', 'Republishing wave visualization', 'Archival snapshot integration']
  },
  {
    id: 'cs-source-graph',
    title: 'Source Network Graph',
    badge: 'Preview',
    description: 'Interactive node-link visualization showing how an image cascaded from its original publication through syndication, social commentary, and news coverage.',
    highlights: ['Syndication hub detection', 'Domain cluster analysis', 'Provenance path tracing']
  },
  {
    id: 'cs-reports',
    title: 'Auditable PDF Compliance Reports',
    badge: 'Enterprise',
    description: 'Generate timestamped, legally compliant visual similarity audit dossiers for brand protection teams, copyright holders, and privacy counsels.',
    highlights: ['Cryptographic SHA-256 result hashing', 'Executive similarity summary', 'Chain of public availability record']
  },
  {
    id: 'cs-connected-providers',
    title: 'Connected Search Providers Hub',
    badge: 'API Hub',
    description: 'Plug in custom enterprise search APIs, private indexing nodes, or additional commercial reverse image providers with modular connector hooks.',
    highlights: ['Multi-provider federated query distribution', 'Real-time provider latency monitoring', 'Enterprise custom indexing endpoint']
  }
];

export const FAQ_ITEMS = [
  {
    q: 'Does DIGITAL YOUR scan private social media or password-protected accounts?',
    a: 'No. DIGITAL YOUR operates strictly on publicly indexed, legally accessible web sources, open archives, and public media databases. We never bypass authentication, access private Instagram/Facebook/LinkedIn accounts, or scrape behind paywalls.'
  },
  {
    q: 'Does an image match prove someone’s legal identity?',
    a: 'No. Visual similarity percentages reflect algorithmic feature proximity and must never be interpreted as verified personal identity, legal affiliation, or ownership. For private or ordinary individuals, we strictly refuse to guess identity or search personal profiles.'
  },
  {
    q: 'How does DIGITAL YOUR handle ordinary private individuals?',
    a: 'If an image contains an ordinary private person or unknown individual, our strict privacy guardrails activate: we do not guess names, we do not search personal social accounts, and we do not compile profiles. We only provide non-sensitive visual description (clothing colors, lighting, composition).'
  },
  {
    q: 'Can DIGITAL YOUR identify anime posters, fictional characters, and media scenes?',
    a: 'Yes! Our multimodal recognition engine classifies anime posters, animated series, films, and game characters, extracting franchise names, character rosters, production studios, and linking to public reference directories such as MyAnimeList and Crunchyroll.'
  },
  {
    q: 'How does the free evaluation quota work?',
    a: 'Every explorer receives 3 complimentary public-source searches. In demo mode, you can reset your quota at any time via the dashboard or upgrade to the Researcher Pro tier for high-volume research.'
  }
];
