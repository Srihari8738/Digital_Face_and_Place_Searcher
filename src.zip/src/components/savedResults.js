// src/components/savedResults.js
// Saved results dossier with collection filters, note annotations, export tools, and detail inspection

import { store } from '../state.js';
import { renderIcon } from '../utils/icons.js';

export function renderSavedResults() {
  const { savedResults, collections, activeCollectionFilter } = store.state;
  const activeCol = activeCollectionFilter || 'all';

  const filtered = savedResults.filter((item) => {
    if (activeCol === 'all') return true;
    return item.collectionId === activeCol;
  });

  return `
    <div class="saved-view">
      <!-- Section Header -->
      <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 16px;">
        <div>
          <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 4px;">
            <span class="badge badge-public">
              ${renderIcon('folder-heart', 'w-3 h-3', 12)} Research Dossiers
            </span>
          </div>
          <h2 style="font-size: 1.8rem;">Saved Results & Collections</h2>
          <p style="font-size: 0.95rem; color: var(--text-secondary);">
            Organize public findings into structured collections, add notes, and export verification reports.
          </p>
        </div>

        ${
          savedResults.length > 0
            ? `
          <div style="display: flex; gap: 10px;">
            <button class="btn btn-secondary btn-sm" id="export-saved-csv-btn">
              ${renderIcon('download', 'w-4 h-4', 16)} Export CSV
            </button>
            <button class="btn btn-outline btn-sm" id="export-saved-json-btn">
              ${renderIcon('download', 'w-4 h-4', 16)} Export JSON
            </button>
          </div>
        `
            : ''
        }
      </div>

      <!-- Collection Filter Pills -->
      <div style="display: flex; gap: 8px; overflow-x: auto; padding-bottom: 4px;">
        ${collections
          .map((col) => {
            const count =
              col.id === 'all'
                ? savedResults.length
                : savedResults.filter((s) => s.collectionId === col.id).length;
            const isActive = activeCol === col.id;

            return `
            <button class="btn btn-secondary btn-sm ${isActive ? 'btn-primary' : ''}" data-collection-id="${col.id}" style="border-radius: var(--radius-full); font-size: 0.8rem;">
              <span>${col.name}</span>
              <span class="badge" style="background: rgba(255, 255, 255, 0.12); padding: 1px 6px; font-size: 0.68rem;">
                ${count}
              </span>
            </button>
          `;
          })
          .join('')}
      </div>

      <!-- Saved Items Grid -->
      ${
        filtered.length === 0
          ? `
          <div class="glass-panel" style="text-align: center; padding: 64px 24px;">
            <div style="color: var(--text-muted); margin-bottom: 14px;">
              ${renderIcon('bookmark', 'w-12 h-12', 48)}
            </div>
            <h3 style="font-size: 1.25rem; margin-bottom: 6px;">
              No saved items in this collection
            </h3>
            <p style="font-size: 0.9rem; color: var(--text-muted); max-width: 440px; margin: 0 auto 20px;">
              You can bookmark any result during a search to save its public domain, similarity score, and context.
            </p>
            <button class="btn btn-primary" id="saved-new-search-cta">
              ${renderIcon('search', 'w-4 h-4', 16)} Search the Public Web
            </button>
          </div>
        `
          : `
          <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(340px, 1fr)); gap: 20px;">
            ${filtered
              .map(
                (item) => `
              <div class="result-card" data-saved-card-id="${item.id}">
                <div class="result-card-media" style="aspect-ratio: 16 / 9;">
                  <img src="${item.image}" alt="${item.title}" />
                  <div class="result-similarity-pill badge-similarity-high">
                    ${item.similarity}% Similarity
                  </div>
                  <span class="result-type-tag">${item.category}</span>
                </div>

                <div class="result-card-body">
                  <div class="result-domain-row">
                    <span style="font-weight: 600; color: var(--text-primary);">${item.domain}</span>
                    <span>${item.savedAt}</span>
                  </div>

                  <h3 class="result-card-title" title="${item.title}">
                    ${item.title}
                  </h3>

                  <!-- Interactive Notes Field -->
                  <div style="background: var(--bg-tertiary); padding: 10px 12px; border-radius: var(--radius-sm); border: 1px solid var(--border-subtle); margin-top: 4px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px;">
                      <span style="font-size: 0.72rem; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">
                        Researcher Notes
                      </span>
                      <button class="btn btn-ghost btn-sm edit-note-btn" data-saved-id="${item.id}" style="padding: 0 4px; font-size: 0.72rem; color: var(--primary);">
                        Edit
                      </button>
                    </div>
                    <p style="font-size: 0.8rem; color: var(--text-secondary); line-height: 1.4;">
                      ${item.notes || 'No annotations added yet.'}
                    </p>
                  </div>
                </div>

                <div class="result-card-footer">
                  <button class="btn btn-secondary btn-sm inspect-saved-btn" data-saved-id="${item.id}">
                    ${renderIcon('git-compare', 'w-3.5 h-3.5', 14)} Inspect Details
                  </button>

                  <div style="display: flex; gap: 6px;">
                    <a href="${item.url}" target="_blank" rel="noopener noreferrer" class="btn btn-ghost btn-sm" title="Open source">
                      ${renderIcon('external-link', 'w-3.5 h-3.5', 14)}
                    </a>
                    <button class="btn btn-ghost btn-sm delete-saved-btn" data-saved-id="${item.id}" title="Remove from saved" style="color: var(--accent-rose);">
                      ${renderIcon('trash', 'w-3.5 h-3.5', 14)}
                    </button>
                  </div>
                </div>
              </div>
            `
              )
              .join('')}
          </div>
        `
      }
    </div>
  `;
}

export function attachSavedResultsEvents() {
  // Collection Filter Buttons
  const colBtns = document.querySelectorAll('button[data-collection-id]');
  colBtns.forEach((btn) => {
    btn.addEventListener('click', (e) => {
      const colId = e.currentTarget.getAttribute('data-collection-id');
      store.state.activeCollectionFilter = colId;
      store.notify();
    });
  });

  const searchCta = document.getElementById('saved-new-search-cta');
  if (searchCta) {
    searchCta.addEventListener('click', () => {
      store.setDashboardTab('search');
    });
  }

  // Inspect details button
  const inspectBtns = document.querySelectorAll('.inspect-saved-btn');
  inspectBtns.forEach((btn) => {
    btn.addEventListener('click', (e) => {
      const id = e.currentTarget.getAttribute('data-saved-id');
      const item = store.state.savedResults.find((s) => s.id === id);
      if (item) {
        store.openResultDetail(item);
      }
    });
  });

  // Edit note button
  const editNoteBtns = document.querySelectorAll('.edit-note-btn');
  editNoteBtns.forEach((btn) => {
    btn.addEventListener('click', (e) => {
      const id = e.currentTarget.getAttribute('data-saved-id');
      const item = store.state.savedResults.find((s) => s.id === id);
      if (item) {
        const newNotes = prompt('Edit your notes for this saved result:', item.notes || '');
        if (newNotes !== null) {
          store.updateSavedItemNotes(id, newNotes);
        }
      }
    });
  });

  // Delete saved button
  const deleteBtns = document.querySelectorAll('.delete-saved-btn');
  deleteBtns.forEach((btn) => {
    btn.addEventListener('click', (e) => {
      const id = e.currentTarget.getAttribute('data-saved-id');
      if (confirm('Remove this result from your saved items?')) {
        store.removeSavedResult(id);
      }
    });
  });

  // Export JSON
  const jsonBtn = document.getElementById('export-saved-json-btn');
  if (jsonBtn) {
    jsonBtn.addEventListener('click', () => {
      const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(store.state.savedResults, null, 2));
      triggerDownload(dataStr, `digital_your_saved_${Date.now()}.json`);
    });
  }

  // Export CSV
  const csvBtn = document.getElementById('export-saved-csv-btn');
  if (csvBtn) {
    csvBtn.addEventListener('click', () => {
      const headers = ['Title', 'Domain', 'Category', 'Similarity', 'URL', 'SavedAt', 'Notes'];
      const rows = store.state.savedResults.map((s) => [
        `"${(s.title || '').replace(/"/g, '""')}"`,
        `"${s.domain || ''}"`,
        `"${s.category || ''}"`,
        `"${s.similarity}%"`,
        `"${s.url || ''}"`,
        `"${s.savedAt || ''}"`,
        `"${(s.notes || '').replace(/"/g, '""')}"`
      ]);
      const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
      triggerDownload(csvContent, `digital_your_saved_${Date.now()}.csv`);
    });
  }
}

function triggerDownload(contentUri, fileName) {
  const downloadAnchor = document.createElement('a');
  downloadAnchor.setAttribute('href', contentUri);
  downloadAnchor.setAttribute('download', fileName);
  document.body.appendChild(downloadAnchor);
  downloadAnchor.click();
  downloadAnchor.remove();
  store.showToast('Export downloaded successfully.', 'success');
}
