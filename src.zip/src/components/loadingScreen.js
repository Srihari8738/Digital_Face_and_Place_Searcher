// src/components/loadingScreen.js
// 1-Second minimal AI initialization screen for quiet luxury experience

export function renderLoadingScreen() {
  if (typeof window !== 'undefined' && sessionStorage.getItem('dy_initialized')) {
    return '';
  }

  return `
    <div class="dy-init-overlay" id="dy-init-overlay">
      <div class="dy-init-content">
        <div class="dy-init-logo">
          <div class="dy-init-symbol">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <path d="M6 3h6a6 6 0 0 1 6 6v6a6 6 0 0 1-6 6H6V3z"/>
              <path d="M12 9v6" stroke="rgba(255,255,255,0.7)" stroke-width="2"/>
            </svg>
          </div>
          <span class="dy-init-brand-text">DIGITAL YOUR</span>
        </div>
        <span class="dy-init-tagline">Initializing vision intelligence...</span>
        <div class="dy-init-progress-track">
          <div class="dy-init-progress-bar"></div>
        </div>
      </div>
    </div>
  `;
}

export function initLoadingScreenTransition() {
  const overlay = document.getElementById('dy-init-overlay');
  if (!overlay) return;

  if (sessionStorage.getItem('dy_initialized')) {
    overlay.classList.add('dy-fade-out');
    setTimeout(() => overlay.remove(), 400);
    return;
  }

  setTimeout(() => {
    overlay.classList.add('dy-fade-out');
    sessionStorage.setItem('dy_initialized', 'true');
    setTimeout(() => {
      if (overlay && overlay.parentNode) {
        overlay.parentNode.removeChild(overlay);
      }
    }, 650);
  }, 1000);
}
