// src/components/resultDetailsModal.js
// Result details modal with side-by-side view, interactive split-overlay comparison slider, zoom controls,
// source quality indicator, feature matching explanation, and research dossier actions

import { store } from '../state.js';
import { renderIcon } from '../utils/icons.js';

export function renderResultDetailsModal() {
  const { currentSearch, savedResults, collections } = store.state;
  const res = currentSearch.activeResultDetail;
  if (!res) return '';

  const isSaved = savedResults.some((s) => s.resultId === res.id);
  const comparisonMode = currentSearch.comparisonMode || 'split';
  const zoomLevel = currentSearch.zoomLevel || 100;
  const sliderPos = currentSearch.comparisonSliderPos ?? 50;
  const originalImg = currentSearch.imageSrc || res.image;

  // Source quality badge styling
  let qualityBadgeClass = 'badge-public';
  let qualityLabel = res.sourceQualityLabel || 'Reputable publication';
  if (res.sourceQuality === 'official') {
    qualityBadgeClass = 'badge-similarity-high';
    qualityLabel = 'Official source';
  } else if (res.sourceQuality === 'reference') {
    qualityBadgeClass = 'badge-public';
    qualityLabel = 'Public reference database';
  } else if (res.sourceQuality === 'user-generated') {
    qualityBadgeClass = 'badge-demo';
    qualityLabel = 'User-generated page';
  }

  const platformName = res.sourceWebsite || res.domain;

  return `
    <div class="modal-backdrop" id="detail-modal-backdrop">
      <div class="modal-dialog modal-wide" id="detail-modal-dialog">
        <!-- Modal Header -->
        <div class="modal-header">
          <div style="display: flex; align-items: center; gap: 12px; min-width: 0;">
            <div class="nav-logo-icon" style="width: 36px; height: 36px; flex-shrink: 0;">
              ${renderIcon('git-compare', 'w-4 h-4', 20)}
            </div>
            <div style="min-width: 0;">
              <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 2px; flex-wrap: wrap;">
                <span class="badge ${qualityBadgeClass}" style="font-size: 0.72rem; font-weight: 700;">
                  ${qualityLabel}
                </span>
                ${
                  res.matchType === 'exact' || res.similarity === 100
                    ? `
                    <span class="badge badge-similarity-high" style="font-size: 0.75rem; font-weight: 800; background: var(--accent-emerald); color: white; display: inline-flex; align-items: center; gap: 4px;">
                      ${renderIcon('check-circle', 'w-3.5 h-3.5', 12)} Exact Match: 100% Verified
                    </span>
                    <span class="badge" style="background: rgba(16, 185, 129, 0.12); color: #059669; font-size: 0.72rem; font-weight: 700; border: 1px solid rgba(16, 185, 129, 0.25);">
                      0 bit distance • Bitwise Duplicate
                    </span>
                    `
                    : `
                    <span class="badge ${res.matchType === 'exact' ? 'badge-similarity-high' : 'badge-demo'}" style="font-size: 0.72rem;">
                      ${res.matchLabel || 'Visual Match'}
                    </span>
                    <span class="badge badge-public" style="font-size: 0.68rem;">
                      Similarity: ${res.similarity}%
                    </span>
                    `
                }
              </div>
              <h3 style="font-size: 1.15rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin: 0;">
                ${res.title}
              </h3>
            </div>
          </div>

          <button class="btn btn-ghost btn-sm" id="detail-modal-close-btn" aria-label="Close details">
            ${renderIcon('x', 'w-5 h-5', 20)}
          </button>
        </div>

        <!-- Modal Body -->
        <div class="modal-body" style="display: flex; flex-direction: column; gap: 24px;">
          <!-- Viewport Inspection Controls Bar -->
          <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px; padding-bottom: 12px; border-bottom: 1px solid var(--border-subtle);">
            <div style="display: flex; align-items: center; gap: 8px;">
              <span style="font-size: 0.8rem; font-weight: 700; color: var(--text-muted);">Inspection Mode:</span>
              <div style="display: flex; background: var(--bg-tertiary); padding: 3px; border-radius: var(--radius-sm); border: 1px solid var(--border-subtle);">
                <button class="btn btn-ghost btn-sm ${comparisonMode === 'split' ? 'active' : ''}" id="mode-split-btn" style="${comparisonMode === 'split' ? 'background: var(--bg-secondary); color: var(--text-primary);' : ''}">
                  ${renderIcon('sliders', 'w-3.5 h-3.5', 14)} Overlay Split Slider
                </button>
                <button class="btn btn-ghost btn-sm ${comparisonMode === 'side' ? 'active' : ''}" id="mode-side-btn" style="${comparisonMode === 'side' ? 'background: var(--bg-secondary); color: var(--text-primary);' : ''}">
                  ${renderIcon('grid', 'w-3.5 h-3.5', 14)} Side-by-Side
                </button>
              </div>
            </div>

            <div style="display: flex; align-items: center; gap: 8px;">
              <span style="font-size: 0.8rem; font-weight: 700; color: var(--text-muted);">Magnification:</span>
              <div style="display: flex; gap: 4px;">
                <button class="btn btn-secondary btn-sm zoom-btn ${zoomLevel === 100 ? 'active' : ''}" data-zoom="100">100%</button>
                <button class="btn btn-secondary btn-sm zoom-btn ${zoomLevel === 150 ? 'active' : ''}" data-zoom="150">150%</button>
                <button class="btn btn-secondary btn-sm zoom-btn ${zoomLevel === 200 ? 'active' : ''}" data-zoom="200">200%</button>
              </div>
            </div>
          </div>

          <!-- Comparison Viewport -->
          ${
            comparisonMode === 'split'
              ? `
              <div class="comparison-container">
                <div class="comparison-viewport" id="interactive-comparison-viewport">
                  <!-- Base Layer: Found Match Image -->
                  <div class="comparison-img-layer" style="transform: scale(${zoomLevel / 100}); transform-origin: center;">
                    <img src="${res.image}" alt="Found Public Match Image" />
                  </div>

                  <!-- Overlay Layer: Query Upload Image (Clipped) -->
                  <div class="comparison-img-layer query-layer" id="comparison-query-layer" style="width: ${sliderPos}%; transform: scale(${zoomLevel / 100}); transform-origin: center;">
                    <img src="${originalImg}" alt="Uploaded Query Image" style="width: 100%; height: 100%; object-fit: contain;" />
                  </div>

                  <!-- Draggable Divider Line & Knob -->
                  <div class="comparison-divider-line" id="comparison-divider" style="left: ${sliderPos}%;">
                    <div class="comparison-handle-knob">
                      ${renderIcon('git-compare', 'w-4 h-4', 16)}
                    </div>
                  </div>

                  <!-- Overlay Corner Badges -->
                  <div style="position: absolute; bottom: 12px; left: 16px; z-index: 15; background: rgba(0,0,0,0.75); backdrop-filter: blur(8px); padding: 4px 10px; border-radius: 4px; font-size: 0.72rem; font-weight: 700; color: #fff;">
                    Uploaded Query (${currentSearch.selectedRegion?.label || 'Entire Image'})
                  </div>
                  <div style="position: absolute; bottom: 12px; right: 16px; z-index: 15; background: rgba(0,0,0,0.75); backdrop-filter: blur(8px); padding: 4px 10px; border-radius: 4px; font-size: 0.72rem; font-weight: 700; color: #fff;">
                    Found Public Match (${res.domain})
                  </div>
                </div>
                <p style="font-size: 0.75rem; color: var(--text-muted); text-align: center; margin-top: 8px;">
                  Drag slider handle horizontally to cross-examine fine edge alignment, artifacts, and color grading.
                </p>
              </div>
            `
              : `
              <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                <!-- Left: Query Image -->
                <div style="display: flex; flex-direction: column; gap: 8px;">
                  <span style="font-size: 0.8rem; font-weight: 700; color: var(--text-secondary);">
                    Uploaded Query (${currentSearch.selectedRegion?.label || 'Entire Image'})
                  </span>
                  <div style="aspect-ratio: 4/3; background: #000; border-radius: var(--radius-md); overflow: hidden; border: 1px solid var(--border-subtle);">
                    <img src="${originalImg}" alt="Query image" style="width: 100%; height: 100%; object-fit: contain; transform: scale(${zoomLevel / 100}); transform-origin: center;" />
                  </div>
                </div>

                <!-- Right: Found Image -->
                <div style="display: flex; flex-direction: column; gap: 8px;">
                  <span style="font-size: 0.8rem; font-weight: 700; color: var(--text-secondary);">
                    Found Public Match (${res.domain})
                  </span>
                  <div style="aspect-ratio: 4/3; background: #000; border-radius: var(--radius-md); overflow: hidden; border: 1px solid var(--border-subtle);">
                    <img src="${res.image}" alt="Found web image" style="width: 100%; height: 100%; object-fit: contain; transform: scale(${zoomLevel / 100}); transform-origin: center;" />
                  </div>
                </div>
              </div>
            `
          }

          <!-- Matching Features Explanation & Differences -->
          <div style="background: var(--bg-tertiary); padding: 18px; border-radius: var(--radius-md); border: 1px solid var(--border-subtle);">
            <h4 style="font-size: 0.88rem; font-weight: 700; margin-bottom: 8px;">Feature Matching & Verification Notes:</h4>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 12px; font-size: 0.825rem;">
              <div>
                <span style="color: var(--text-muted); font-weight: 600; display: block;">Matching Visual Regions:</span>
                <span style="color: var(--text-primary);">${res.matchingRegions || 'Spatial keypoint coordinates and high-frequency edge gradients match closely.'}</span>
              </div>
              <div>
                <span style="color: var(--text-muted); font-weight: 600; display: block;">Differences Detected:</span>
                <span style="color: ${res.matchType === 'exact' ? '#047857' : 'var(--accent-amber)'}; font-weight: 600;">
                  ${res.matchType === 'exact' ? 'None. 0 bit distance (Exact bitwise & perceptual duplicate of master image).' : (res.differences || 'None. Image hash comparison indicates an identical source asset.')}
                </span>
              </div>
            </div>
          </div>

          <!-- Metadata Dossier -->
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 14px; background: var(--bg-tertiary); padding: 18px; border-radius: var(--radius-md); border: 1px solid var(--border-subtle);">
            <div>
              <span style="font-size: 0.72rem; color: var(--text-muted); font-weight: 700; text-transform: uppercase;">Source Platform</span>
              <p style="font-size: 0.95rem; font-weight: 700; margin-top: 2px; color: var(--text-primary);">${platformName}</p>
            </div>
            <div>
              <span style="font-size: 0.72rem; color: var(--text-muted); font-weight: 700; text-transform: uppercase;">Published Date</span>
              <p style="font-size: 0.95rem; font-weight: 600; margin-top: 2px;">${res.firstPublished || 'Open Web Archive'}</p>
            </div>
            <div>
              <span style="font-size: 0.72rem; color: var(--text-muted); font-weight: 700; text-transform: uppercase;">Last Seen by Crawler</span>
              <p style="font-size: 0.95rem; font-weight: 600; margin-top: 2px; color: var(--accent-cyan);">${res.lastSeen || 'Indexed recently'}</p>
            </div>
            <div>
              <span style="font-size: 0.72rem; color: var(--text-muted); font-weight: 700; text-transform: uppercase;">Match Confidence</span>
              <p style="font-size: 0.95rem; font-weight: 800; margin-top: 2px; color: var(--accent-emerald);">
                ${res.matchType === 'exact' || res.similarity === 100 ? '100% Exact Bitwise Match' : `${res.similarity}% Structural Fit`}
              </p>
            </div>
          </div>

          <!-- URLs Dossier -->
          <div style="display: flex; flex-direction: column; gap: 8px; font-size: 0.78rem;">
            <div style="display: flex; gap: 10px; align-items: center; background: var(--bg-tertiary); padding: 8px 12px; border-radius: var(--radius-sm); border: 1px solid var(--border-subtle);">
              <span style="font-weight: 700; color: var(--text-muted); width: 80px; flex-shrink: 0;">Page URL:</span>
              <a href="${res.url}" target="_blank" rel="noopener noreferrer" style="color: var(--primary); text-decoration: underline; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; flex: 1;">
                ${res.url}
              </a>
            </div>
            ${
              res.imageUrl
                ? `
              <div style="display: flex; gap: 10px; align-items: center; background: var(--bg-tertiary); padding: 8px 12px; border-radius: var(--radius-sm); border: 1px solid var(--border-subtle);">
                <span style="font-weight: 700; color: var(--text-muted); width: 80px; flex-shrink: 0;">Image URL:</span>
                <a href="${res.imageUrl}" target="_blank" rel="noopener noreferrer" style="color: var(--text-muted); text-decoration: underline; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; flex: 1;">
                  ${res.imageUrl}
                </a>
              </div>
            `
                : ''
            }
          </div>

          <!-- Add to Collection Selector -->
          <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px; padding: 14px; background: var(--bg-tertiary); border-radius: var(--radius-md); border: 1px solid var(--border-subtle);">
            <div style="display: flex; align-items: center; gap: 10px;">
              ${renderIcon('folder-heart', 'w-4 h-4', 18)}
              <span style="font-size: 0.85rem; font-weight: 700;">Save Finding to Collection:</span>
            </div>
            <div style="display: flex; gap: 8px;">
              <select id="detail-collection-select" style="padding: 6px 12px; font-size: 0.825rem; background: var(--bg-secondary); border: 1px solid var(--border-subtle); color: var(--text-primary); border-radius: var(--radius-sm);">
                ${collections
                  .map(
                    (c) => `<option value="${c.id}">${c.name}</option>`
                  )
                  .join('')}
              </select>
              <button class="btn btn-primary btn-sm" id="detail-save-btn">
                ${renderIcon(isSaved ? 'bookmark-check' : 'bookmark', 'w-3.5 h-3.5', 14)}
                ${isSaved ? 'Saved' : 'Save Finding'}
              </button>
            </div>
          </div>

          <!-- Responsible Use Notice -->
          <div style="background: rgba(245, 158, 11, 0.08); border: 1px solid rgba(245, 158, 11, 0.25); border-radius: var(--radius-md); padding: 12px 16px; display: flex; gap: 10px; align-items: flex-start;">
            <div style="color: var(--accent-amber); margin-top: 1px;">
              ${renderIcon('shield', 'w-4 h-4', 16)}
            </div>
            <p style="font-size: 0.78rem; color: var(--text-secondary); line-height: 1.45; margin: 0;">
              <strong>Notice:</strong> Visual similarity is an estimate and does not prove identity, ownership, authorship, or association. DIGITAL YOUR searches publicly indexed and connected sources only.
            </p>
          </div>
        </div>

        <!-- Modal Footer -->
        <div class="modal-footer">
          <button class="btn btn-ghost btn-sm" id="detail-report-btn" style="color: var(--accent-rose);">
            ${renderIcon('flag', 'w-3.5 h-3.5', 14)} Report Incorrect Result
          </button>
          <a href="${res.url}" target="_blank" rel="noopener noreferrer" class="btn btn-secondary btn-sm" style="display: inline-flex; align-items: center; gap: 6px;">
            ${renderIcon('external-link', 'w-3.5 h-3.5', 14)} Open Source Page
          </a>
          <button class="btn btn-primary btn-sm" id="detail-done-btn">
            Done
          </button>
        </div>
      </div>
    </div>
  `;
}

export function attachResultDetailsEvents() {
  const closeBtn = document.getElementById('detail-modal-close-btn');
  const doneBtn = document.getElementById('detail-done-btn');
  if (closeBtn) closeBtn.addEventListener('click', () => store.closeModal());
  if (doneBtn) doneBtn.addEventListener('click', () => store.closeModal());

  const backdrop = document.getElementById('detail-modal-backdrop');
  if (backdrop) {
    backdrop.addEventListener('click', (e) => {
      if (e.target === backdrop) store.closeModal();
    });
  }

  // Comparison Mode Toggles
  const splitBtn = document.getElementById('mode-split-btn');
  const sideBtn = document.getElementById('mode-side-btn');
  if (splitBtn) splitBtn.addEventListener('click', () => store.setComparisonMode('split'));
  if (sideBtn) sideBtn.addEventListener('click', () => store.setComparisonMode('side'));

  // Zoom Level Toggles
  const zoomBtns = document.querySelectorAll('.zoom-btn');
  zoomBtns.forEach((btn) => {
    btn.addEventListener('click', (e) => {
      const zoom = parseInt(e.currentTarget.getAttribute('data-zoom'), 10);
      store.setZoomLevel(zoom);
    });
  });

  // Interactive Split Slider Mouse & Touch Handling
  const viewport = document.getElementById('interactive-comparison-viewport');
  const divider = document.getElementById('comparison-divider');
  const queryLayer = document.getElementById('comparison-query-layer');

  if (viewport && divider && queryLayer) {
    let isDragging = false;

    const updateSlider = (clientX) => {
      const rect = viewport.getBoundingClientRect();
      const x = clientX - rect.left;
      const percentage = Math.max(0, Math.min(100, (x / rect.width) * 100));
      divider.style.left = `${percentage}%`;
      queryLayer.style.width = `${percentage}%`;
      store.state.currentSearch.comparisonSliderPos = percentage;
    };

    divider.addEventListener('mousedown', () => {
      isDragging = true;
    });

    window.addEventListener('mousemove', (e) => {
      if (!isDragging) return;
      updateSlider(e.clientX);
    });

    window.addEventListener('mouseup', () => {
      isDragging = false;
    });

    // Touch events for mobile/tablet
    divider.addEventListener('touchstart', () => {
      isDragging = true;
    });

    window.addEventListener('touchmove', (e) => {
      if (!isDragging || !e.touches[0]) return;
      updateSlider(e.touches[0].clientX);
    });

    window.addEventListener('touchend', () => {
      isDragging = false;
    });
  }

  // Save to collection button
  const saveBtn = document.getElementById('detail-save-btn');
  const collectionSelect = document.getElementById('detail-collection-select');
  if (saveBtn) {
    saveBtn.addEventListener('click', () => {
      const res = store.state.currentSearch.activeResultDetail;
      if (res) {
        store.saveResult(res, collectionSelect ? collectionSelect.value : 'all');
      }
    });
  }

  // Report incorrect result action
  const reportBtn = document.getElementById('detail-report-btn');
  if (reportBtn) {
    reportBtn.addEventListener('click', () => {
      const res = store.state.currentSearch.activeResultDetail;
      store.openModal('report', res);
    });
  }
}
