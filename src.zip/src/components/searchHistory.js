// src/components/searchHistory.js
// ChatGPT-style search history view with rename, delete, filter, and purge actions

import { store } from '../state.js';
import { renderIcon } from '../utils/icons.js';

export function renderSearchHistory() {
  const { searchHistory, historyQuery } = store.state;
  const filtered = searchHistory.filter((item) => {
    if (!historyQuery) return true;
    return (
      item.name.toLowerCase().includes(historyQuery.toLowerCase()) ||
      item.selectedRegionLabel?.toLowerCase().includes(historyQuery.toLowerCase())
    );
  });

  return `
    <div class="history-view">
      <!-- Section Header -->
      <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 16px;">
        <div>
          <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 4px;">
            <span class="badge badge-privacy">
              ${renderIcon('shield-check', 'w-3 h-3', 12)} Local History Only
            </span>
          </div>
          <h2 style="font-size: 1.8rem;">Search History</h2>
          <p style="font-size: 0.95rem; color: var(--text-secondary);">
            Review, reopen, rename, or permanently erase your past public discovery queries.
          </p>
        </div>

        ${
          searchHistory.length > 0
            ? `
          <button class="btn btn-danger btn-sm" id="history-clear-all-btn">
            ${renderIcon('trash', 'w-4 h-4', 16)} Clear All History
          </button>
        `
            : ''
        }
      </div>

      <!-- Search & Filter Bar -->
      <div style="display: flex; align-items: center; gap: 14px; background: var(--bg-glass); padding: 12px 18px; border-radius: var(--radius-lg); border: 1px solid var(--border-subtle);">
        ${renderIcon('search', 'w-4 h-4', 18)}
        <input 
          type="text" 
          id="history-search-input" 
          placeholder="Filter history by search title or focus..." 
          value="${historyQuery || ''}" 
          style="flex: 1; background: transparent; border: none; padding: 0; box-shadow: none;"
        />
        ${
          historyQuery
            ? `
          <button class="btn btn-ghost btn-sm" id="clear-history-query-btn">
            ${renderIcon('x', 'w-3.5 h-3.5', 14)}
          </button>
        `
            : ''
        }
      </div>

      <!-- History List -->
      ${
        filtered.length === 0
          ? `
          <div class="glass-panel" style="text-align: center; padding: 64px 24px;">
            <div style="color: var(--text-muted); margin-bottom: 14px;">
              ${renderIcon('history', 'w-12 h-12', 48)}
            </div>
            <h3 style="font-size: 1.25rem; margin-bottom: 6px;">
              ${searchHistory.length === 0 ? 'No search history yet' : 'No matching searches found'}
            </h3>
            <p style="font-size: 0.9rem; color: var(--text-muted); max-width: 440px; margin: 0 auto 20px;">
              ${
                searchHistory.length === 0
                  ? 'Completed reverse image searches will be listed here with options to review findings or wipe records.'
                  : 'Try adjusting your search query filter above.'
              }
            </p>
            ${
              searchHistory.length === 0
                ? `
              <button class="btn btn-primary" id="history-start-first-btn">
                ${renderIcon('search', 'w-4 h-4', 16)} Start a New Search
              </button>
            `
                : ''
            }
          </div>
        `
          : `
          <div style="display: flex; flex-direction: column; gap: 12px;">
            ${filtered
              .map(
                (item) => `
              <div class="history-item-row" data-history-id="${item.id}">
                <div style="display: flex; align-items: center; gap: 16px; min-width: 0; flex: 1;">
                  <img src="${item.image}" alt="${item.name}" class="history-thumb" />
                  <div style="min-width: 0; flex: 1;">
                    <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
                      <h4 class="history-title-text" style="font-size: 0.98rem; font-weight: 700; color: var(--text-primary); white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                        ${item.name}
                      </h4>
                      ${
                        item.entityType === 'anime'
                          ? `<span class="badge badge-similarity-high" style="font-size: 0.65rem; padding: 2px 6px;">Anime Poster</span>`
                          : ''
                      }
                      <span class="badge badge-public" style="font-size: 0.65rem; padding: 2px 6px;">
                        ${item.status}
                      </span>
                    </div>

                    ${
                      item.characters && item.characters.length > 0
                        ? `
                      <div style="font-size: 0.75rem; color: var(--accent-cyan); margin-top: 2px;">
                        ${item.characters.map((c) => c.name).join(' · ')}
                      </div>
                    `
                        : ''
                    }

                    <div style="display: flex; align-items: center; gap: 12px; font-size: 0.78rem; color: var(--text-muted); margin-top: 4px; flex-wrap: wrap;">
                      <span>${item.date}</span>
                      <span>•</span>
                      <span style="color: var(--accent-cyan);">Focus: ${item.selectedRegionLabel || 'Full Image'}</span>
                      <span>•</span>
                      <span style="color: var(--accent-emerald); font-weight: 600;">${item.resultCount} public matches</span>
                    </div>
                  </div>
                </div>

                <div style="display: flex; align-items: center; gap: 8px;">
                  <button class="btn btn-primary btn-sm reopen-history-item-btn" data-history-id="${item.id}" title="Reopen Search Results">
                    ${renderIcon('arrow-right', 'w-3.5 h-3.5', 14)} Open
                  </button>
                  <button class="btn btn-ghost btn-sm rename-history-item-btn" data-history-id="${item.id}" title="Rename search">
                    ${renderIcon('edit', 'w-3.5 h-3.5', 14)}
                  </button>
                  <button class="btn btn-ghost btn-sm delete-history-item-btn" data-history-id="${item.id}" title="Delete this search" style="color: var(--accent-rose);">
                    ${renderIcon('trash', 'w-3.5 h-3.5', 14)}
                  </button>
                </div>
              </div>
            `
              )
              .join('')}
          </div>
        `
      }
    </div>
  `;
}

export function attachSearchHistoryEvents() {
  // Filter input
  const searchInput = document.getElementById('history-search-input');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      store.state.historyQuery = e.target.value;
      store.notify();
    });
  }

  const clearQueryBtn = document.getElementById('clear-history-query-btn');
  if (clearQueryBtn) {
    clearQueryBtn.addEventListener('click', () => {
      store.state.historyQuery = '';
      store.notify();
    });
  }

  const startFirstBtn = document.getElementById('history-start-first-btn');
  if (startFirstBtn) {
    startFirstBtn.addEventListener('click', () => {
      store.setDashboardTab('search');
    });
  }

  // Clear All History Button
  const clearAllBtn = document.getElementById('history-clear-all-btn');
  if (clearAllBtn) {
    clearAllBtn.addEventListener('click', () => {
      store.openModal('clearHistory');
    });
  }

  // Reopen History Item
  const reopenBtns = document.querySelectorAll('.reopen-history-item-btn');
  reopenBtns.forEach((btn) => {
    btn.addEventListener('click', (e) => {
      const id = e.currentTarget.getAttribute('data-history-id');
      const item = store.state.searchHistory.find((h) => h.id === id);
      if (item) {
        store.openHistoryItem(item);
      }
    });
  });

  // Rename History Item
  const renameBtns = document.querySelectorAll('.rename-history-item-btn');
  renameBtns.forEach((btn) => {
    btn.addEventListener('click', (e) => {
      const id = e.currentTarget.getAttribute('data-history-id');
      const item = store.state.searchHistory.find((h) => h.id === id);
      if (item) {
        const newName = prompt('Enter a new name for this search query:', item.name);
        if (newName) {
          store.renameHistoryItem(id, newName);
        }
      }
    });
  });

  // Delete History Item
  const deleteBtns = document.querySelectorAll('.delete-history-item-btn');
  deleteBtns.forEach((btn) => {
    btn.addEventListener('click', (e) => {
      const id = e.currentTarget.getAttribute('data-history-id');
      if (confirm('Are you sure you want to delete this search from your history?')) {
        store.deleteHistoryItem(id);
      }
    });
  });
}
