// src/components/uploadSection.js
// Polished image upload, bounding-box visual analysis, multi-element visual region selection,
// preset category filters, and strict privacy-by-design disclaimers

import { store } from '../state.js';
import { renderIcon } from '../utils/icons.js';
import { SAMPLE_IMAGES } from '../data/mockData.js';

// Local UI state for preset tab filter
let activePresetTab = 'all'; // 'all', 'anime', 'public-figure', 'ordinary-person', 'no-match', 'stage-scene'

export function renderUploadSection() {
  const { currentSearch } = store.state;
  const hasImage = !!currentSearch.imageSrc;

  return `
    <div class="search-view">
      <!-- Section Header -->
      <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 16px; margin-bottom: 20px;">
        <div>
          <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 4px;">
            <span class="badge badge-demo">
              ${renderIcon('terminal', 'w-3 h-3', 12)} Public Index Prototype
            </span>
            <span class="badge badge-privacy">
              ${renderIcon('shield-check', 'w-3 h-3', 12)} Ephemeral Memory
            </span>
            ${
              store.state.geminiApiKey
                ? `
              <span class="badge badge-public" style="background: rgba(16, 185, 129, 0.15); color: #34d399; border-color: rgba(16, 185, 129, 0.3);">
                ${renderIcon('sparkles', 'w-3 h-3', 12)} Gemini Vision Active
              </span>
            `
                : `
              <span class="badge" style="background: rgba(139, 92, 246, 0.15); color: var(--accent-purple); border: 1px solid rgba(139, 92, 246, 0.3);">
                ${renderIcon('cpu', 'w-3 h-3', 12)} Neural Vision Core
              </span>
            `
            }
          </div>
          <h2 style="font-size: 1.8rem; font-weight: 800; color: var(--text-primary);">Visual Public Discovery</h2>
          <p style="font-size: 0.95rem; color: var(--text-secondary);">
            Searches publicly indexed and connected sources. Analyze visual content, discover media/characters, and verify public sources.
          </p>
        </div>

        ${
          hasImage
            ? `
          <div style="display: flex; gap: 10px;">
            <button class="btn btn-secondary btn-sm" id="upload-replace-btn">
              ${renderIcon('refresh', 'w-4 h-4', 16)} Replace Image
            </button>
            <button class="btn btn-ghost btn-sm" id="upload-remove-btn" style="color: var(--accent-rose);">
              ${renderIcon('trash', 'w-4 h-4', 16)} Remove
            </button>
          </div>
        `
            : ''
        }
      </div>

      ${
        !hasImage
          ? renderEmptyUploadState()
          : renderRegionAnalysisState(currentSearch)
      }
    </div>
  `;
}

function renderEmptyUploadState() {
  const filteredSamples = SAMPLE_IMAGES.filter((sample) => {
    if (activePresetTab === 'all') return true;
    if (activePresetTab === 'anime') return sample.category === 'anime';
    if (activePresetTab === 'public-figure') return sample.category === 'public-figure';
    if (activePresetTab === 'ordinary-person') return sample.category === 'ordinary-person';
    if (activePresetTab === 'no-match') return sample.category === 'no-match';
    if (activePresetTab === 'stage-scene') return sample.category === 'landmark';
    return true;
  });

  return `
    <div class="upload-card-wrapper">
      <!-- Drag & Drop Zone -->
      <div class="upload-dropzone" id="upload-dropzone" role="region" aria-label="Image drop zone">
        <div class="dropzone-icon">
          ${renderIcon('upload-cloud', 'w-8 h-8', 34)}
        </div>
        <h3 class="dropzone-title">Upload Image for Public Source Discovery</h3>
        <p class="dropzone-sub">
          Upload any anime poster, artwork, public keynote, product, or photograph (JPEG, PNG, WebP up to 15 MB).
        </p>
        <div style="display: flex; gap: 12px; align-items: center; justify-content: center; flex-wrap: wrap;">
          <button class="btn btn-primary" id="upload-browse-btn">
            ${renderIcon('file-image', 'w-4 h-4', 18)}
            Browse Image Files
          </button>
          <button class="btn btn-secondary btn-sm" id="toggle-gemini-config-btn" style="font-size: 0.8rem;">
            ${renderIcon('key', 'w-3.5 h-3.5', 14)}
            ${store.state.geminiApiKey ? 'Gemini 2.0 API Connected' : 'Optional Gemini API Key'}
          </button>
        </div>
        <input type="file" id="upload-file-input" accept="image/jpeg,image/png,image/webp" style="display: none;" />
      </div>

      <!-- Optional Gemini Vision Key Collapsible Drawer -->
      <div id="gemini-config-drawer" style="display: none; background: var(--bg-tertiary); border: 1px solid var(--border-subtle); border-radius: var(--radius-md); padding: 16px 20px; margin-top: 16px;">
        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px;">
          <div style="display: flex; align-items: center; gap: 8px;">
            ${renderIcon('sparkles', 'w-4 h-4', 16)}
            <span style="font-size: 0.9rem; font-weight: 700;">Live Google Gemini 2.0 Flash Multimodal Vision API</span>
          </div>
          <span class="badge badge-demo" style="font-size: 0.7rem;">Optional Integration</span>
        </div>
        <p style="font-size: 0.8rem; color: var(--text-secondary); margin-bottom: 12px; line-height: 1.45;">
          Provide an optional Gemini API key to run real-time multimodal intelligence on custom uploads. (If empty, the built-in offline neural engine will classify anime, public figures, and scenes).
        </p>
        <div style="display: flex; gap: 10px;">
          <input 
            type="password" 
            id="gemini-api-key-input" 
            placeholder="AIzaSy... (Stored locally in session)" 
            value="${store.state.geminiApiKey || ''}" 
            style="flex: 1; padding: 8px 14px; font-size: 0.85rem; border-radius: var(--radius-sm); background: var(--bg-primary); border: 1px solid var(--border-subtle); color: var(--text-primary);"
          />
          <button class="btn btn-primary btn-sm" id="save-gemini-key-btn">
            Save Key
          </button>
          ${
            store.state.geminiApiKey
              ? `<button class="btn btn-ghost btn-sm" id="clear-gemini-key-btn" style="color: var(--accent-rose);">Clear</button>`
              : ''
          }
        </div>
      </div>

      <!-- Quick 1-Click Curated Testing Presets -->
      <div class="sample-presets-wrap" style="margin-top: 28px;">
        <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px; margin-bottom: 14px;">
          <div>
            <span class="sample-presets-title" style="margin-bottom: 2px; font-weight: 800;">
              Instant Demonstration Scenarios:
            </span>
            <p style="font-size: 0.8rem; color: var(--text-muted); margin: 0;">
              Click any scenario to evaluate specific capabilities (Anime Posters, Public Figures, Strict Privacy Guardrail, or No Match).
            </p>
          </div>

          <!-- Preset Category Filter Tabs -->
          <div style="display: flex; background: var(--bg-tertiary); padding: 3px; border-radius: var(--radius-md); border: 1px solid var(--border-subtle); gap: 2px; flex-wrap: wrap;">
            <button class="btn btn-ghost btn-sm preset-filter-tab ${activePresetTab === 'all' ? 'active' : ''}" data-tab="all" style="font-size: 0.75rem; padding: 4px 8px;">
              All (${SAMPLE_IMAGES.length})
            </button>
            <button class="btn btn-ghost btn-sm preset-filter-tab ${activePresetTab === 'anime' ? 'active' : ''}" data-tab="anime" style="font-size: 0.75rem; padding: 4px 8px;">
              ✨ Anime (${SAMPLE_IMAGES.filter(s => s.category === 'anime').length})
            </button>
            <button class="btn btn-ghost btn-sm preset-filter-tab ${activePresetTab === 'public-figure' ? 'active' : ''}" data-tab="public-figure" style="font-size: 0.75rem; padding: 4px 8px;">
              👤 Public Figures (${SAMPLE_IMAGES.filter(s => s.category === 'public-figure').length})
            </button>
            <button class="btn btn-ghost btn-sm preset-filter-tab ${activePresetTab === 'ordinary-person' ? 'active' : ''}" data-tab="ordinary-person" style="font-size: 0.75rem; padding: 4px 8px;">
              🛡️ Ordinary Person (${SAMPLE_IMAGES.filter(s => s.category === 'ordinary-person').length})
            </button>
            <button class="btn btn-ghost btn-sm preset-filter-tab ${activePresetTab === 'no-match' ? 'active' : ''}" data-tab="no-match" style="font-size: 0.75rem; padding: 4px 8px;">
              🔍 No Match Demo (${SAMPLE_IMAGES.filter(s => s.category === 'no-match').length})
            </button>
          </div>
        </div>

        <!-- Presets Grid -->
        <div class="sample-presets-grid" style="grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 14px;">
          ${filteredSamples
            .map(
              (sample) => `
            <div class="preset-chip" data-sample-id="${sample.id}" style="padding: 14px; gap: 14px; align-items: flex-start; cursor: pointer; background: var(--bg-card); border: 1px solid var(--border-subtle); border-radius: var(--radius-md);">
              <img src="${sample.src}" alt="${sample.title}" style="width: 60px; height: 80px; object-fit: cover; border-radius: var(--radius-sm); border: 1px solid var(--border-subtle); flex-shrink: 0;" />
              <div style="flex: 1; min-width: 0;">
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 3px;">
                  <span class="badge ${sample.category === 'anime' ? 'badge-similarity-high' : sample.category === 'ordinary-person' ? 'badge-privacy' : 'badge-public'}" style="font-size: 0.65rem; padding: 1px 6px;">
                    ${sample.classification || 'Demo'}
                  </span>
                  <span style="font-size: 0.68rem; color: var(--text-muted);">${sample.dimensions}</span>
                </div>
                <div class="preset-chip-title" style="font-size: 0.92rem; font-weight: 800; color: var(--text-primary);">
                  ${sample.title}
                </div>
                <div class="preset-chip-sub" style="font-size: 0.78rem; color: var(--text-secondary); margin-top: 2px; line-height: 1.35;">
                  ${sample.subtitle}
                </div>
                <!-- Platform Footprint Chips -->
                <div style="display: flex; gap: 4px; flex-wrap: wrap; margin-top: 8px;">
                  ${
                    sample.category === 'anime'
                      ? `
                    <span style="font-size: 0.65rem; padding: 2px 5px; border-radius: 4px; background: rgba(255, 69, 0, 0.12); color: #fb923c; border: 1px solid rgba(255, 69, 0, 0.25);">Reddit</span>
                    <span style="font-size: 0.65rem; padding: 2px 5px; border-radius: 4px; background: rgba(29, 155, 240, 0.12); color: #38bdf8; border: 1px solid rgba(29, 155, 240, 0.25);">Twitter/X</span>
                    <span style="font-size: 0.65rem; padding: 2px 5px; border-radius: 4px; background: rgba(225, 48, 108, 0.12); color: #f43f5e; border: 1px solid rgba(225, 48, 108, 0.25);">Instagram</span>
                    <span style="font-size: 0.65rem; padding: 2px 5px; border-radius: 4px; background: rgba(16, 185, 129, 0.12); color: #34d399; border: 1px solid rgba(16, 185, 129, 0.25);">MAL / Crunchyroll</span>
                  `
                      : sample.category === 'ordinary-person'
                      ? `
                    <span style="font-size: 0.65rem; padding: 2px 6px; border-radius: 4px; background: rgba(16, 185, 129, 0.15); color: #34d399; border: 1px solid rgba(16, 185, 129, 0.3);">
                      Zero Profile Search (Strict Privacy)
                    </span>
                  `
                      : sample.category === 'no-match'
                      ? `
                    <span style="font-size: 0.65rem; padding: 2px 6px; border-radius: 4px; background: rgba(245, 158, 11, 0.15); color: #fbbf24; border: 1px solid rgba(245, 158, 11, 0.3);">
                      Zero Public Matches Demo
                    </span>
                  `
                      : sample.id === 'sample-elon'
                      ? `
                    <span style="font-size: 0.65rem; padding: 2px 5px; border-radius: 4px; background: rgba(37, 99, 235, 0.12); color: var(--primary); border: 1px solid rgba(37, 99, 235, 0.25);">SpaceX</span>
                    <span style="font-size: 0.65rem; padding: 2px 5px; border-radius: 4px; background: rgba(225, 29, 72, 0.12); color: #f43f5e; border: 1px solid rgba(225, 29, 72, 0.25);">Tesla</span>
                    <span style="font-size: 0.65rem; padding: 2px 5px; border-radius: 4px; background: rgba(15, 23, 42, 0.12); color: var(--text-primary); border: 1px solid var(--border-color);">𝕏 / Twitter</span>
                    <span style="font-size: 0.65rem; padding: 2px 5px; border-radius: 4px; background: rgba(16, 185, 129, 0.12); color: #34d399; border: 1px solid rgba(16, 185, 129, 0.25);">xAI · Neuralink</span>
                  `
                      : `
                    <span style="font-size: 0.65rem; padding: 2px 5px; border-radius: 4px; background: rgba(59, 130, 246, 0.12); color: #38bdf8; border: 1px solid rgba(59, 130, 246, 0.25);">Stanford HAI</span>
                    <span style="font-size: 0.65rem; padding: 2px 5px; border-radius: 4px; background: rgba(245, 158, 11, 0.12); color: #fbbf24; border: 1px solid rgba(245, 158, 11, 0.25);">IEEE</span>
                    <span style="font-size: 0.65rem; padding: 2px 5px; border-radius: 4px; background: rgba(10, 102, 194, 0.12); color: #60a5fa; border: 1px solid rgba(10, 102, 194, 0.25);">WIRED</span>
                  `
                  }
                </div>
              </div>
            </div>
          `
            )
            .join('')}
        </div>
      </div>

      <!-- Legal and Boundaries Notice -->
      <div style="background: rgba(59, 130, 246, 0.05); border: 1px solid rgba(59, 130, 246, 0.2); border-radius: var(--radius-md); padding: 16px 20px; display: flex; align-items: flex-start; gap: 14px; margin-top: 24px;">
        <div style="color: var(--primary); margin-top: 2px;">
          ${renderIcon('shield', 'w-5 h-5', 20)}
        </div>
        <div>
          <h4 style="font-size: 0.88rem; font-weight: 700; color: var(--text-primary); margin-bottom: 2px;">
            Search Boundary & Privacy Architecture
          </h4>
          <p style="font-size: 0.825rem; color: var(--text-secondary); line-height: 1.5; margin: 0;">
            Searches publicly indexed and connected sources. Results depend on source availability, indexing, regional access, and search-provider coverage. DIGITAL YOUR never accesses private social-media accounts, password-protected pages, restricted databases, private messages, or unauthorized personal records.
          </p>
        </div>
      </div>
    </div>
  `;
}

function renderRegionAnalysisState(currentSearch) {
  const { imageSrc, fileName, fileSize, dimensions, regions, selectedRegion, title, classification, entityType, mediaAnalysis, ordinaryPersonGuardrail } = currentSearch;

  return `
    <div class="upload-card-wrapper">
      <!-- File Metadata Header -->
      <div style="display: flex; align-items: center; justify-content: space-between; padding-bottom: 16px; border-bottom: 1px solid var(--border-subtle); flex-wrap: wrap; gap: 12px; margin-bottom: 20px;">
        <div style="display: flex; align-items: center; gap: 12px;">
          <div style="width: 40px; height: 40px; border-radius: var(--radius-md); background: var(--bg-tertiary); display: flex; align-items: center; justify-content: center; color: var(--accent-cyan);">
            ${renderIcon('file-image', 'w-5 h-5', 22)}
          </div>
          <div>
            <div style="display: flex; align-items: center; gap: 8px;">
              <h4 style="font-size: 1rem; font-weight: 800; color: var(--text-primary); margin: 0;">${title || fileName}</h4>
              <span class="badge badge-demo" style="font-size: 0.68rem;">${classification}</span>
            </div>
            <div style="display: flex; gap: 10px; font-size: 0.78rem; color: var(--text-muted); margin-top: 2px;">
              <span>${fileSize}</span>
              <span>•</span>
              <span>${dimensions}</span>
              <span>•</span>
              <span style="color: var(--accent-emerald); font-weight: 600;">Analysis Complete (${regions.length} visual regions isolated)</span>
            </div>
          </div>
        </div>

        <span class="badge badge-public">
          ${renderIcon('scan', 'w-3 h-3', 12)} Select Search Focus
        </span>
      </div>

      <!-- Quick Intelligence Preview Badge -->
      ${
        mediaAnalysis
          ? `
        <div style="background: rgba(59, 130, 246, 0.08); border: 1px solid var(--border-glow); border-radius: var(--radius-md); padding: 12px 18px; margin-bottom: 20px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px;">
          <div style="display: flex; align-items: center; gap: 8px;">
            <span class="badge badge-similarity-high" style="font-size: 0.72rem;">
              ${renderIcon('sparkles', 'w-3 h-3', 12)} Anime Recognition
            </span>
            <span style="font-size: 0.88rem; font-weight: 700; color: var(--text-primary);">${mediaAnalysis.title}</span>
          </div>
          <div style="font-size: 0.78rem; color: var(--text-secondary);">
            Roster: <strong>${mediaAnalysis.characters.map((c) => c.name).join(', ')}</strong>
          </div>
        </div>
      `
          : ordinaryPersonGuardrail?.active
          ? `
        <div style="background: rgba(16, 185, 129, 0.08); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: var(--radius-md); padding: 12px 18px; margin-bottom: 20px; display: flex; align-items: center; gap: 10px;">
          <div style="color: var(--accent-emerald);">
            ${renderIcon('shield-check', 'w-4 h-4', 18)}
          </div>
          <span style="font-size: 0.825rem; color: var(--text-secondary);">
            <strong>Strict Privacy Guardrail:</strong> Ordinary private subject detected. The system will provide non-identifying scene details and will not search personal profiles.
          </span>
        </div>
      `
          : ''
      }

      <!-- Main Layout: Viewport with Bounding Boxes & Multi-Region Selector List -->
      <div class="image-analysis-container">
        <!-- Left: Image Viewport with Bounding Boxes -->
        <div>
          <div class="analysis-viewport-card" id="analysis-viewport">
            <img src="${imageSrc}" alt="Uploaded preview" class="analysis-main-image" id="analysis-preview-img" />

            <!-- Interactive Bounding Boxes -->
            ${regions
              .filter((r) => r.type !== 'full')
              .map((reg) => {
                const isSelected = selectedRegion?.id === reg.id;
                return `
                <div 
                  class="detected-bounding-overlay ${isSelected ? 'selected' : ''}" 
                  data-region-id="${reg.id}"
                  style="top: ${reg.box.top}%; left: ${reg.box.left}%; width: ${reg.box.width}%; height: ${reg.box.height}%;"
                  title="Click to focus search on ${reg.label}"
                >
                  <span class="box-tag">${reg.label}</span>
                </div>
              `;
              })
              .join('')}
          </div>
          <p style="font-size: 0.75rem; color: var(--text-muted); margin-top: 8px; text-align: center;">
            Click directly on any bounding box on the image or choose from the list.
          </p>
        </div>

        <!-- Right: Multi-Element Region Selection List & Search Action -->
        <div class="analysis-panel">
          <div>
            <h3 style="font-size: 1.1rem; font-weight: 800; margin-bottom: 4px; color: var(--text-primary);">
              Select Visual Region
            </h3>
            <p style="font-size: 0.85rem; color: var(--text-secondary); margin: 0;">
              Choose which visual element or face to search across openly indexed public sources.
            </p>
          </div>

          <!-- Region List -->
          <div class="region-selector-list" style="display: flex; flex-direction: column; gap: 8px;">
            ${regions
              .map((reg) => {
                const isSelected = selectedRegion?.id === reg.id;
                return `
                <div class="region-item-card ${isSelected ? 'selected' : ''}" data-region-id="${reg.id}">
                  <div class="region-item-info">
                    <div style="display: flex; align-items: center; gap: 8px;">
                      <span class="region-item-label" style="font-weight: 700;">${reg.label}</span>
                      <span class="badge ${reg.type === 'character' ? 'badge-similarity-high' : reg.type === 'face' ? 'badge-public' : 'badge-demo'}" style="font-size: 0.65rem; padding: 1px 6px;">
                        ${reg.confidence}% confidence
                      </span>
                    </div>
                    <span class="region-item-desc" style="font-size: 0.75rem; color: var(--text-muted);">${reg.description}</span>
                  </div>
                  <div class="region-item-radio"></div>
                </div>
              `;
              })
              .join('')}
          </div>

          <!-- Selection Disclaimer Notice -->
          <div style="background: var(--bg-tertiary); border: 1px solid var(--border-subtle); border-radius: var(--radius-md); padding: 12px 14px; display: flex; gap: 10px;">
            <div style="color: var(--accent-amber); margin-top: 1px;">
              ${renderIcon('info', 'w-4 h-4', 16)}
            </div>
            <p style="font-size: 0.78rem; color: var(--text-secondary); line-height: 1.45; margin: 0;">
              <strong>Visual region notice:</strong> Selections are coordinate boundaries for algorithmic image comparison. DIGITAL YOUR does not claim that a detected face proves someone’s identity.
            </p>
          </div>

          <!-- Primary Search Execution CTA -->
          <div style="margin-top: 8px;">
            <button class="btn btn-primary btn-lg" id="execute-search-btn" style="width: 100%;">
              ${renderIcon('search', 'w-5 h-5', 20)}
              Search Public Indexed Sources
            </button>
            <div style="display: flex; justify-content: space-between; font-size: 0.75rem; color: var(--text-muted); margin-top: 8px;">
              <span>10-stage public source verification</span>
              <span>1 search deducted from quota</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `;
}

export function attachUploadEvents() {
  // Preset Tab Filters
  const presetTabs = document.querySelectorAll('.preset-filter-tab');
  presetTabs.forEach((tab) => {
    tab.addEventListener('click', (e) => {
      activePresetTab = e.currentTarget.getAttribute('data-tab');
      store.notify();
    });
  });

  // Toggle Gemini AI Configuration Modal
  const toggleGeminiBtn = document.getElementById('toggle-gemini-config-btn');
  if (toggleGeminiBtn) {
    toggleGeminiBtn.addEventListener('click', () => {
      store.openModal('aiConfig');
    });
  }

  // Save Gemini Key
  const saveGeminiBtn = document.getElementById('save-gemini-key-btn');
  const geminiInput = document.getElementById('gemini-api-key-input');
  if (saveGeminiBtn && geminiInput) {
    saveGeminiBtn.addEventListener('click', () => {
      store.setGeminiApiKey(geminiInput.value);
    });
  }

  // Clear Gemini Key
  const clearGeminiBtn = document.getElementById('clear-gemini-key-btn');
  if (clearGeminiBtn) {
    clearGeminiBtn.addEventListener('click', () => {
      store.setGeminiApiKey('');
    });
  }

  // Preset Chips Click
  const presetChips = document.querySelectorAll('.preset-chip');
  presetChips.forEach((chip) => {
    chip.addEventListener('click', (e) => {
      const sampleId = e.currentTarget.getAttribute('data-sample-id');
      store.loadSampleImage(sampleId);
    });
  });

  // Browse File Button
  const browseBtn = document.getElementById('upload-browse-btn');
  const fileInput = document.getElementById('upload-file-input');
  if (browseBtn && fileInput) {
    browseBtn.addEventListener('click', () => fileInput.click());
    fileInput.addEventListener('change', (e) => {
      if (e.target.files && e.target.files[0]) {
        store.uploadCustomImage(e.target.files[0]);
      }
    });
  }

  // Drag & Drop
  const dropzone = document.getElementById('upload-dropzone');
  if (dropzone) {
    ['dragenter', 'dragover'].forEach((eventName) => {
      dropzone.addEventListener(eventName, (e) => {
        e.preventDefault();
        dropzone.classList.add('dragover');
      });
    });

    ['dragleave', 'drop'].forEach((eventName) => {
      dropzone.addEventListener(eventName, (e) => {
        e.preventDefault();
        dropzone.classList.remove('dragover');
      });
    });

    dropzone.addEventListener('drop', (e) => {
      if (e.dataTransfer.files && e.dataTransfer.files[0]) {
        store.uploadCustomImage(e.dataTransfer.files[0]);
      }
    });
  }

  // Replace & Remove
  const replaceBtn = document.getElementById('upload-replace-btn');
  if (replaceBtn) {
    replaceBtn.addEventListener('click', () => {
      if (fileInput) fileInput.click();
      else {
        store.state.currentSearch.imageSrc = null;
        store.notify();
      }
    });
  }

  const removeBtn = document.getElementById('upload-remove-btn');
  if (removeBtn) {
    removeBtn.addEventListener('click', () => {
      store.state.currentSearch.imageSrc = null;
      store.state.currentSearch.status = 'idle';
      store.notify();
    });
  }

  // Bounding Box Overlays
  const boundingOverlays = document.querySelectorAll('.detected-bounding-overlay');
  boundingOverlays.forEach((overlay) => {
    overlay.addEventListener('click', (e) => {
      e.stopPropagation();
      const regionId = e.currentTarget.getAttribute('data-region-id');
      const region = store.state.currentSearch.regions.find((r) => r.id === regionId);
      if (region) {
        store.selectRegion(region);
      }
    });
  });

  // Region Cards List Click
  const regionCards = document.querySelectorAll('.region-item-card');
  regionCards.forEach((card) => {
    card.addEventListener('click', (e) => {
      const regionId = e.currentTarget.getAttribute('data-region-id');
      const region = store.state.currentSearch.regions.find((r) => r.id === regionId);
      if (region) {
        store.selectRegion(region);
      }
    });
  });

  // Execute Search CTA
  const executeSearchBtn = document.getElementById('execute-search-btn');
  if (executeSearchBtn) {
    executeSearchBtn.addEventListener('click', () => {
      store.startSearchExecution();
    });
  }
}
