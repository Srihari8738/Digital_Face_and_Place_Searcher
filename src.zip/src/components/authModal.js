// src/components/authModal.js
// Authentication modal supporting Google SSO simulation, Email login, Account creation, Password reset, and Profile info

import { store } from '../state.js';
import { renderIcon } from '../utils/icons.js';

export function renderAuthModal() {
  const { modalData, user, isAuthenticated } = store.state;
  const initialTab = modalData?.tab || (isAuthenticated ? 'profile' : 'login');

  return `
    <div class="modal-backdrop" id="auth-modal-backdrop">
      <div class="modal-dialog" id="auth-modal-dialog">
        <div class="modal-header">
          <div style="display: flex; align-items: center; gap: 10px;">
            <div class="nav-logo-icon" style="width: 32px; height: 32px;">
              ${renderIcon('scan', 'w-4 h-4', 18)}
            </div>
            <div>
              <h3 style="font-size: 1.15rem;" id="auth-modal-title">
                ${
                  initialTab === 'profile'
                    ? 'Account Profile'
                    : initialTab === 'register'
                    ? 'Create DIGITAL YOUR Account'
                    : initialTab === 'forgot'
                    ? 'Reset Password'
                    : 'Log in to DIGITAL YOUR'
                }
              </h3>
              <p style="font-size: 0.8rem; color: var(--text-muted);">
                Privacy-by-design access • Zero invasive tracking
              </p>
            </div>
          </div>
          <button class="btn btn-ghost btn-sm" id="auth-modal-close-btn" aria-label="Close modal">
            ${renderIcon('x', 'w-5 h-5', 20)}
          </button>
        </div>

        <div class="modal-body">
          ${
            initialTab === 'profile'
              ? renderProfileView(user)
              : renderAuthForms(initialTab)
          }
        </div>
      </div>
    </div>
  `;
}

function renderProfileView(user) {
  return `
    <div style="display: flex; flex-direction: column; gap: 24px;">
      <div style="display: flex; align-items: center; gap: 20px; padding: 16px; background: var(--bg-tertiary); border-radius: var(--radius-lg); border: 1px solid var(--border-subtle);">
        <img src="${user.avatar}" alt="${user.name}" style="width: 72px; height: 72px; border-radius: 50%; object-fit: cover; border: 2px solid var(--primary);" />
        <div>
          <h4 style="font-size: 1.2rem; margin-bottom: 2px;">${user.name}</h4>
          <p style="font-size: 0.88rem; color: var(--text-secondary); margin-bottom: 8px;">${user.email}</p>
          <span class="badge badge-privacy">
            ${renderIcon('shield-check', 'w-3 h-3', 12)} Verified Member
          </span>
        </div>
      </div>

      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px;">
        <div style="padding: 14px; background: var(--bg-tertiary); border-radius: var(--radius-md); border: 1px solid var(--border-subtle);">
          <span style="font-size: 0.75rem; color: var(--text-muted); text-transform: uppercase; font-weight: 700;">Account Created</span>
          <p style="font-size: 0.95rem; font-weight: 600; color: var(--text-primary); margin-top: 4px;">${user.joined}</p>
        </div>
        <div style="padding: 14px; background: var(--bg-tertiary); border-radius: var(--radius-md); border: 1px solid var(--border-subtle);">
          <span style="font-size: 0.75rem; color: var(--text-muted); text-transform: uppercase; font-weight: 700;">Usage Count</span>
          <p style="font-size: 0.95rem; font-weight: 600; color: var(--text-primary); margin-top: 4px;">${user.searchesUsed} Searches Conducted</p>
        </div>
      </div>

      <div style="padding: 14px; background: rgba(16, 185, 129, 0.08); border: 1px solid rgba(16, 185, 129, 0.25); border-radius: var(--radius-md);">
        <p style="font-size: 0.825rem; color: var(--accent-emerald); display: flex; align-items: center; gap: 8px;">
          ${renderIcon('shield-check', 'w-4 h-4', 16)}
          Data Minimization: We store only essential authentication metadata. No biometric profiles or browsing histories are indexed.
        </p>
      </div>

      <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 8px;">
        <button class="btn btn-secondary" id="auth-switch-to-settings-btn">
          ${renderIcon('settings', 'w-4 h-4', 16)} Privacy Settings
        </button>
        <button class="btn btn-danger" id="auth-logout-btn">
          ${renderIcon('logout', 'w-4 h-4', 16)} Log out
        </button>
      </div>
    </div>
  `;
}

function renderAuthForms(activeTab) {
  return `
    <div style="display: flex; flex-direction: column; gap: 20px;">
      <!-- Google SSO Button -->
      <button class="btn btn-secondary" id="auth-google-sso-btn" style="width: 100%; padding: 12px; font-weight: 600;">
        <svg width="18" height="18" viewBox="0 0 24 24">
          <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
          <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
          <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
          <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
        </svg>
        Continue with Google
      </button>

      <div style="display: flex; align-items: center; gap: 12px; color: var(--text-muted); font-size: 0.8rem;">
        <div style="flex: 1; height: 1px; background: var(--border-subtle);"></div>
        <span>or continue with email</span>
        <div style="flex: 1; height: 1px; background: var(--border-subtle);"></div>
      </div>

      <!-- Form Mode Toggle -->
      <div style="display: flex; background: var(--bg-tertiary); padding: 4px; border-radius: var(--radius-md); border: 1px solid var(--border-subtle);">
        <button class="btn btn-ghost btn-sm ${activeTab === 'login' ? 'active' : ''}" id="tab-login-btn" style="flex: 1; ${activeTab === 'login' ? 'background: var(--bg-primary); color: var(--text-primary); font-weight: 600;' : ''}">
          Log in
        </button>
        <button class="btn btn-ghost btn-sm ${activeTab === 'register' ? 'active' : ''}" id="tab-register-btn" style="flex: 1; ${activeTab === 'register' ? 'background: var(--bg-primary); color: var(--text-primary); font-weight: 600;' : ''}">
          Create Account
        </button>
      </div>

      <!-- Form Inputs -->
      <form id="auth-email-form" style="display: flex; flex-direction: column; gap: 14px;">
        <div id="auth-error-alert" style="display: none; padding: 10px 14px; background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.3); border-radius: 6px; color: #ef4444; font-size: 0.8rem; line-height: 1.4;">
        </div>

        ${
          activeTab === 'register'
            ? `
            <div>
              <label style="display: block; font-size: 0.825rem; font-weight: 600; margin-bottom: 6px;">Your Name</label>
              <input type="text" id="auth-input-name" placeholder="e.g. Alex Morgan" required style="width: 100%; padding: 10px 14px; border-radius: 8px; border: 1px solid var(--border-color); background: var(--bg-surface); color: var(--text-primary); font-size: 0.9rem;" value="" />
            </div>
          `
            : ''
        }

        <div>
          <label style="display: block; font-size: 0.825rem; font-weight: 600; margin-bottom: 6px;">Original Email Address</label>
          <input 
            type="email" 
            id="auth-input-email" 
            placeholder="you@yourdomain.com" 
            required 
            style="width: 100%; padding: 10px 14px; border-radius: 8px; border: 1px solid var(--border-color); background: var(--bg-surface); color: var(--text-primary); font-size: 0.9rem;" 
            value="${localStorage.getItem('dy_user_email') || ''}" 
          />
          <span style="font-size: 0.72rem; color: var(--text-muted); display: block; margin-top: 4px;">
            Log in with your original email to access saved investigations & history.
          </span>
        </div>

        ${
          activeTab !== 'forgot'
            ? `
            <div>
              <div style="display: flex; justify-content: space-between; margin-bottom: 6px;">
                <label style="font-size: 0.825rem; font-weight: 600;">Password</label>
                ${
                  activeTab === 'login'
                    ? `<a href="#" id="auth-forgot-link" style="font-size: 0.8rem; color: var(--primary);">Forgot password?</a>`
                    : ''
                }
              </div>
              <input 
                type="password" 
                id="auth-input-password" 
                placeholder="Enter password (min. 6 characters)" 
                required 
                style="width: 100%; padding: 10px 14px; border-radius: 8px; border: 1px solid var(--border-color); background: var(--bg-surface); color: var(--text-primary); font-size: 0.9rem;" 
                value="" 
              />
            </div>
          `
            : `
            <p style="font-size: 0.85rem; color: var(--text-secondary); line-height: 1.5;">
              We will send a secure password reset link to your original verified email address.
            </p>
          `
        }

        <button type="submit" id="auth-submit-btn" class="btn btn-primary" style="width: 100%; margin-top: 6px; padding: 12px; font-weight: 700; font-size: 0.92rem; border-radius: 8px;">
          ${
            activeTab === 'register'
              ? 'Create Account with Email'
              : activeTab === 'forgot'
              ? 'Send Reset Link'
              : 'Sign In with Email'
          }
        </button>
      </form>

      <p style="font-size: 0.75rem; color: var(--text-muted); text-align: center; line-height: 1.4;">
        By continuing, you acknowledge our Responsible Use Policy and agree to respect public source boundaries and individual privacy.
      </p>
    </div>
  `;
}

export function attachAuthEvents() {
  const closeBtn = document.getElementById('auth-modal-close-btn');
  if (closeBtn) {
    closeBtn.addEventListener('click', () => {
      store.closeModal();
    });
  }

  const backdrop = document.getElementById('auth-modal-backdrop');
  if (backdrop) {
    backdrop.addEventListener('click', (e) => {
      if (e.target === backdrop) {
        store.closeModal();
      }
    });
  }

  // Google SSO Simulation
  const googleBtn = document.getElementById('auth-google-sso-btn');
  if (googleBtn) {
    googleBtn.addEventListener('click', () => {
      store.login({
        name: 'Verified User',
        email: 'user@gmail.com',
        avatar: 'https://api.dicebear.com/7.x/initials/svg?seed=user@gmail.com&backgroundColor=2563eb,7c3aed'
      });
    });
  }

  // Email form submission with Backend API integration
  const emailForm = document.getElementById('auth-email-form');
  if (emailForm) {
    emailForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const nameInput = document.getElementById('auth-input-name');
      const emailInput = document.getElementById('auth-input-email');
      const passwordInput = document.getElementById('auth-input-password');
      const submitBtn = document.getElementById('auth-submit-btn');
      const errorAlert = document.getElementById('auth-error-alert');

      const email = emailInput ? emailInput.value.trim() : '';
      const password = passwordInput ? passwordInput.value : '';
      const name = nameInput ? nameInput.value.trim() : '';
      const isRegister = !!nameInput;

      if (!email) {
        if (errorAlert) {
          errorAlert.textContent = 'Please enter your email address.';
          errorAlert.style.display = 'block';
        }
        return;
      }

      if (!password || password.length < 6) {
        if (errorAlert) {
          errorAlert.textContent = 'Password must be at least 6 characters long.';
          errorAlert.style.display = 'block';
        }
        return;
      }

      const origText = submitBtn ? submitBtn.innerHTML : '';
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span class="spinner" style="width: 14px; height: 14px; border: 2px solid #fff; border-top-color: transparent; border-radius: 50%; display: inline-block; animation: spin 0.8s linear infinite; margin-right: 8px;"></span> Signing in...';
      }

      try {
        const success = await store.loginWithEmail(email, password, name, isRegister);
        if (!success && errorAlert) {
          errorAlert.textContent = 'Authentication failed. Please check your email and password.';
          errorAlert.style.display = 'block';
        }
      } catch (err) {
        if (errorAlert) {
          errorAlert.textContent = err.message || 'Network error connecting to auth server.';
          errorAlert.style.display = 'block';
        }
      } finally {
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.innerHTML = origText;
        }
      }
    });
  }

  // Tab buttons
  const tabLoginBtn = document.getElementById('tab-login-btn');
  if (tabLoginBtn) {
    tabLoginBtn.addEventListener('click', () => {
      store.openModal('auth', { tab: 'login' });
    });
  }

  const tabRegisterBtn = document.getElementById('tab-register-btn');
  if (tabRegisterBtn) {
    tabRegisterBtn.addEventListener('click', () => {
      store.openModal('auth', { tab: 'register' });
    });
  }

  const forgotLink = document.getElementById('auth-forgot-link');
  if (forgotLink) {
    forgotLink.addEventListener('click', (e) => {
      e.preventDefault();
      store.openModal('auth', { tab: 'forgot' });
    });
  }

  // Profile actions
  const logoutBtn = document.getElementById('auth-logout-btn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
      store.logout();
      store.closeModal();
    });
  }

  const switchSettingsBtn = document.getElementById('auth-switch-to-settings-btn');
  if (switchSettingsBtn) {
    switchSettingsBtn.addEventListener('click', () => {
      store.closeModal();
      store.navigate('dashboard', 'settings');
    });
  }
}
