// src/components/navbar.js
// Top Navigation bar for Landing Page and Application Shell

import { store } from '../state.js';
import { renderIcon } from '../utils/icons.js';

export function renderNavbar() {
  const { view, theme, isAuthenticated, user } = store.state;
  const remaining = store.remainingSearches;

  if (view === 'landing') {
    return `
      <div class="dy-nav-wrapper" id="dy-nav-wrapper">
        <nav class="dy-nav-pill" id="dy-nav-pill">
          <!-- Brand Logo: Abstract 'D' Symbol + DIGITAL YOUR -->
          <div class="dy-nav-brand" id="nav-brand-logo">
            <div class="dy-brand-icon-d">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                <path d="M6 3h6a6 6 0 0 1 6 6v6a6 6 0 0 1-6 6H6V3z"/>
                <path d="M12 9v6" stroke="rgba(255,255,255,0.7)" stroke-width="2"/>
              </svg>
            </div>
            <span class="dy-brand-title">
              DIGITAL YOUR
            </span>
          </div>

          <!-- Navigation Links -->
          <ul class="dy-nav-links">
            <li class="dy-nav-link-item"><a href="#home" class="dy-nav-link active">Home</a></li>
            <li class="dy-nav-link-item"><a href="#how-it-works" class="dy-nav-link">How It Works</a></li>
            <li class="dy-nav-link-item"><a href="#people" class="dy-nav-link">People</a></li>
            <li class="dy-nav-link-item"><a href="#places" class="dy-nav-link">Places</a></li>
            <li class="dy-nav-link-item"><a href="#technology" class="dy-nav-link">Technology</a></li>
          </ul>

          <!-- Right Action: "Try AI →" CTA -->
          <div class="dy-nav-actions">
            ${
              isAuthenticated
                ? `<button class="btn btn-secondary btn-sm" id="nav-dashboard-btn" style="border-radius: 12px; font-weight: 600; padding: 7px 14px; font-size: 0.84rem;">
                    ${renderIcon('dashboard', 'w-3.5 h-3.5', 14)} Dashboard
                   </button>`
                : `<button class="btn btn-ghost btn-sm" id="nav-login-btn" style="font-size: 0.85rem; font-weight: 600; color: var(--dy-text-secondary);">
                    Sign In
                   </button>`
            }

            <button class="dy-btn-try" id="nav-start-search-btn">
              <span>Try AI</span>
              <span class="dy-arrow">→</span>
            </button>
          </div>
        </nav>
      </div>
    `;
  }

  // App Shell Topbar (Dashboard View)
  return `
    <header class="app-topbar">
      <div class="topbar-left">
        <button class="btn btn-ghost btn-sm" id="mobile-sidebar-toggle" aria-label="Toggle Sidebar">
          ${renderIcon('sliders-horizontal', 'w-4 h-4', 18)}
        </button>
        <div class="topbar-env-pill">
          ${renderIcon('shield-check', 'w-3.5 h-3.5', 14)}
          <span>Public Index Demo • Zero Private Scrapes</span>
        </div>
      </div>

      <div class="topbar-right">
        <button class="btn btn-ghost btn-sm" id="topbar-ai-modal-btn" title="Configure AI Engine" style="display: flex; align-items: center; gap: 6px; font-size: 0.78rem; padding: 5px 12px; border-radius: 999px; background: ${store.state.geminiApiKey ? 'rgba(16, 185, 129, 0.12)' : 'rgba(139, 92, 246, 0.12)'}; color: ${store.state.geminiApiKey ? '#10b981' : 'var(--accent-purple)'}; border: 1px solid ${store.state.geminiApiKey ? 'rgba(16, 185, 129, 0.3)' : 'rgba(139, 92, 246, 0.3)'}; font-weight: 700;">
          ${renderIcon('sparkles', 'w-3.5 h-3.5', 14)}
          <span>${store.state.geminiApiKey ? 'Gemini 2.0' : 'AI Engine'}</span>
        </button>

        <div class="quota-indicator-pill" title="${remaining} free searches left">
          <span class="quota-dot ${remaining === 0 ? 'depleted' : ''}"></span>
          <span>${remaining} / ${user.searchesLimit} searches remaining</span>
        </div>

        <button class="btn btn-ghost" id="topbar-theme-toggle" title="Toggle Theme" aria-label="Toggle Theme">
          ${renderIcon(theme === 'dark' ? 'sun' : 'moon', 'w-4 h-4', 18)}
        </button>

        <div class="user-profile-menu-btn" id="topbar-user-menu-btn" role="button" tabindex="0">
          <img src="${user.avatar}" alt="${user.name}" class="user-avatar-mini" />
          <span class="user-name-label">${user.name}</span>
          ${renderIcon('chevron-down', 'w-3 h-3', 14)}
        </div>
      </div>
    </header>
  `;
}

export function attachNavbarEvents() {
  const brandLogo = document.getElementById('nav-brand-logo');
  if (brandLogo) {
    brandLogo.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      store.navigate('landing');
    });
  }

  // Scroll event for dynamic navbar shrink & blur transition
  const navWrapper = document.getElementById('dy-nav-wrapper');
  if (navWrapper) {
    const handleScroll = () => {
      if (window.scrollY > 30) {
        navWrapper.classList.add('scrolled');
      } else {
        navWrapper.classList.remove('scrolled');
      }
    };
    window.removeEventListener('scroll', handleScroll);
    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();
  }

  const navThemeToggle = document.getElementById('nav-theme-toggle');
  if (navThemeToggle) {
    navThemeToggle.addEventListener('click', () => {
      store.toggleTheme();
    });
  }

  const topbarThemeToggle = document.getElementById('topbar-theme-toggle');
  if (topbarThemeToggle) {
    topbarThemeToggle.addEventListener('click', () => {
      store.toggleTheme();
    });
  }

  const navLoginBtn = document.getElementById('nav-login-btn');
  if (navLoginBtn) {
    navLoginBtn.addEventListener('click', () => {
      store.openModal('auth');
    });
  }

  const navDashboardBtn = document.getElementById('nav-dashboard-btn');
  if (navDashboardBtn) {
    navDashboardBtn.addEventListener('click', () => {
      store.navigate('dashboard', 'overview');
    });
  }

  const navStartSearchBtn = document.getElementById('nav-start-search-btn');
  if (navStartSearchBtn) {
    navStartSearchBtn.addEventListener('click', () => {
      // Smoothly scroll or navigate to live search
      if (store.state.isAuthenticated) {
        store.navigate('dashboard', 'search');
      } else {
        store.openModal('auth', { nextTab: 'search' });
      }
    });
  }

  const topbarUserMenuBtn = document.getElementById('topbar-user-menu-btn');
  if (topbarUserMenuBtn) {
    topbarUserMenuBtn.addEventListener('click', () => {
      store.openModal('auth', { tab: 'profile' });
    });
  }

  const mobileSidebarToggle = document.getElementById('mobile-sidebar-toggle');
  if (mobileSidebarToggle) {
    mobileSidebarToggle.addEventListener('click', () => {
      const sidebar = document.querySelector('.app-sidebar');
      if (sidebar) {
        sidebar.classList.toggle('mobile-open');
      }
    });
  }

  const topbarAiBtn = document.getElementById('topbar-ai-modal-btn');
  if (topbarAiBtn) {
    topbarAiBtn.addEventListener('click', () => {
      store.openModal('aiConfig');
    });
  }
}
