// src/components/settingsView.js
// Settings: Account profile, Zero-Retention privacy controls, quota management, and theme preferences

import { store } from '../state.js';
import { renderIcon } from '../utils/icons.js';

export function renderSettingsView() {
  const { user, theme } = store.state;
  const remaining = store.remainingSearches;

  return `
    <div style="display: flex; flex-direction: column; gap: 32px; max-width: 860px;">
      <!-- Header -->
      <div>
        <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 4px;">
          <span class="badge badge-privacy">
            ${renderIcon('lock', 'w-3 h-3', 12)} Privacy-by-Design
          </span>
        </div>
        <h2 style="font-size: 1.8rem;">Account & Privacy Settings</h2>
        <p style="font-size: 0.95rem; color: var(--text-secondary);">
          Manage data retention policies, search quotas, interface themes, and personal credentials.
        </p>
      </div>

      <!-- Account Profile Card -->
      <div class="glass-panel" style="padding: 28px;">
        <h3 style="font-size: 1.15rem; margin-bottom: 16px;">Account Profile</h3>
        <div style="display: flex; align-items: center; gap: 20px; flex-wrap: wrap;">
          <img src="${user.avatar}" alt="${user.name}" style="width: 76px; height: 76px; border-radius: 50%; object-fit: cover; border: 2px solid var(--primary);" />
          <div style="flex: 1; min-width: 200px;">
            <h4 style="font-size: 1.1rem;">${user.name}</h4>
            <p style="font-size: 0.85rem; color: var(--text-secondary); margin-bottom: 8px;">${user.email}</p>
            <div style="display: flex; gap: 12px; font-size: 0.78rem; color: var(--text-muted); flex-wrap: wrap;">
              <span>Member since: <strong>${user.joined}</strong></span>
              <span>•</span>
              <span>Total queries run: <strong>${user.searchesUsed}</strong></span>
            </div>
          </div>
          <button class="btn btn-secondary btn-sm" id="settings-edit-profile-btn">
            ${renderIcon('edit', 'w-3.5 h-3.5', 14)} Edit Credentials
          </button>
        </div>
      </div>

      <!-- Search Quota & Evaluation Management -->
      <div class="glass-panel" style="padding: 28px;">
        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px; flex-wrap: wrap; gap: 12px;">
          <div>
            <h3 style="font-size: 1.15rem;">Search Quota & Tier</h3>
            <p style="font-size: 0.85rem; color: var(--text-secondary);">
              Current evaluation tier allows up to 3 complimentary public searches.
            </p>
          </div>
          <span class="badge ${remaining > 0 ? 'badge-public' : 'badge-demo'}" style="font-size: 0.8rem; padding: 4px 10px;">
            ${remaining} / ${user.searchesLimit} Remaining
          </span>
        </div>

        <div class="usage-bar-track" style="height: 10px; margin-bottom: 18px;">
          <div class="usage-bar-fill" style="width: ${(user.searchesUsed / user.searchesLimit) * 100}%;"></div>
        </div>

        <div style="display: flex; gap: 12px; flex-wrap: wrap;">
          <button class="btn btn-secondary btn-sm" id="settings-reset-quota-btn" title="Reset quota to 3 searches for testing">
            ${renderIcon('refresh', 'w-3.5 h-3.5', 14)} Reset Demo Quota (Test Mode)
          </button>
          <button class="btn btn-primary btn-sm" id="settings-upgrade-pro-btn">
            ${renderIcon('zap', 'w-3.5 h-3.5', 14)} Upgrade to Researcher Pro
          </button>
        </div>
      </div>

      <!-- Data Retention & Zero-Storage Controls -->
      <div class="glass-panel" style="padding: 28px;">
        <h3 style="font-size: 1.15rem; margin-bottom: 6px;">Zero-Retention Privacy Controls</h3>
        <p style="font-size: 0.85rem; color: var(--text-secondary); margin-bottom: 20px;">
          Choose how long temporary feature hash vectors and query logs reside in local memory.
        </p>

        <div style="display: flex; flex-direction: column; gap: 16px;">
          <label style="display: flex; align-items: flex-start; gap: 14px; cursor: pointer; padding: 12px; background: var(--bg-tertiary); border-radius: var(--radius-md); border: 1px solid var(--border-subtle);">
            <input type="radio" name="retention" value="session" checked style="margin-top: 4px;" />
            <div>
              <div style="font-size: 0.9rem; font-weight: 600; color: var(--text-primary);">
                Zero-Retention Mode (Recommended)
              </div>
              <p style="font-size: 0.8rem; color: var(--text-muted); line-height: 1.45; margin-top: 2px;">
                Image pixels and hash vectors are immediately expunged from memory as soon as the search query terminates.
              </p>
            </div>
          </label>

          <label style="display: flex; align-items: flex-start; gap: 14px; cursor: pointer; padding: 12px; background: var(--bg-tertiary); border-radius: var(--radius-md); border: 1px solid var(--border-subtle);">
            <input type="radio" name="retention" value="30days" style="margin-top: 4px;" />
            <div>
              <div style="font-size: 0.9rem; font-weight: 600; color: var(--text-primary);">
                30-Day Encrypted Research Cache
              </div>
              <p style="font-size: 0.8rem; color: var(--text-muted); line-height: 1.45; margin-top: 2px;">
                Caches perceptual descriptors in local browser storage to re-run comparisons without re-uploading files.
              </p>
            </div>
          </label>
        </div>

        <div style="margin-top: 20px; padding-top: 18px; border-top: 1px solid var(--border-subtle); display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;">
          <div>
            <div style="font-size: 0.88rem; font-weight: 600;">Purge Local Footprint</div>
            <p style="font-size: 0.78rem; color: var(--text-muted);">Permanently delete all search history and saved collections from this browser.</p>
          </div>
          <button class="btn btn-danger btn-sm" id="settings-purge-data-btn">
            ${renderIcon('trash', 'w-3.5 h-3.5', 14)} Purge Local Data
          </button>
        </div>
      </div>

      <!-- Appearance & Theme Settings -->
      <div class="glass-panel" style="padding: 28px;">
        <h3 style="font-size: 1.15rem; margin-bottom: 6px;">Appearance & Interface</h3>
        <p style="font-size: 0.85rem; color: var(--text-secondary); margin-bottom: 18px;">
          Customize visual contrast, typography density, and color theme.
        </p>

        <div style="display: flex; gap: 16px;">
          <button class="btn btn-secondary ${theme === 'dark' ? 'btn-primary' : ''}" id="settings-theme-dark-btn" style="flex: 1; padding: 14px; flex-direction: column; gap: 8px;">
            ${renderIcon('moon', 'w-5 h-5', 22)}
            <span>Dark Cyber Graphite (Default)</span>
          </button>
          <button class="btn btn-secondary ${theme === 'light' ? 'btn-primary' : ''}" id="settings-theme-light-btn" style="flex: 1; padding: 14px; flex-direction: column; gap: 8px;">
            ${renderIcon('sun', 'w-5 h-5', 22)}
            <span>Light Crisp Alabaster</span>
          </button>
        </div>
      </div>
    </div>
  `;
}

export function attachSettingsEvents() {
  const resetBtn = document.getElementById('settings-reset-quota-btn');
  if (resetBtn) {
    resetBtn.addEventListener('click', () => {
      store.resetSearchQuota();
    });
  }

  const upgradeBtn = document.getElementById('settings-upgrade-pro-btn');
  if (upgradeBtn) {
    upgradeBtn.addEventListener('click', () => {
      store.openModal('upgrade');
    });
  }

  const editProfileBtn = document.getElementById('settings-edit-profile-btn');
  if (editProfileBtn) {
    editProfileBtn.addEventListener('click', () => {
      store.openModal('auth', { tab: 'profile' });
    });
  }

  const purgeBtn = document.getElementById('settings-purge-data-btn');
  if (purgeBtn) {
    purgeBtn.addEventListener('click', () => {
      if (confirm('Are you sure you want to permanently erase all local search history and saved collections?')) {
        localStorage.clear();
        store.clearAllHistory();
        store.state.savedResults = [];
        store.saveJSON('dy_saved', []);
        store.showToast('All local application data has been purged.', 'info');
        store.notify();
      }
    });
  }

  const darkBtn = document.getElementById('settings-theme-dark-btn');
  const lightBtn = document.getElementById('settings-theme-light-btn');
  if (darkBtn) darkBtn.addEventListener('click', () => store.setTheme('dark'));
  if (lightBtn) lightBtn.addEventListener('click', () => store.setTheme('light'));
}
