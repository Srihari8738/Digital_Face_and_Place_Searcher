// src/components/searchResults.js
// Clean, light interface with Exact Matches, Near Matches, Related Pages, Media/Character Panel,
// Public Figure Panel, Ordinary Person Privacy Guardrail, Image Context Analysis, and No Strong Match handling

import { store } from '../state.js';
import { renderIcon } from '../utils/icons.js';

export function renderSearchResults() {
  const { currentSearch, savedResults } = store.state;
  const results = currentSearch.filteredResults || [];
  const totalCount = currentSearch.results?.length || 0;
  const activeFilter = currentSearch.activeFilter || 'All';
  const sortBy = currentSearch.sortBy || 'relevance';
  const viewLayout = currentSearch.viewLayout || 'grid';

  const filterCategories = [
    'All',
    'Exact Matches',
    'Similar Images',
    'Articles',
    'Profiles',
    'Media',
    'Products',
    'Public Figures',
    'Websites'
  ];

  const exactMatches = results.filter((r) => r.matchType === 'exact');
  const nearMatches = results.filter((r) => r.matchType === 'near');
  const relatedMatches = results.filter((r) => r.matchType === 'related');

  return `
    <div class="search-view results-view-clean">
      <!-- Search Summary Header -->
      <div class="results-header-card">
        <div class="results-query-summary">
          <div class="query-dual-thumb">
            <img src="${currentSearch.imageSrc}" alt="Query image" />
            <div class="query-region-crop-badge" title="${currentSearch.selectedRegion?.label || 'Selected Focus'}">
              ${renderIcon('scan', 'w-3 h-3', 14)}
            </div>
          </div>

          <div>
            <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 3px; flex-wrap: wrap;">
              <h2 style="font-size: 1.4rem; font-weight: 800; color: var(--text-primary);">
                ${currentSearch.title || 'Public Source Matches'}
              </h2>
              <span class="badge badge-public">${totalCount} Public Records</span>
              <span class="badge badge-demo" style="font-size: 0.72rem;">
                ${currentSearch.classification || 'Visual Match'}
              </span>
            </div>
            <div style="display: flex; gap: 10px; font-size: 0.8rem; color: var(--text-muted); flex-wrap: wrap;">
              <span>Visual Focus: <strong>${currentSearch.selectedRegion?.label || 'Entire Image'}</strong></span>
              <span>•</span>
              <span>Verified at: ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
              <span>•</span>
              <span style="color: var(--accent-emerald); font-weight: 600;">Public Web & Connected Sources</span>
            </div>
          </div>
        </div>

        <div style="display: flex; gap: 10px; flex-wrap: wrap;">
          <button class="btn btn-secondary btn-sm" id="results-new-search-btn">
            ${renderIcon('plus', 'w-4 h-4', 16)} New Search
          </button>
          <button class="btn btn-outline btn-sm" id="results-export-btn">
            ${renderIcon('download', 'w-4 h-4', 16)} Export Dossier
          </button>
        </div>
      </div>

      <!-- Mandatory Algorithmic Similarity & Legal Disclaimer Notice -->
      <div class="responsible-notice-bar" style="background: rgba(59, 130, 246, 0.05); border: 1px solid rgba(59, 130, 246, 0.2); border-radius: var(--radius-md); padding: 12px 18px; display: flex; align-items: center; gap: 12px; margin-bottom: 24px;">
        <div style="color: var(--primary); flex-shrink: 0;">
          ${renderIcon('shield-check', 'w-5 h-5', 20)}
        </div>
        <p style="font-size: 0.825rem; color: var(--text-secondary); line-height: 1.45; margin: 0;">
          <strong>Visual similarity notice:</strong> Visual similarity is an estimate and does not prove identity, ownership, authorship, or association. Searches publicly indexed and connected sources. Results depend on source availability, indexing, regional access, and search-provider coverage.
        </p>
      </div>

      <!-- Interactive AI Research Assistant Panel -->
      ${renderAiAssistantPanel(currentSearch)}

      <!-- Social Media & Public Identity Resolver (Always available when public figure data is not yet active) -->
      ${
        !currentSearch.publicFigureData
          ? renderSocialProfileResolverCard(currentSearch)
          : ''
      }

      <!-- Deep Public Anime & Media Search Toolbar -->
      ${renderDeepAnimeSearchToolbar(currentSearch)}

      <!-- 1. Strict Privacy Guardrail Panel (for Ordinary / Private Individuals) -->
      ${
        currentSearch.ordinaryPersonGuardrail?.active
          ? renderOrdinaryPersonPrivacyPanel(currentSearch.ordinaryPersonGuardrail)
          : ''
      }

      <!-- 2. Media and Character Information Panel (for Anime, Animation, Games & Cinema) -->
      ${
        currentSearch.mediaAnalysis
          ? renderMediaCharacterPanel(currentSearch.mediaAnalysis)
          : ''
      }

      <!-- 3. Public Figure Information Panel (for Documented Public Figures) -->
      ${
        currentSearch.publicFigureData
          ? renderPublicFigurePanel(currentSearch.publicFigureData)
          : ''
      }

      <!-- 4. Structured Image Context Analysis Panel (Always Available) -->
      ${
        currentSearch.imageContextAnalysis
          ? renderImageContextPanel(currentSearch.imageContextAnalysis)
          : ''
      }

      <!-- Filter Tabs, Sorting, and View Layout Controls -->
      <div class="results-controls-bar" style="margin-bottom: 20px;">
        <!-- Filter Tabs -->
        <div class="results-filter-tabs" style="display: flex; gap: 6px; overflow-x: auto; padding-bottom: 4px;">
          ${filterCategories
            .map((cat) => {
              const isActive = activeFilter.toLowerCase() === cat.toLowerCase();
              return `
              <button class="btn filter-tab-btn ${isActive ? 'active' : ''}" data-filter-cat="${cat}">
                ${cat}
              </button>
            `;
            })
            .join('')}
        </div>

        <!-- Sort and Layout Controls -->
        <div class="results-sort-group" style="display: flex; align-items: center; gap: 12px;">
          <div style="display: flex; align-items: center; gap: 6px;">
            <span style="font-size: 0.8rem; color: var(--text-muted); font-weight: 600;">Sort:</span>
            <select id="results-sort-select" style="padding: 5px 10px; font-size: 0.8rem; border-radius: var(--radius-sm); background: var(--bg-secondary); border: 1px solid var(--border-subtle); color: var(--text-primary);">
              <option value="relevance" ${sortBy === 'relevance' ? 'selected' : ''}>Relevance (Exact First)</option>
              <option value="similarity" ${sortBy === 'similarity' ? 'selected' : ''}>Highest Similarity</option>
              <option value="date" ${sortBy === 'date' ? 'selected' : ''}>Publication Date</option>
              <option value="sourceType" ${sortBy === 'sourceType' ? 'selected' : ''}>Source Quality</option>
            </select>
          </div>

          <div style="display: flex; background: var(--bg-tertiary); padding: 3px; border-radius: var(--radius-sm); border: 1px solid var(--border-subtle);">
            <button class="btn btn-ghost btn-sm ${viewLayout === 'grid' ? 'active' : ''}" id="toggle-grid-layout" title="Grid View" style="${viewLayout === 'grid' ? 'background: var(--bg-secondary); color: var(--text-primary);' : ''}">
              ${renderIcon('grid', 'w-3.5 h-3.5', 14)}
            </button>
            <button class="btn btn-ghost btn-sm ${viewLayout === 'list' ? 'active' : ''}" id="toggle-list-layout" title="List View" style="${viewLayout === 'list' ? 'background: var(--bg-secondary); color: var(--text-primary);' : ''}">
              ${renderIcon('list', 'w-3.5 h-3.5', 14)}
            </button>
          </div>
        </div>
      </div>

      <!-- 5. Search Results Content (or No Strong Match Fallback) -->
      ${
        currentSearch.isNoMatch || (results.length === 0 && !currentSearch.ordinaryPersonGuardrail?.active)
          ? renderNoStrongMatchSection()
          : renderCategorizedMatches(results, exactMatches, nearMatches, relatedMatches, activeFilter, viewLayout, savedResults)
      }
    </div>
  `;
}

// Social Media Profiles & Public Identity Resolver
function renderSocialProfileResolverCard(currentSearch) {
  return `
    <div class="glass-panel social-profile-resolver" style="margin-bottom: 24px; padding: 22px 24px; background: linear-gradient(135deg, rgba(37, 99, 235, 0.05), rgba(124, 58, 237, 0.05)); border: 1.5px solid rgba(59, 130, 246, 0.35); border-radius: 14px; box-shadow: 0 6px 24px -4px rgba(0, 0, 0, 0.05);">
      <!-- Header -->
      <div style="display: flex; align-items: flex-start; justify-content: space-between; flex-wrap: wrap; gap: 14px; margin-bottom: 14px;">
        <div style="display: flex; align-items: center; gap: 12px;">
          <div style="width: 42px; height: 42px; border-radius: 10px; background: linear-gradient(135deg, #2563eb, #7c3aed); display: flex; align-items: center; justify-content: center; color: white; flex-shrink: 0; box-shadow: 0 4px 14px rgba(37, 99, 235, 0.35);">
            ${renderIcon('users', 'w-5 h-5', 22)}
          </div>
          <div>
            <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
              <h3 style="font-size: 1.15rem; font-weight: 800; color: var(--text-primary); margin: 0;">
                Find Social Media Profiles & Verified Public Footprint
              </h3>
              <span class="badge" style="background: rgba(37, 99, 235, 0.12); color: var(--primary); font-size: 0.74rem; font-weight: 700; border: 1px solid rgba(37, 99, 235, 0.25);">
                𝕏 (Twitter) • Instagram • Snapchat • LinkedIn • Wikipedia • YouTube
              </span>
            </div>
            <p style="font-size: 0.825rem; color: var(--text-secondary); margin: 3px 0 0 0;">
              Looking for this person's social accounts? Public figures, creators, executives, and leaders have verified public profiles. Type their name or select a quick candidate below:
            </p>
          </div>
        </div>
      </div>

      <!-- Quick Name Input & Resolution Form -->
      <form id="social-resolver-form" style="display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 14px;">
        <div style="position: relative; flex: 1; min-width: 260px;">
          <input
            type="text"
            id="social-resolver-input"
            placeholder="Type any person's name (e.g. Elon Musk, Sam Altman, Jensen Huang, Mark Zuckerberg, Cristiano Ronaldo)..."
            style="width: 100%; padding: 11px 14px 11px 38px; border-radius: 8px; border: 1px solid var(--border-color); background: var(--bg-surface); color: var(--text-primary); font-size: 0.9rem; outline: none; box-sizing: border-box;"
          />
          <div style="position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: var(--text-muted); pointer-events: none;">
            ${renderIcon('search', '', 16)}
          </div>
        </div>
        <button
          type="submit"
          class="btn btn-primary"
          style="padding: 11px 22px; font-size: 0.88rem; font-weight: 700; display: inline-flex; align-items: center; gap: 8px; white-space: nowrap; border-radius: 8px;"
        >
          ${renderIcon('globe', '', 16)} Retrieve Social Profiles
        </button>
      </form>

      <!-- 1-Click Candidate Chips -->
      <div style="display: flex; align-items: center; gap: 6px; flex-wrap: wrap; margin-bottom: 14px;">
        <span style="font-size: 0.76rem; font-weight: 700; color: var(--text-muted);">Quick-Select Public Figure:</span>
        ${['Elon Musk', 'Sam Altman', 'Jensen Huang', 'Mark Zuckerberg', 'Sundar Pichai', 'Satya Nadella', 'Cristiano Ronaldo', 'Dr. Elena Vance']
          .map(name => `
            <button class="social-resolver-chip" data-name="${name}" type="button" style="padding: 5px 12px; font-size: 0.76rem; font-weight: 600; border-radius: 6px; border: 1px solid var(--border-color); background: var(--bg-surface); color: var(--text-primary); cursor: pointer; transition: all 0.15s ease;">
              ${name}
            </button>
          `).join('')}
      </div>

      <!-- Clear Privacy Guidance Explaining WHY private individuals don't have public social scraping -->
      <div style="padding: 12px 16px; background: rgba(16, 185, 129, 0.06); border: 1px solid rgba(16, 185, 129, 0.25); border-radius: 8px; font-size: 0.78rem; color: var(--text-secondary); line-height: 1.5; display: flex; align-items: flex-start; gap: 10px;">
        <span style="color: var(--accent-emerald); margin-top: 1px; flex-shrink: 0;">${renderIcon('shield-check', 'w-4 h-4', 16)}</span>
        <div>
          <strong style="color: var(--text-primary);">Why don't private photos automatically show personal social profiles?</strong>
          <p style="margin: 2px 0 0 0;">
            Legitimate search engines (Google Lens, TinEye) and DIGITAL YOUR strictly adhere to <strong>Privacy-by-Design</strong> and consumer data laws (GDPR, CCPA). We do not scrape private personal social accounts (Instagram, Snapchat, Facebook) or run unauthorized facial biometric surveillance on private citizens. Verified social media accounts are indexed exclusively for documented public figures, creators, and public entities.
          </p>
        </div>
      </div>
    </div>
  `;
}

// Deep Public Anime & Media Search Toolbar
function renderDeepAnimeSearchToolbar(currentSearch) {
  const queryVal = (currentSearch.entityType === 'public-figure' && currentSearch.publicFigureData?.publicName)
    ? currentSearch.publicFigureData.publicName
    : (currentSearch.entityType === 'anime' && !currentSearch.isUnconfirmedAnime
      ? (currentSearch.mediaAnalysis?.title || currentSearch.title || '')
      : '');

  return `
    <div class="deep-search-toolbar" style="margin-bottom: 24px; background: linear-gradient(135deg, rgba(37, 99, 235, 0.06), rgba(124, 58, 237, 0.06)); border: 1px solid rgba(59, 130, 246, 0.3); border-radius: 12px; padding: 18px 22px; box-shadow: 0 4px 16px rgba(0, 0, 0, 0.03);">
      <div style="display: flex; align-items: center; justify-content: space-between; gap: 12px; margin-bottom: 12px; flex-wrap: wrap;">
        <div style="display: flex; align-items: center; gap: 10px;">
          <span style="display: flex; align-items: center; justify-content: center; width: 34px; height: 34px; border-radius: 9px; background: var(--primary); color: white; flex-shrink: 0;">
            ${renderIcon('sparkles', '', 18)}
          </span>
          <div>
            <h4 style="font-size: 1rem; font-weight: 800; margin: 0; color: var(--text-primary); display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
              Public Figure, Social Media & Visual Entity Search Engine
              <span class="badge" style="background: rgba(37, 99, 235, 0.14); color: var(--primary); font-size: 0.72rem; font-weight: 700; border: 1px solid rgba(37, 99, 235, 0.25);">
                Live Web, Wikipedia & Social Ready
              </span>
            </h4>
            <p style="font-size: 0.8rem; color: var(--text-secondary); margin: 2px 0 0;">
              Identify world public figures, companies owned, verified social media platforms, anime rosters, and open-web sources
            </p>
          </div>
        </div>
      </div>

      <div style="display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 12px;">
        <div style="position: relative; flex: 1; min-width: 260px;">
          <input
            type="text"
            id="deepAnimeInput"
            placeholder="Search public figures (Elon Musk, SpaceX, Tesla, Sam Altman) or anime titles & characters..."
            value="${queryVal}"
            style="width: 100%; padding: 10px 14px 10px 38px; border-radius: 8px; border: 1px solid var(--border-color); background: var(--bg-surface); color: var(--text-primary); font-size: 0.88rem; outline: none; box-sizing: border-box;"
          />
          <div style="position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: var(--text-muted); pointer-events: none;">
            ${renderIcon('search', '', 16)}
          </div>
        </div>
        <button
          id="btnRunDeepSearch"
          class="btn btn-primary"
          style="padding: 10px 22px; font-size: 0.88rem; font-weight: 700; display: inline-flex; align-items: center; gap: 8px; white-space: nowrap; border-radius: 8px;"
        >
          ${renderIcon('globe', '', 16)} Run Deep Search
        </button>
      </div>

      <!-- Quick-Search Suggestion Chips -->
      <div style="display: flex; align-items: center; gap: 6px; flex-wrap: wrap; margin-bottom: 12px;">
        <span style="font-size: 0.76rem; font-weight: 700; color: var(--text-muted);">Quick Suggestions:</span>
        ${['Elon Musk', 'SpaceX', 'Tesla', 'Sam Altman', 'Jensen Huang', 'Demon Slayer', 'Jujutsu Kaisen', 'Naruto', 'One Piece', 'Mark Zuckerberg']
          .map(t => `
            <button class="anime-quick-chip" data-anime="${t}" type="button" style="padding: 4px 11px; font-size: 0.74rem; font-weight: 600; border-radius: 6px; border: 1px solid var(--border-color); background: var(--bg-surface); color: var(--text-secondary); cursor: pointer; transition: all 0.15s ease;">
              ${t}
            </button>
          `).join('')}
      </div>

      <!-- 1-Click Direct Public Reverse Image Search Engines -->
      <div style="border-top: 1px solid rgba(59, 130, 246, 0.2); padding-top: 12px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px;">
        <div style="display: flex; align-items: center; gap: 6px;">
          <span style="font-size: 0.78rem; font-weight: 700; color: var(--text-primary); display: inline-flex; align-items: center; gap: 5px;">
            ${renderIcon('globe', 'w-3.5 h-3.5', 14)} 1-Click Direct Reverse Engines:
          </span>
          <span style="font-size: 0.72rem; color: var(--text-muted);">(Verify against global public indexes)</span>
        </div>
        <div style="display: flex; gap: 6px; flex-wrap: wrap;">
          <a href="https://images.google.com/" target="_blank" rel="noopener noreferrer" class="badge badge-public" style="text-decoration: none; padding: 5px 11px; font-size: 0.74rem; font-weight: 700; display: inline-flex; align-items: center; gap: 5px; background: var(--bg-surface); border: 1px solid var(--border-color);">
            Global Web Search ${renderIcon('external-link', 'w-2.5 h-2.5', 10)}
          </a>
          <a href="https://trace.moe/" target="_blank" rel="noopener noreferrer" class="badge badge-public" style="text-decoration: none; padding: 5px 11px; font-size: 0.74rem; font-weight: 700; display: inline-flex; align-items: center; gap: 5px; background: var(--bg-surface); border: 1px solid var(--border-color);">
            Trace.moe ${renderIcon('external-link', 'w-2.5 h-2.5', 10)}
          </a>
          <a href="https://yandex.com/images/" target="_blank" rel="noopener noreferrer" class="badge badge-public" style="text-decoration: none; padding: 5px 11px; font-size: 0.74rem; font-weight: 700; display: inline-flex; align-items: center; gap: 5px; background: var(--bg-surface); border: 1px solid var(--border-color);">
            Yandex Visual ${renderIcon('external-link', 'w-2.5 h-2.5', 10)}
          </a>
          <a href="https://tineye.com/" target="_blank" rel="noopener noreferrer" class="badge badge-public" style="text-decoration: none; padding: 5px 11px; font-size: 0.74rem; font-weight: 700; display: inline-flex; align-items: center; gap: 5px; background: var(--bg-surface); border: 1px solid var(--border-color);">
            TinEye ${renderIcon('external-link', 'w-2.5 h-2.5', 10)}
          </a>
          <a href="https://anilist.co/search/anime" target="_blank" rel="noopener noreferrer" class="badge badge-public" style="text-decoration: none; padding: 5px 11px; font-size: 0.74rem; font-weight: 700; display: inline-flex; align-items: center; gap: 5px; background: var(--bg-surface); border: 1px solid var(--border-color);">
            AniList Archive ${renderIcon('external-link', 'w-2.5 h-2.5', 10)}
          </a>
        </div>
      </div>
    </div>
  `;
}

// Interactive AI Research Assistant Panel
function renderAiAssistantPanel(currentSearch) {
  const { geminiApiKey } = store.state;
  const isPublicFigure = !!currentSearch.publicFigureData;
  const isAnime = !!currentSearch.mediaAnalysis;
  const isPortrait = currentSearch.classification === 'Photographic portrait' || currentSearch.entityType === 'ordinary-person';
  const chatHistory = currentSearch.aiChat || [];

  let promptChips = [];
  if (isPublicFigure) {
    promptChips = [
      'What companies does he own?',
      'What are his verified social media accounts?',
      'What is his estimated net worth?',
      'What does he work on and create?'
    ];
  } else if (isAnime) {
    promptChips = [
      'Who are the characters in this visual?',
      'Which animation studio produced this?',
      'Where can I stream this anime?',
      'What is the franchise and genre?'
    ];
  } else if (isPortrait) {
    promptChips = [
      "Why aren't social profiles showing for this photo?",
      "How to find this person's social media accounts",
      'Analyze the lighting and camera depth-of-field',
      'Suggest reverse visual search queries'
    ];
  } else {
    promptChips = [
      'Describe this visual composition',
      'What public records match this image?',
      'Suggest key reverse search keywords'
    ];
  }

  return `
    <div class="glass-panel" style="padding: 24px; background: var(--bg-card); border: 1px solid var(--border-glow); border-radius: var(--radius-lg); margin-bottom: 24px; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);">
      <!-- Header -->
      <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px; margin-bottom: 16px; border-bottom: 1px solid var(--border-subtle); padding-bottom: 14px;">
        <div style="display: flex; align-items: center; gap: 12px;">
          <div style="width: 40px; height: 40px; border-radius: var(--radius-md); background: linear-gradient(135deg, #3b82f6, #8b5cf6); display: flex; align-items: center; justify-content: center; color: #fff; box-shadow: 0 4px 12px rgba(99, 102, 241, 0.35);">
            ${renderIcon('sparkles', 'w-5 h-5', 22)}
          </div>
          <div>
            <div style="display: flex; align-items: center; gap: 8px;">
              <h3 style="font-size: 1.15rem; font-weight: 800; color: var(--text-primary); margin: 0;">
                Ask AI Research Assistant
              </h3>
              <span class="badge ${geminiApiKey ? 'badge-similarity-high' : 'badge-demo'}" style="font-size: 0.72rem;">
                ${geminiApiKey ? '✨ Gemini 2.0 Flash Active' : '⚡ Built-in Neural Vision AI'}
              </span>
            </div>
            <p style="font-size: 0.825rem; color: var(--text-secondary); margin: 2px 0 0 0;">
              Investigative Q&A synthesized from public records, verified corporate filings, and multimodal visual analysis
            </p>
          </div>
        </div>

        <button class="btn btn-ghost btn-sm" id="ai-engine-settings-trigger" style="font-size: 0.78rem; display: flex; align-items: center; gap: 6px;">
          ${renderIcon('settings', 'w-3.5 h-3.5', 14)}
          ${geminiApiKey ? 'Gemini 2.0 Connected' : 'Connect Gemini API Key'}
        </button>
      </div>

      <!-- Quick Suggested Prompts -->
      <div style="margin-bottom: 16px;">
        <span style="font-size: 0.75rem; font-weight: 700; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.04em; display: block; margin-bottom: 8px;">
          Suggested Investigative Queries:
        </span>
        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
          ${promptChips
            .map(
              (prompt) => `
            <button class="btn btn-secondary btn-sm ai-prompt-chip" data-prompt="${prompt}" style="font-size: 0.8rem; padding: 6px 12px; border-radius: 999px; background: var(--bg-tertiary); border: 1px solid var(--border-subtle); color: var(--text-primary); cursor: pointer;">
              ${renderIcon('message-square', 'w-3 h-3', 12)} ${prompt}
            </button>
          `
            )
            .join('')}
        </div>
      </div>

      <!-- Conversation Output -->
      ${
        chatHistory.length > 0
          ? `
        <div class="ai-chat-thread" style="display: flex; flex-direction: column; gap: 12px; max-height: 380px; overflow-y: auto; padding: 14px; background: var(--bg-tertiary); border-radius: var(--radius-md); border: 1px solid var(--border-subtle); margin-bottom: 16px;">
          ${chatHistory
            .map(
              (msg) => `
            <div style="display: flex; flex-direction: column; align-items: ${msg.role === 'user' ? 'flex-end' : 'flex-start'};">
              <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 4px; font-size: 0.72rem; color: var(--text-muted);">
                <span>${msg.role === 'user' ? 'You' : 'AI Assistant'}</span>
                <span>•</span>
                <span>${msg.timestamp}</span>
              </div>
              <div style="max-width: 85%; padding: 10px 14px; border-radius: var(--radius-md); font-size: 0.88rem; line-height: 1.5; ${
                msg.role === 'user'
                  ? 'background: var(--primary); color: #ffffff;'
                  : 'background: var(--bg-card); color: var(--text-primary); border: 1px solid var(--border-subtle);'
              }">
                ${
                  msg.loading
                    ? `
                  <div style="display: flex; align-items: center; gap: 8px; color: var(--text-secondary);">
                    <span class="spinner" style="width: 14px; height: 14px; border: 2px solid var(--primary); border-top-color: transparent; border-radius: 50%; display: inline-block; animation: spin 0.8s linear infinite;"></span>
                    <span>${msg.text}</span>
                  </div>
                `
                    : msg.text
                }
              </div>
            </div>
          `
            )
            .join('')}
        </div>
      `
          : ''
      }

      <!-- Question Input Form -->
      <form id="ai-ask-form" style="display: flex; gap: 10px;">
        <input 
          type="text" 
          id="ai-question-input" 
          placeholder="Ask anything about this image (e.g. What companies does he own? What are his social handles?)..." 
          style="flex: 1; padding: 10px 16px; font-size: 0.9rem; border-radius: var(--radius-md); border: 1px solid var(--border-subtle); background: var(--bg-primary); color: var(--text-primary);"
        />
        <button type="submit" class="btn btn-primary" id="ai-ask-btn" style="display: flex; align-items: center; gap: 6px; padding: 10px 20px;">
          ${renderIcon('send', 'w-4 h-4', 16)}
          <span>Ask AI</span>
        </button>
      </form>
    </div>
  `;
}

// 1. Ordinary Person Strict Privacy Guardrail Panel
function renderOrdinaryPersonPrivacyPanel(guardrail) {
  const details = guardrail.nonIdentifyingDetails || {};

  return `
    <div class="glass-panel" style="padding: 24px; border-left: 4px solid var(--accent-emerald); background: var(--bg-card); margin-bottom: 24px;">
      <!-- Mandatory Notice Heading -->
      <div style="display: flex; align-items: flex-start; gap: 14px; margin-bottom: 16px;">
        <div style="color: var(--accent-emerald); margin-top: 2px;">
          ${renderIcon('shield-check', 'w-6 h-6', 24)}
        </div>
        <div style="flex: 1;">
          <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 6px; flex-wrap: wrap;">
            <span class="badge" style="background: rgba(16, 185, 129, 0.15); color: #34d399; border: 1px solid rgba(16, 185, 129, 0.3); font-weight: 700;">
              Strict Privacy-by-Design Active
            </span>
            <span class="badge" style="background: rgba(59, 130, 246, 0.12); color: var(--primary); font-weight: 600;">
              Web & Social Media Scan: 0 Public Records
            </span>
          </div>
          <h3 style="font-size: 1.15rem; font-weight: 800; color: var(--text-primary); margin: 0 0 6px;">
            ${guardrail.mandatoryNotice}
          </h3>
          <p style="font-size: 0.85rem; color: var(--text-secondary); line-height: 1.5; margin: 0;">
            We scanned the open web and social media archives (Instagram, Twitter/X, LinkedIn, public web domains). <strong>No publicly indexed social media accounts or public records were found for this individual.</strong> As an ordinary private person, DIGITAL YOUR does not associate private personal profiles or guess names.
          </p>
        </div>
      </div>

      <!-- Identified Subject Visual Breakdown -->
      <div style="background: var(--bg-tertiary); border: 1px solid var(--border-subtle); border-radius: var(--radius-md); padding: 14px 18px; margin-bottom: 16px;">
        <span style="font-size: 0.75rem; font-weight: 700; color: var(--text-muted); text-transform: uppercase; display: block; margin-bottom: 4px;">
          Visual Subject Description (Visible Non-Identifying Attributes):
        </span>
        <p style="font-size: 0.88rem; color: var(--text-primary); font-weight: 600; line-height: 1.5; margin: 0;">
          Person wearing a ${details.clothingColors || 'dark T-shirt / neutral knit garment'}, with ${details.hairOrHead || 'short dark cropped hair / natural head styling'}, framed in ${details.approximateComposition || 'medium close-up portrait framing'}.
        </p>
      </div>

      <!-- Non-Identifying Visual Breakdown -->
      <div style="border-top: 1px solid var(--border-subtle); padding-top: 16px;">
        <h4 style="font-size: 0.82rem; font-weight: 700; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 12px;">
          Visible Non-Sensitive Image Details
        </h4>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 10px;">
          <div style="background: var(--bg-tertiary); padding: 12px; border-radius: var(--radius-sm); border: 1px solid var(--border-subtle);">
            <strong style="font-size: 0.74rem; color: var(--text-muted); display: block; text-transform: uppercase;">Visible People</strong>
            <span style="font-size: 0.85rem; color: var(--text-primary); font-weight: 600;">${details.visiblePeopleCount || 1} Person visible in foreground</span>
          </div>
          <div style="background: var(--bg-tertiary); padding: 12px; border-radius: var(--radius-sm); border: 1px solid var(--border-subtle);">
            <strong style="font-size: 0.74rem; color: var(--text-muted); display: block; text-transform: uppercase;">Head & Hair Styling</strong>
            <span style="font-size: 0.85rem; color: var(--text-primary);">${details.hairOrHead || 'Short cropped natural hair'}</span>
          </div>
          <div style="background: var(--bg-tertiary); padding: 12px; border-radius: var(--radius-sm); border: 1px solid var(--border-subtle);">
            <strong style="font-size: 0.74rem; color: var(--text-muted); display: block; text-transform: uppercase;">T-Shirt / Garments</strong>
            <span style="font-size: 0.85rem; color: var(--text-primary);">${details.clothingColors || 'Charcoal black turtleneck / T-shirt'}</span>
          </div>
          <div style="background: var(--bg-tertiary); padding: 12px; border-radius: var(--radius-sm); border: 1px solid var(--border-subtle);">
            <strong style="font-size: 0.74rem; color: var(--text-muted); display: block; text-transform: uppercase;">Composition & Framing</strong>
            <span style="font-size: 0.85rem; color: var(--text-primary);">${details.approximateComposition || 'Medium close-up portrait'}</span>
          </div>
          <div style="background: var(--bg-tertiary); padding: 12px; border-radius: var(--radius-sm); border: 1px solid var(--border-subtle);">
            <strong style="font-size: 0.74rem; color: var(--text-muted); display: block; text-transform: uppercase;">Accessories</strong>
            <span style="font-size: 0.85rem; color: var(--text-primary);">${details.accessories || 'Optical eyewear frames'}</span>
          </div>
          <div style="background: var(--bg-tertiary); padding: 12px; border-radius: var(--radius-sm); border: 1px solid var(--border-subtle);">
            <strong style="font-size: 0.74rem; color: var(--text-muted); display: block; text-transform: uppercase;">Lighting & Setup</strong>
            <span style="font-size: 0.85rem; color: var(--text-primary);">${details.lighting || 'Diffused directional illumination'}</span>
          </div>
        </div>
      </div>
    </div>
  `;
}

// 2. Media & Character Information Panel
function renderMediaCharacterPanel(media) {
  return `
    <div class="glass-panel" style="padding: 24px; border: 1px solid var(--border-glow); background: var(--bg-card); margin-bottom: 24px;">
      <!-- Header -->
      <div style="display: flex; align-items: flex-start; justify-content: space-between; flex-wrap: wrap; gap: 14px; margin-bottom: 16px;">
        <div>
          <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 4px;">
            <span class="badge badge-similarity-high" style="font-size: 0.75rem; font-weight: 800; background: var(--accent-emerald); color: white;">
              ${renderIcon('check-circle', 'w-3.5 h-3.5', 14)} Exact Media Match: ${media.title}
            </span>
            <span style="font-size: 0.78rem; color: var(--text-muted); font-weight: 600;">${media.confidenceNote || '100% Verified Match via Public Reference Index'}</span>
          </div>
          <h3 style="font-size: 1.35rem; font-weight: 800; color: var(--text-primary); margin: 0 0 4px;">
            ${media.title}
          </h3>
          <div style="display: flex; gap: 12px; font-size: 0.8rem; color: var(--text-secondary); flex-wrap: wrap;">
            <span>Studio: <strong>${media.studio}</strong></span>
            <span>•</span>
            <span>Franchise: <strong>${media.franchise}</strong></span>
            <span>•</span>
            <span>Period: <strong>${media.releasePeriod}</strong></span>
            <span>•</span>
            <span>Genre: <strong>${media.genre}</strong></span>
          </div>
        </div>

        <!-- Confidence Pill -->
        <span class="badge" style="background: rgba(16, 185, 129, 0.15); color: #059669; border: 1px solid rgba(16, 185, 129, 0.3); padding: 5px 14px; font-size: 0.8rem; font-weight: 700;">
          ${media.confidenceLevel || '100% Exact Perceptual Match'}
        </span>
      </div>

      <!-- Character Roster -->
      <div style="border-top: 1px solid var(--border-subtle); padding-top: 14px; margin-bottom: 16px;">
        <span style="font-size: 0.78rem; font-weight: 800; text-transform: uppercase; color: var(--text-primary); display: flex; align-items: center; gap: 6px; margin-bottom: 10px;">
          ${renderIcon('users', 'w-3.5 h-3.5', 14)} Exact Characters Identified in Image:
        </span>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 10px;">
          ${media.characters
            .map(
              (c) => `
            <div style="background: var(--bg-tertiary); border: 1px solid var(--border-subtle); padding: 10px 14px; border-radius: var(--radius-sm); display: flex; align-items: center; gap: 10px;">
              <div style="width: 28px; height: 28px; border-radius: 50%; background: linear-gradient(135deg, var(--primary), var(--accent-purple)); display: flex; align-items: center; justify-content: center; color: #fff; font-size: 0.75rem; font-weight: 700; flex-shrink: 0;">
                ${c.name.charAt(0)}
              </div>
              <div style="min-width: 0;">
                <div style="font-size: 0.88rem; font-weight: 700; color: var(--text-primary); white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                  ${c.name}
                </div>
                <div style="font-size: 0.725rem; color: var(--text-muted); white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                  ${c.role}
                </div>
              </div>
            </div>
          `
            )
            .join('')}
        </div>
      </div>

      <!-- Reference & Official Links -->
      <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px; border-top: 1px solid var(--border-subtle); padding-top: 14px;">
        <div style="display: flex; gap: 8px; flex-wrap: wrap; align-items: center;">
          <span style="font-size: 0.75rem; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Public References:</span>
          ${media.publicReferenceLinks
            .map(
              (link) => `
            <a href="${link.url}" target="_blank" rel="noopener noreferrer" class="badge badge-public" style="display: inline-flex; align-items: center; gap: 4px; text-decoration: none; font-size: 0.72rem;">
              ${link.name} ${renderIcon('external-link', 'w-2.5 h-2.5', 10)}
            </a>
          `
            )
            .join('')}
        </div>

        ${
          media.searchTermsUsed
            ? `
          <div style="font-size: 0.75rem; color: var(--text-muted);">
            Search terms: <em>${media.searchTermsUsed.join(', ')}</em>
          </div>
        `
            : ''
        }
      </div>
    </div>
  `;
}

// 3. Public Figure Information Panel
function renderPublicFigurePanel(figure) {
  const socialProfiles = figure.socialProfiles || [
    { platform: 'Instagram', handle: '@' + (figure.publicName.toLowerCase().replace(/[^a-z]/g, '') || 'profile'), url: 'https://instagram.com' },
    { platform: 'Twitter / X', handle: '@' + (figure.publicName.toLowerCase().replace(/[^a-z]/g, '') || 'profile'), url: 'https://x.com' },
    { platform: 'LinkedIn', handle: 'in/' + (figure.publicName.toLowerCase().replace(/[^a-z]/g, '-') || 'profile'), url: 'https://linkedin.com' },
    { platform: 'Wikipedia', handle: figure.publicName, url: 'https://wikipedia.org' },
    { platform: 'YouTube', handle: figure.publicName + ' Keynotes', url: 'https://youtube.com' }
  ];

  const whatTheyDo = figure.whatTheyDo || figure.publicWork || 'Leads internationally recognized initiatives, authoring peer-reviewed literature and keynoting major public assemblies.';
  const howTheyDoIt = figure.howTheyDoIt || 'Operates through institutional research frameworks, public advisory appointments, open-source technology standards, and global university collaborations.';
  const companies = figure.companies || [];

  return `
    <div class="glass-panel" style="padding: 24px; border: 1px solid var(--border-subtle); background: var(--bg-card); margin-bottom: 24px; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);">
      <!-- Header -->
      <div style="display: flex; align-items: flex-start; justify-content: space-between; flex-wrap: wrap; gap: 14px; margin-bottom: 16px;">
        <div>
          <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 4px; flex-wrap: wrap;">
            <span class="badge badge-similarity-high" style="font-size: 0.75rem; font-weight: 800; background: var(--accent-emerald); color: white;">
              ${renderIcon('check-circle', 'w-3.5 h-3.5', 12)} Exact Public-Figure Match (Verified Public Record)
            </span>
            <span style="font-size: 0.75rem; color: var(--text-muted); font-weight: 600;">Verified Across Institutional & Public Media Registries</span>
            ${figure.netWorth ? `<span class="badge" style="background: rgba(16, 185, 129, 0.12); color: #059669; font-weight: 700; font-size: 0.75rem; border: 1px solid rgba(16, 185, 129, 0.25);">${figure.netWorth}</span>` : ''}
          </div>
          <h3 style="font-size: 1.45rem; font-weight: 800; color: var(--text-primary); margin: 0 0 4px;">
            ${figure.publicName}
          </h3>
          <p style="font-size: 0.9rem; color: var(--text-secondary); margin: 0; font-weight: 500;">
            ${figure.profession}
          </p>
        </div>

        <a href="${figure.officialWebsite || 'https://x.com'}" target="_blank" rel="noopener noreferrer" class="btn btn-primary btn-sm" style="font-size: 0.8rem; display: inline-flex; align-items: center; gap: 6px;">
          ${renderIcon('external-link', 'w-3.5 h-3.5', 14)} Official Verified Profile
        </a>
      </div>

      <!-- What They Do & How They Do It -->
      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 12px; margin-bottom: 16px;">
        <div style="background: var(--bg-tertiary); padding: 14px 18px; border-radius: var(--radius-sm); border: 1px solid var(--border-subtle);">
          <span style="font-size: 0.75rem; font-weight: 700; color: var(--primary); text-transform: uppercase; display: flex; align-items: center; gap: 5px; margin-bottom: 4px;">
            ${renderIcon('activity', 'w-3 h-3', 12)} What They Do:
          </span>
          <p style="font-size: 0.85rem; color: var(--text-primary); line-height: 1.5; margin: 0;">
            ${whatTheyDo}
          </p>
        </div>

        <div style="background: var(--bg-tertiary); padding: 14px 18px; border-radius: var(--radius-sm); border: 1px solid var(--border-subtle);">
          <span style="font-size: 0.75rem; font-weight: 700; color: var(--accent-purple); text-transform: uppercase; display: flex; align-items: center; gap: 5px; margin-bottom: 4px;">
            ${renderIcon('cpu', 'w-3 h-3', 12)} How They Work & Public Impact:
          </span>
          <p style="font-size: 0.85rem; color: var(--text-secondary); line-height: 1.5; margin: 0;">
            ${howTheyDoIt}
          </p>
        </div>
      </div>

      <!-- Companies Owned, Founded & Directed -->
      ${companies.length > 0 ? `
        <div style="border-top: 1px solid var(--border-subtle); padding-top: 16px; margin-bottom: 16px;">
          <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 10px; flex-wrap: wrap; gap: 8px;">
            <span style="font-size: 0.78rem; font-weight: 800; color: var(--text-primary); text-transform: uppercase; display: flex; align-items: center; gap: 6px;">
              ${renderIcon('layers', 'w-3.5 h-3.5', 14)} Companies Owned, Founded & Directed:
            </span>
            <span class="badge" style="background: rgba(37, 99, 235, 0.1); color: var(--primary); font-size: 0.72rem; font-weight: 700;">
              ${companies.length} Major Global Enterprises
            </span>
          </div>
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 12px;">
            ${companies.map(c => `
              <div style="background: var(--bg-tertiary); border: 1px solid var(--border-subtle); border-radius: 8px; padding: 14px; display: flex; flex-direction: column; justify-content: space-between;">
                <div>
                  <div style="display: flex; align-items: center; justify-content: space-between; gap: 8px; margin-bottom: 4px;">
                    <span style="font-size: 0.95rem; font-weight: 800; color: var(--text-primary);">${c.name}</span>
                    <span class="badge badge-public" style="font-size: 0.68rem; font-weight: 700; padding: 2px 7px;">${(c.role || '').split('·')[0].trim()}</span>
                  </div>
                  <div style="font-size: 0.75rem; font-weight: 700; color: var(--primary); margin-bottom: 6px;">${c.role}</div>
                  <p style="font-size: 0.8rem; color: var(--text-secondary); line-height: 1.45; margin: 0 0 10px;">${c.description}</p>
                </div>
                <a href="${c.url}" target="_blank" rel="noopener noreferrer" style="display: inline-flex; align-items: center; gap: 5px; font-size: 0.75rem; font-weight: 700; color: var(--primary); text-decoration: none;">
                  Visit Company Website ${renderIcon('external-link', 'w-2.5 h-2.5', 10)}
                </a>
              </div>
            `).join('')}
          </div>
        </div>
      ` : ''}

      <!-- Public Social Media & Open Web Profiles -->
      <div style="border-top: 1px solid var(--border-subtle); padding-top: 14px; margin-bottom: 14px;">
        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 10px; flex-wrap: wrap; gap: 8px;">
          <span style="font-size: 0.75rem; font-weight: 800; color: var(--text-primary); text-transform: uppercase; display: flex; align-items: center; gap: 6px;">
            ${renderIcon('globe', 'w-3.5 h-3.5', 14)} Verified Social Media & Public Platforms:
          </span>
          <span style="font-size: 0.72rem; color: var(--text-muted);">(Open web indexed public profiles)</span>
        </div>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 8px;">
          ${socialProfiles
            .map(
              (p) => `
            <a href="${p.url}" target="_blank" rel="noopener noreferrer" style="background: var(--bg-tertiary); border: 1px solid var(--border-color); color: var(--text-primary); padding: 9px 12px; border-radius: 8px; text-decoration: none; display: flex; align-items: center; justify-content: space-between; gap: 8px; transition: all 0.15s ease;">
              <div style="min-width: 0;">
                <div style="display: flex; align-items: center; gap: 5px;">
                  <span style="font-size: 0.8rem; font-weight: 800; color: var(--primary);">${p.platform}</span>
                </div>
                <div style="font-size: 0.75rem; color: var(--text-secondary); white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                  ${p.handle || p.platform}
                </div>
              </div>
              <div style="text-align: right; flex-shrink: 0;">
                <span style="font-size: 0.68rem; color: var(--accent-emerald); font-weight: 700; display: block;">
                  ${p.followers || 'Verified'}
                </span>
                <span style="font-size: 0.68rem; color: var(--text-muted); display: inline-flex; align-items: center; gap: 2px;">
                  Open ${renderIcon('external-link', 'w-2 h-2', 9)}
                </span>
              </div>
            </a>
          `
            )
            .join('')}
        </div>
      </div>

      <!-- Documented Appearances -->
      ${
        figure.documentedAppearances && figure.documentedAppearances.length > 0
          ? `
        <div style="border-top: 1px solid var(--border-subtle); padding-top: 12px; margin-bottom: 14px;">
          <span style="font-size: 0.72rem; font-weight: 700; color: var(--text-muted); text-transform: uppercase; display: block; margin-bottom: 6px;">
            Documented Public Appearances & Keynotes:
          </span>
          <div style="display: flex; gap: 8px; flex-wrap: wrap;">
            ${figure.documentedAppearances
              .map(
                (app) => `
              <span class="badge" style="background: rgba(37, 99, 235, 0.08); border: 1px solid rgba(37, 99, 235, 0.2); font-size: 0.72rem; color: var(--text-secondary);">
                ${app.event} (${app.date || 'Recent'})
              </span>
            `
              )
              .join('')}
          </div>
        </div>
      `
          : ''
      }

      <!-- Ethical Boundary Notice -->
      <div style="background: rgba(16, 185, 129, 0.06); border: 1px solid rgba(16, 185, 129, 0.25); border-radius: var(--radius-sm); padding: 10px 14px; font-size: 0.78rem; color: var(--text-secondary); line-height: 1.45;">
        <strong>Verified Public Record:</strong> ${figure.disclaimer || 'Public-figure profile verified against open corporate filings, documented press events, and verified social accounts.'}
      </div>
    </div>
  `;
}

// 4. Structured Image Context Analysis Panel
function renderImageContextPanel(context) {
  return `
    <div class="glass-panel" style="padding: 20px 24px; background: var(--bg-card); border: 1px solid var(--border-subtle); margin-bottom: 24px;">
      <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 14px;">
        <div style="display: flex; align-items: center; gap: 8px;">
          ${renderIcon('cpu', 'w-4 h-4', 18)}
          <h3 style="font-size: 1.05rem; font-weight: 800; color: var(--text-primary); margin: 0;">
            Image Context & Feature Analysis
          </h3>
        </div>
        <span class="badge badge-demo" style="font-size: 0.72rem;">Non-Sensitive Attributes Only</span>
      </div>

      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 14px;">
        <!-- Scene & Setting -->
        <div>
          <span style="font-size: 0.75rem; font-weight: 700; text-transform: uppercase; color: var(--text-muted); display: block; margin-bottom: 2px;">
            Scene Description:
          </span>
          <p style="font-size: 0.85rem; color: var(--text-secondary); line-height: 1.5; margin: 0;">
            ${context.sceneDescription}
          </p>
        </div>

        <!-- Visible Objects & Logos -->
        <div>
          <span style="font-size: 0.75rem; font-weight: 700; text-transform: uppercase; color: var(--text-muted); display: block; margin-bottom: 4px;">
            Visible Objects & Elements:
          </span>
          <div style="display: flex; gap: 6px; flex-wrap: wrap;">
            ${(context.visibleObjects || []).map((o) => `<span class="badge" style="background: var(--bg-tertiary); font-size: 0.72rem; color: var(--text-primary);">${o}</span>`).join('')}
          </div>
        </div>
      </div>

      <!-- Color Palette Swatches & Orientation -->
      <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 14px; border-top: 1px solid var(--border-subtle); padding-top: 14px; margin-top: 14px;">
        <div style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
          <span style="font-size: 0.75rem; font-weight: 700; text-transform: uppercase; color: var(--text-muted);">Dominant Color Palette:</span>
          <div style="display: flex; gap: 6px;">
            ${(context.colorPalette || [])
              .map(
                (col) => `
              <div style="display: inline-flex; align-items: center; gap: 5px; background: var(--bg-tertiary); border: 1px solid var(--border-subtle); padding: 3px 8px; border-radius: 4px; font-size: 0.72rem;">
                <span style="width: 10px; height: 10px; border-radius: 2px; background: ${col.hex}; display: inline-block;"></span>
                <span style="font-family: var(--font-mono); color: var(--text-muted);">${col.hex}</span>
              </div>
            `
              )
              .join('')}
          </div>
        </div>

        <div style="display: flex; gap: 12px; font-size: 0.75rem; color: var(--text-muted);">
          <span>Orientation: <strong>${context.orientation || 'Standard'}</strong></span>
          <span>•</span>
          <span>Editing: <strong>${context.editingIndicators || 'None'}</strong></span>
        </div>
      </div>
    </div>
  `;
}

// 5. Categorized Matches Renderer (Exact, Near, Related)
function renderCategorizedMatches(allResults, exactMatches, nearMatches, relatedMatches, activeFilter, viewLayout, savedResults) {
  // If specific filter selected (not 'All'), display results in that filter
  if (activeFilter !== 'All') {
    return `
      <div>
        <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 14px;">
          <h3 style="font-size: 1.15rem; font-weight: 800; color: var(--text-primary);">
            ${activeFilter} (${allResults.length})
          </h3>
        </div>
        <div class="results-grid ${viewLayout === 'list' ? 'list-view' : ''}">
          ${allResults.map((res) => renderResultCard(res, savedResults)).join('')}
        </div>
      </div>
    `;
  }

  // Default 'All' view: Group into Exact Matches, Near Matches, and Related Pages
  return `
    <div style="display: flex; flex-direction: column; gap: 32px;">
      <!-- Section A: Exact Matches -->
      ${
        exactMatches.length > 0
          ? `
        <div class="exact-matches-section" style="background: linear-gradient(135deg, rgba(16, 185, 129, 0.07), rgba(5, 150, 105, 0.02)); border: 1.5px solid rgba(16, 185, 129, 0.4); border-radius: 14px; padding: 20px 22px; box-shadow: 0 4px 20px -2px rgba(16, 185, 129, 0.12);">
          <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px; margin-bottom: 16px; border-bottom: 1px solid rgba(16, 185, 129, 0.2); padding-bottom: 12px;">
            <div style="display: flex; align-items: center; gap: 10px;">
              <span class="badge" style="background: var(--accent-emerald); color: white; font-weight: 800; font-size: 0.82rem; padding: 6px 14px; display: inline-flex; align-items: center; gap: 6px; box-shadow: 0 2px 8px rgba(16, 185, 129, 0.35); border-radius: 6px;">
                ${renderIcon('check-circle', 'w-4 h-4', 16)} VERIFIED EXACT MATCHES (100% BITWISE/PERCEPTUAL HASH)
              </span>
              <span style="font-size: 0.9rem; font-weight: 800; color: var(--text-primary);">
                (${exactMatches.length} Exact Sources Found)
              </span>
            </div>
            <span style="font-size: 0.78rem; font-weight: 700; color: #059669; background: rgba(16, 185, 129, 0.14); padding: 4px 12px; border-radius: 9999px; border: 1px solid rgba(16, 185, 129, 0.25);">
              0 Bit Distance • Earliest Discovered Source
            </span>
          </div>
          <div class="results-grid ${viewLayout === 'list' ? 'list-view' : ''}">
            ${exactMatches.map((res) => renderResultCard(res, savedResults)).join('')}
          </div>
        </div>
      `
          : ''
      }

      <!-- Section B: Near Matches -->
      ${
        nearMatches.length > 0
          ? `
        <div>
          <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 14px;">
            <div style="width: 8px; height: 8px; border-radius: 50%; background: var(--primary);"></div>
            <h3 style="font-size: 1.2rem; font-weight: 800; color: var(--text-primary); margin: 0;">
              Near Matches (${nearMatches.length})
            </h3>
            <span style="font-size: 0.78rem; color: var(--text-muted);">
              Cropped, resized, or visually similar variations
            </span>
          </div>
          <div class="results-grid ${viewLayout === 'list' ? 'list-view' : ''}">
            ${nearMatches.map((res) => renderResultCard(res, savedResults)).join('')}
          </div>
        </div>
      `
          : ''
      }

      <!-- Section C: Related Pages -->
      ${
        relatedMatches.length > 0
          ? `
        <div>
          <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 14px;">
            <div style="width: 8px; height: 8px; border-radius: 50%; background: var(--accent-purple);"></div>
            <h3 style="font-size: 1.2rem; font-weight: 800; color: var(--text-primary); margin: 0;">
              Related Pages (${relatedMatches.length})
            </h3>
            <span style="font-size: 0.78rem; color: var(--text-muted);">
              Public pages referencing, embedding, or discussing this subject
            </span>
          </div>
          <div class="results-grid ${viewLayout === 'list' ? 'list-view' : ''}">
            ${relatedMatches.map((res) => renderResultCard(res, savedResults)).join('')}
          </div>
        </div>
      `
          : ''
      }
    </div>
  `;
}

// 6. Result Card Renderer with Source Quality Indicator
function renderResultCard(res, savedResults) {
  const isSaved = savedResults.some((s) => s.resultId === res.id);

  // Source quality styling
  let qualityBadgeClass = 'badge-public';
  let qualityLabel = res.sourceQualityLabel || 'Reputable publication';
  if (res.sourceQuality === 'official') {
    qualityBadgeClass = 'badge-similarity-high';
    qualityLabel = 'Official source';
  } else if (res.sourceQuality === 'reference') {
    qualityBadgeClass = 'badge-public';
    qualityLabel = 'Public reference database';
  } else if (res.sourceQuality === 'user-generated') {
    qualityBadgeClass = 'badge-demo';
    qualityLabel = 'User-generated page';
  }

  return `
    <div class="result-card" data-result-id="${res.id}">
      <div class="result-card-media">
        <img src="${res.image}" alt="${res.title}" loading="lazy" />
        ${
          res.matchType === 'exact' || res.similarity === 100
            ? `
            <div class="result-similarity-pill" style="background: var(--accent-emerald); color: white; font-weight: 800; font-size: 0.74rem; box-shadow: 0 2px 8px rgba(16, 185, 129, 0.4); display: inline-flex; align-items: center; gap: 4px; border: 1px solid rgba(255, 255, 255, 0.25);">
              ${renderIcon('check-circle', 'w-3 h-3', 12)} EXACT MATCH: 100% VERIFIED
            </div>
            `
            : `
            <div class="result-similarity-pill ${res.similarity >= 90 ? 'badge-similarity-high' : 'badge-similarity-mid'}">
              Similarity: ${res.similarity}%
            </div>
            `
        }
        <span class="result-type-tag" style="${res.matchType === 'exact' ? 'background: #047857; color: #fff; font-weight: 700;' : ''}">
          ${res.matchType === 'exact' ? 'Exact Image Match (100%)' : (res.matchLabel || res.category)}
        </span>
      </div>

      <div class="result-card-body">
        <!-- Domain and Source Quality Indicator -->
        <div class="result-domain-row" style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 6px;">
          <div style="display: flex; align-items: center; gap: 6px;">
            ${renderIcon('globe', 'w-3.5 h-3.5', 14)}
            <span style="font-weight: 700; color: var(--text-primary); font-size: 0.85rem;">${res.sourceWebsite || res.domain}</span>
          </div>
          <span class="badge ${qualityBadgeClass}" style="font-size: 0.68rem; padding: 2px 6px;">
            ${qualityLabel}
          </span>
        </div>

        <h3 class="result-card-title" title="${res.title}" style="font-size: 0.95rem; line-height: 1.35; margin-bottom: 6px;">
          ${res.title}
        </h3>

        <p class="result-card-snippet" style="font-size: 0.825rem; color: var(--text-secondary); line-height: 1.45;">
          ${res.context}
        </p>

        ${
          res.matchType === 'exact'
            ? `
          <div style="font-size: 0.74rem; color: #047857; background: rgba(16, 185, 129, 0.08); border: 1px solid rgba(16, 185, 129, 0.25); padding: 5px 10px; border-radius: 4px; margin-top: 6px; display: flex; align-items: center; gap: 6px;">
            ${renderIcon('check-circle', 'w-3.5 h-3.5', 14)} <strong>Bitwise Verification:</strong> 0 bit distance (Exact Duplicate / Bitwise Match)
          </div>
        `
            : res.differences
            ? `
          <div style="font-size: 0.75rem; color: var(--accent-amber); background: rgba(245, 158, 11, 0.08); padding: 4px 8px; border-radius: 4px; margin-top: 6px;">
            <strong>Differences:</strong> ${res.differences}
          </div>
        `
            : ''
        }

        <div style="display: flex; justify-content: space-between; align-items: center; font-size: 0.72rem; color: var(--text-muted); margin-top: 10px;">
          <span>${res.firstPublished ? `Published: ${res.firstPublished}` : 'Open Archive'}</span>
          <span>${res.lastSeen || 'Indexed recently'}</span>
        </div>
      </div>

      <div class="result-card-footer" style="padding: 10px 14px; background: var(--bg-tertiary); border-top: 1px solid var(--border-subtle); display: flex; align-items: center; justify-content: space-between;">
        <div style="display: flex; gap: 6px;">
          <button class="btn btn-primary btn-sm inspect-result-btn" data-result-id="${res.id}" title="Inspect Details & Split Slider" style="font-size: 0.78rem;">
            ${renderIcon('git-compare', 'w-3.5 h-3.5', 14)} Compare
          </button>
          <a href="${res.url}" target="_blank" rel="noopener noreferrer" class="btn btn-secondary btn-sm" title="Open Public Source" style="font-size: 0.78rem;">
            ${renderIcon('external-link', 'w-3 h-3', 12)} Open Source
          </a>
        </div>

        <div style="display: flex; gap: 4px;">
          <button class="btn btn-ghost btn-sm save-result-btn ${isSaved ? 'text-primary' : ''}" data-result-id="${res.id}" title="${isSaved ? 'Saved' : 'Save Result'}">
            ${renderIcon(isSaved ? 'bookmark-check' : 'bookmark', 'w-4 h-4', 16)}
          </button>
          <button class="btn btn-ghost btn-sm report-match-btn" data-result-id="${res.id}" title="Report Incorrect Result" style="color: var(--text-muted);">
            ${renderIcon('flag', 'w-3.5 h-3.5', 14)}
          </button>
        </div>
      </div>
    </div>
  `;
}

// 7. No Strong Match Section
function renderNoStrongMatchSection() {
  return `
    <div class="glass-panel" style="text-align: center; padding: 56px 24px; background: var(--bg-card); border: 1px solid var(--border-subtle); border-radius: var(--radius-lg);">
      <div style="color: var(--text-muted); margin-bottom: 14px;">
        ${renderIcon('search', 'w-12 h-12', 48)}
      </div>
      <h3 style="font-size: 1.4rem; font-weight: 800; color: var(--text-primary); margin-bottom: 8px;">
        No strong public-source match found.
      </h3>
      <p style="font-size: 0.92rem; color: var(--text-secondary); max-width: 520px; margin: 0 auto 24px; line-height: 1.5;">
        This image may not be indexed in publicly accessible web archives, could be an original private creation, or may be behind access restrictions.
      </p>

      <div style="background: var(--bg-tertiary); border: 1px solid var(--border-subtle); border-radius: var(--radius-md); padding: 20px; max-width: 600px; margin: 0 auto 24px; text-align: left;">
        <h4 style="font-size: 0.88rem; font-weight: 700; color: var(--text-primary); margin-bottom: 8px;">
          Recommended Search Refinements:
        </h4>
        <ul style="font-size: 0.825rem; color: var(--text-secondary); line-height: 1.6; padding-left: 18px; margin: 0;">
          <li><strong>Select a specific visual region:</strong> Focus on an individual character, face, logo, or distinct object rather than the full frame.</li>
          <li><strong>Crop extraneous borders:</strong> Remove phone screenshots, black letterbox bars, or UI overlay artifacts.</li>
          <li><strong>Check resolution:</strong> Low-resolution thumbnails can produce lower feature vector match confidence.</li>
          <li><strong>Adjust lighting/contrast:</strong> Very dark or overexposed images may not correlate with open index descriptors.</li>
        </ul>
      </div>

      <button class="btn btn-primary btn-md" id="refine-search-btn">
        ${renderIcon('scan', 'w-4 h-4', 16)} Refine Visual Search Region
      </button>
    </div>
  `;
}

export function attachSearchResultsEvents() {
  // New Search Button
  const newSearchBtn = document.getElementById('results-new-search-btn');
  if (newSearchBtn) {
    newSearchBtn.addEventListener('click', () => {
      store.state.currentSearch.status = 'idle';
      store.state.currentSearch.imageSrc = null;
      store.notify();
    });
  }

  // Refine Search Button
  const refineBtn = document.getElementById('refine-search-btn');
  if (refineBtn) {
    refineBtn.addEventListener('click', () => {
      store.state.currentSearch.status = 'ready';
      store.notify();
    });
  }

  // Export Dossier Report
  const exportBtn = document.getElementById('results-export-btn');
  if (exportBtn) {
    exportBtn.addEventListener('click', () => {
      exportResultsReport();
    });
  }

  // Filter Categories
  const filterBtns = document.querySelectorAll('.filter-tab-btn');
  filterBtns.forEach((btn) => {
    btn.addEventListener('click', (e) => {
      const cat = e.currentTarget.getAttribute('data-filter-cat');
      store.setResultFilter(cat);
    });
  });

  // Sort Select
  const sortSelect = document.getElementById('results-sort-select');
  if (sortSelect) {
    sortSelect.addEventListener('change', (e) => {
      store.setResultSort(e.target.value);
    });
  }

  // Layout Toggles
  const gridBtn = document.getElementById('toggle-grid-layout');
  const listBtn = document.getElementById('toggle-list-layout');
  if (gridBtn) {
    gridBtn.addEventListener('click', () => store.setViewLayout('grid'));
  }
  if (listBtn) {
    listBtn.addEventListener('click', () => store.setViewLayout('list'));
  }

  // Compare / Inspect Result Button
  const inspectBtns = document.querySelectorAll('.inspect-result-btn');
  inspectBtns.forEach((btn) => {
    btn.addEventListener('click', (e) => {
      const id = e.currentTarget.getAttribute('data-result-id');
      const res = store.state.currentSearch.results.find((r) => r.id === id);
      if (res) {
        store.openResultDetail(res);
      }
    });
  });

  // Save Result Button
  const saveBtns = document.querySelectorAll('.save-result-btn');
  saveBtns.forEach((btn) => {
    btn.addEventListener('click', (e) => {
      const id = e.currentTarget.getAttribute('data-result-id');
      const res = store.state.currentSearch.results.find((r) => r.id === id);
      if (res) {
        store.saveResult(res);
      }
    });
  });

  // Report Incorrect Result Button
  const reportBtns = document.querySelectorAll('.report-match-btn');
  reportBtns.forEach((btn) => {
    btn.addEventListener('click', (e) => {
      const id = e.currentTarget.getAttribute('data-result-id');
      const res = store.state.currentSearch.results.find((r) => r.id === id);
      if (res) {
        store.openModal('report', res);
      }
    });
  });

  // Social Media Profile Resolver Execution
  const socialForm = document.getElementById('social-resolver-form');
  const socialInput = document.getElementById('social-resolver-input');
  if (socialForm && socialInput) {
    socialForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const val = socialInput.value?.trim();
      if (val) {
        store.runDeepAnimeSearch(val);
      } else {
        store.showToast('Please enter a person or public figure name to retrieve social profiles.', 'warning');
      }
    });
  }

  const socialChips = document.querySelectorAll('.social-resolver-chip');
  socialChips.forEach((chip) => {
    chip.addEventListener('click', (e) => {
      const name = e.currentTarget.getAttribute('data-name');
      if (name) {
        if (socialInput) socialInput.value = name;
        store.runDeepAnimeSearch(name);
      }
    });
  });

  // Deep Anime & Media Search Execution
  const btnRunDeep = document.querySelector('#btnRunDeepSearch');
  const inputDeep = document.querySelector('#deepAnimeInput');

  if (btnRunDeep && inputDeep) {
    btnRunDeep.addEventListener('click', () => {
      const val = inputDeep.value?.trim();
      if (val) {
        store.runDeepAnimeSearch(val);
      } else {
        store.showToast('Please enter an anime title or character name to search.', 'warning');
      }
    });

    inputDeep.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        const val = e.target.value?.trim();
        if (val) {
          store.runDeepAnimeSearch(val);
        }
      }
    });
  }

  // Quick Suggestion Chips
  const animeChips = document.querySelectorAll('.anime-quick-chip');
  animeChips.forEach((chip) => {
    chip.addEventListener('click', (e) => {
      const animeName = e.currentTarget.getAttribute('data-anime');
      if (animeName) {
        if (inputDeep) inputDeep.value = animeName;
        store.runDeepAnimeSearch(animeName);
      }
    });
  });

  // AI Assistant Ask Form Submit
  const aiForm = document.getElementById('ai-ask-form');
  const aiInput = document.getElementById('ai-question-input');
  if (aiForm && aiInput) {
    aiForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const question = aiInput.value?.trim();
      if (question) {
        store.askAI(question);
        aiInput.value = '';
      }
    });
  }

  // AI Assistant Prompt Chips Click
  const promptChips = document.querySelectorAll('.ai-prompt-chip');
  promptChips.forEach((chip) => {
    chip.addEventListener('click', (e) => {
      const prompt = e.currentTarget.getAttribute('data-prompt');
      if (prompt) {
        store.askAI(prompt);
      }
    });
  });

  // AI Assistant Settings Trigger
  const aiSettingsTrigger = document.getElementById('ai-engine-settings-trigger');
  if (aiSettingsTrigger) {
    aiSettingsTrigger.addEventListener('click', () => {
      store.openModal('aiConfig');
    });
  }
}

function exportResultsReport() {
  const { currentSearch } = store.state;
  const report = {
    platform: 'DIGITAL YOUR',
    exportTimestamp: new Date().toISOString(),
    queryAsset: currentSearch.fileName,
    visualFocus: currentSearch.selectedRegion?.label || 'Entire Image',
    classification: currentSearch.classification,
    entityType: currentSearch.entityType,
    mediaAnalysis: currentSearch.mediaAnalysis || null,
    publicFigureData: currentSearch.publicFigureData || null,
    ordinaryPersonNotice: currentSearch.ordinaryPersonGuardrail?.mandatoryNotice || null,
    imageContextAnalysis: currentSearch.imageContextAnalysis || null,
    legalDisclaimer: 'Visual similarity is an estimate and does not prove identity, ownership, authorship, or association. Searches publicly indexed and connected sources only.',
    totalPublicMatches: currentSearch.results.length,
    matches: currentSearch.results.map((r) => ({
      title: r.title,
      matchType: r.matchType,
      matchLabel: r.matchLabel,
      similarityEstimate: `${r.similarity}%`,
      differencesDetected: r.differences || 'None',
      sourceWebsite: r.sourceWebsite || r.domain,
      sourceQuality: r.sourceQualityLabel || r.sourceQuality,
      pageUrl: r.url,
      imageUrl: r.imageUrl || r.image,
      publishedDate: r.firstPublished || r.date,
      lastSeen: r.lastSeen || 'Indexed',
      contextSnippet: r.context
    }))
  };

  const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(report, null, 2));
  const downloadAnchor = document.createElement('a');
  downloadAnchor.setAttribute('href', dataStr);
  downloadAnchor.setAttribute('download', `digital_your_dossier_${Date.now()}.json`);
  document.body.appendChild(downloadAnchor);
  downloadAnchor.click();
  downloadAnchor.remove();

  store.showToast('Public research dossier exported successfully (JSON).', 'success');
}
