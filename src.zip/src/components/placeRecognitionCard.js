// src/components/placeRecognitionCard.js
// Amalfi Coast Place Recognition Demonstration with Interactive Radar Map and Pin

import { renderIcon } from '../utils/icons.js';

export function renderPlaceRecognitionCard() {
  return `
    <div class="dy-place-stage" id="dy-place-stage">
      <!-- Left: Stunning Travel Photograph with Mini-Map Radar -->
      <div class="dy-place-visual-wrap" id="dy-place-visual-wrap">
        <img 
          src="/demo/amalfi_coast.jpg" 
          alt="Amalfi Coast, Campania, Italy" 
          class="dy-place-img" 
          id="dy-place-img"
        />

        <!-- Floating Map Radar Overlay with Dropping Location Pin -->
        <div class="dy-place-map-overlay">
          <div class="dy-map-radar">
            <!-- Simplified Radar Grid -->
            <svg viewBox="0 0 140 60" style="width: 100%; height: 100%; position: absolute; inset: 0;">
              <circle cx="70" cy="30" r="12" fill="none" stroke="rgba(79, 70, 229, 0.2)" stroke-width="1" />
              <circle cx="70" cy="30" r="22" fill="none" stroke="rgba(79, 70, 229, 0.15)" stroke-width="1" />
              <line x1="70" y1="5" x2="70" y2="55" stroke="rgba(79, 70, 229, 0.15)" stroke-dasharray="2 2" />
              <line x1="15" y1="30" x2="125" y2="30" stroke="rgba(79, 70, 229, 0.15)" stroke-dasharray="2 2" />
            </svg>
            <div class="dy-map-pin" title="Amalfi, Campania, Italy (40.6340° N, 14.6027° E)"></div>
          </div>
          <div class="dy-map-coords-text">40.6340° N, 14.6027° E</div>
        </div>
      </div>

      <!-- Right: Structured Place Intelligence Card -->
      <div class="dy-place-info-panel">
        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 14px;">
          <div class="dy-status-pill">
            <span class="dy-dot"></span>
            <span>Place Detected • 98% Confidence</span>
          </div>
          <span style="font-size: 0.75rem; font-family: 'JetBrains Mono', monospace; color: var(--dy-text-muted);">
            LOC_ID #IT-84011
          </span>
        </div>

        <h3 style="font-size: 1.85rem; font-weight: 800; letter-spacing: -0.03em; color: var(--dy-text-primary); margin-bottom: 4px;">
          Amalfi Coast
        </h3>
        <p style="font-size: 0.96rem; color: var(--dy-indigo); font-weight: 600; margin-bottom: 20px;">
          Campania, Southern Italy
        </p>

        <div style="display: flex; flex-direction: column; gap: 12px; margin-bottom: 28px;">
          <div class="dy-card-field-row">
            <span class="dy-card-field-label">Famous For</span>
            <span class="dy-card-field-value">Pastel clifftop villages, terraced lemon groves, and dramatic Mediterranean coastline.</span>
          </div>

          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
            <div class="dy-card-field-row">
              <span class="dy-card-field-label">Languages</span>
              <span class="dy-card-field-value">Italian, English</span>
            </div>
            <div class="dy-card-field-row">
              <span class="dy-card-field-label">Culture & Climate</span>
              <span class="dy-card-field-value">Mediterranean Maritime</span>
            </div>
          </div>

          <div class="dy-card-field-row">
            <span class="dy-card-field-label">Best Time to Visit</span>
            <span class="dy-card-field-value">May to September (Sunlight: 14h / day · Avg Temp: 27°C)</span>
          </div>
        </div>

        <button class="dy-btn-primary-cta" id="dy-explore-place-btn" style="padding: 12px 24px; font-size: 0.94rem;">
          <span>Explore Place Insights</span>
          <span class="dy-cta-arrow">→</span>
        </button>
      </div>
    </div>
  `;
}

export function attachPlaceEvents() {
  const btn = document.getElementById('dy-explore-place-btn');
  if (btn) {
    btn.addEventListener('click', () => {
      // Direct user to start real image search with place query or open search modal
      const startBtn = document.getElementById('hero-primary-cta');
      if (startBtn) startBtn.click();
    });
  }
}
