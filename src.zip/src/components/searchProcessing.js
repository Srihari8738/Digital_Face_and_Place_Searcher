// src/components/searchProcessing.js
// Realistic animated 10-stage search HUD with radar scanner visual, progress indicator, live source count, and cancel/retry actions

import { store } from '../state.js';
import { renderIcon } from '../utils/icons.js';
import { SEARCH_STAGES } from '../data/mockData.js';

export function renderSearchProcessing() {
  const { currentSearch } = store.state;
  const currentStageNum = currentSearch.processingStage || 1;
  const activeStage = SEARCH_STAGES[currentStageNum - 1] || SEARCH_STAGES[0];
  const progressPercent = Math.min(100, Math.round((currentStageNum / 10) * 100));
  const estimatedSecondsLeft = Math.max(1, Math.round((10 - currentStageNum) * 0.35));
  const sourcesCount = (currentSearch.sourcesReviewedCount || 140).toLocaleString();
  const confidenceVal = currentSearch.matchConfidenceMeter || 45;

  return `
    <div class="search-view">
      <div class="processing-container">
        <!-- Environmental Mode Badge & Disclaimers -->
        <div style="display: flex; gap: 8px; justify-content: center; flex-wrap: wrap; margin-bottom: 20px;">
          <span class="badge badge-demo">
            ${renderIcon('terminal', 'w-3 h-3', 12)} Prototype mode — representative public-source demo results.
          </span>
          <span class="badge badge-privacy">
            ${renderIcon('shield-check', 'w-3 h-3', 12)} Zero-Retention Ephemeral Memory
          </span>
        </div>

        <!-- Animated Scanning Radar Box -->
        <div class="radar-scanner-box">
          <div class="radar-ring inner"></div>
          <div class="radar-ring mid"></div>
          <div class="radar-crosshair-h"></div>
          <div class="radar-crosshair-v"></div>
          <div class="radar-sweep-beam"></div>
          <img src="${currentSearch.imageSrc}" alt="Target image under analysis" class="radar-target-thumb" />
        </div>

        <!-- Stage Title & Description -->
        <div style="margin-bottom: 8px; text-align: center;">
          <h2 style="font-size: 1.5rem; margin-bottom: 4px;">
            Stage ${currentStageNum}: ${activeStage.title}...
          </h2>
          <p style="font-size: 0.9rem; color: var(--text-secondary); max-width: 520px; margin: 0 auto;">
            ${activeStage.desc}
          </p>
        </div>

        <!-- Progress Bar, Metrics & Estimated Time -->
        <div style="width: 100%; max-width: 580px; margin: 20px 0 16px;">
          <div style="display: flex; justify-content: space-between; font-size: 0.8rem; font-weight: 600; color: var(--text-muted); margin-bottom: 6px;">
            <span>Stage ${currentStageNum} of 10 (${progressPercent}%)</span>
            <span>~${estimatedSecondsLeft}s remaining</span>
          </div>
          <div class="usage-bar-track" style="height: 9px; margin: 0; background: var(--bg-tertiary); border: 1px solid var(--border-subtle); border-radius: var(--radius-full); overflow: hidden;">
            <div class="usage-bar-fill" style="width: ${progressPercent}%; height: 100%; background: linear-gradient(90deg, var(--primary), var(--accent-cyan)); transition: width 0.3s ease;"></div>
          </div>
        </div>

        <!-- Live Investigation HUD Metrics Bar -->
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 12px; width: 100%; max-width: 580px; margin-bottom: 24px;">
          <div style="background: var(--bg-tertiary); border: 1px solid var(--border-subtle); border-radius: var(--radius-md); padding: 10px 14px; text-align: center;">
            <span style="font-size: 0.7rem; text-transform: uppercase; color: var(--text-muted); font-weight: 700; display: block;">Sources Reviewed</span>
            <span style="font-size: 1.15rem; font-weight: 800; color: var(--accent-cyan);">${sourcesCount}</span>
          </div>
          <div style="background: var(--bg-tertiary); border: 1px solid var(--border-subtle); border-radius: var(--radius-md); padding: 10px 14px; text-align: center;">
            <span style="font-size: 0.7rem; text-transform: uppercase; color: var(--text-muted); font-weight: 700; display: block;">Match Confidence</span>
            <span style="font-size: 1.15rem; font-weight: 800; color: var(--accent-emerald);">${confidenceVal}%</span>
          </div>
          <div style="background: var(--bg-tertiary); border: 1px solid var(--border-subtle); border-radius: var(--radius-md); padding: 10px 14px; text-align: center;">
            <span style="font-size: 0.7rem; text-transform: uppercase; color: var(--text-muted); font-weight: 700; display: block;">Search Engine</span>
            <span style="font-size: 0.85rem; font-weight: 700; color: var(--text-primary); margin-top: 3px; display: block;">
              ${store.state.geminiApiKey ? 'Gemini 2.0 Vision' : 'Neural Core v4'}
            </span>
          </div>
        </div>

        <!-- Provider Status Banner -->
        <div style="background: rgba(59, 130, 246, 0.06); border: 1px solid rgba(59, 130, 246, 0.2); border-radius: var(--radius-md); padding: 12px 18px; width: 100%; max-width: 580px; display: flex; align-items: center; gap: 10px; margin-bottom: 24px;">
          <div class="pulse-indicator" style="width: 8px; height: 8px; border-radius: 50%; background: var(--accent-cyan); flex-shrink: 0;"></div>
          <span style="font-size: 0.825rem; color: var(--text-secondary); font-family: var(--font-mono); white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
            ${currentSearch.providerStatus || 'Querying indexed public sources...'}
          </span>
        </div>

        <!-- 10 Stages Progressive Checklist -->
        <div class="processing-stages-list" style="max-width: 580px; width: 100%;">
          ${SEARCH_STAGES.map((st) => {
            let statusClass = 'pending';
            let iconMarkup = renderIcon('circle', 'w-3 h-3', 12);

            if (st.stage < currentStageNum) {
              statusClass = 'completed';
              iconMarkup = renderIcon('check', 'w-3.5 h-3.5', 14);
            } else if (st.stage === currentStageNum) {
              statusClass = 'active';
              iconMarkup = renderIcon('scan', 'w-3.5 h-3.5', 14);
            }

            return `
              <div class="stage-step-item ${statusClass}" style="padding: 10px 14px;">
                <div class="stage-status-icon" style="width: 26px; height: 26px;">
                  ${iconMarkup}
                </div>
                <div style="flex: 1; min-width: 0;">
                  <div style="font-size: 0.85rem; font-weight: 700; color: ${statusClass === 'active' ? 'var(--primary)' : 'var(--text-primary)'};">
                    ${st.stage}. ${st.title}
                  </div>
                  <div style="font-size: 0.75rem; color: var(--text-muted); white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                    ${st.desc}
                  </div>
                </div>
                ${
                  statusClass === 'completed'
                    ? `<span style="font-size: 0.72rem; color: var(--accent-emerald); font-weight: 700;">Verified</span>`
                    : statusClass === 'active'
                    ? `<span style="font-size: 0.72rem; color: var(--primary); font-weight: 700;">Scanning</span>`
                    : `<span style="font-size: 0.72rem; color: var(--text-muted);">Queued</span>`
                }
              </div>
            `;
          }).join('')}
        </div>

        <!-- Privacy & Public Source Perimeter Notice -->
        <div style="background: var(--bg-tertiary); border: 1px solid var(--border-subtle); border-radius: var(--radius-md); padding: 14px 18px; max-width: 580px; margin: 20px 0 24px; display: flex; gap: 12px; align-items: flex-start;">
          <div style="color: var(--primary); margin-top: 1px;">
            ${renderIcon('shield-check', 'w-4 h-4', 18)}
          </div>
          <p style="font-size: 0.78rem; color: var(--text-secondary); line-height: 1.5; margin: 0;">
            <strong>Public search boundary:</strong> Searches publicly indexed and connected sources. Results depend on source availability, indexing, regional access, and search-provider coverage. DIGITAL YOUR never accesses private accounts or surveillance feeds.
          </p>
        </div>

        <!-- Control Actions (Cancel & Retry) -->
        <div style="display: flex; gap: 12px; justify-content: center;">
          <button class="btn btn-secondary btn-sm" id="cancel-search-btn">
            ${renderIcon('x-circle', 'w-4 h-4', 16)} Cancel Search
          </button>
          <button class="btn btn-ghost btn-sm" id="retry-search-btn">
            ${renderIcon('refresh', 'w-4 h-4', 16)} Restart Pipeline
          </button>
        </div>
      </div>
    </div>
  `;
}

export function attachSearchProcessingEvents() {
  const cancelBtn = document.getElementById('cancel-search-btn');
  if (cancelBtn) {
    cancelBtn.addEventListener('click', () => {
      store.cancelSearch();
    });
  }

  const retryBtn = document.getElementById('retry-search-btn');
  if (retryBtn) {
    retryBtn.addEventListener('click', () => {
      store.cancelSearch();
      setTimeout(() => {
        store.startSearchExecution();
      }, 100);
    });
  }
}
