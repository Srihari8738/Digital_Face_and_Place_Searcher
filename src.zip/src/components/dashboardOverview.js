// src/components/dashboardOverview.js
// Dashboard Overview: Welcome banner, usage metrics, quick search CTA, recent searches, saved items, and privacy notice

import { store } from '../state.js';
import { renderIcon } from '../utils/icons.js';
import { COMING_SOON_FEATURES } from '../data/mockData.js';

export function renderDashboardOverview() {
  const { user, searchHistory, savedResults } = store.state;
  const remaining = store.remainingSearches;
  const recentSearches = searchHistory.slice(0, 3);
  const recentSaved = savedResults.slice(0, 3);

  return `
    <div class="overview-view">
      <!-- Welcome & Primary CTA Banner -->
      <div class="welcome-banner">
        <div class="welcome-text">
          <div style="display: inline-flex; align-items: center; gap: 6px; margin-bottom: 8px;">
            <span class="badge badge-privacy">
              ${renderIcon('shield-check', 'w-3.5 h-3.5', 14)} Zero-Retention Privacy Mode
            </span>
          </div>
          <h1>Welcome back, ${user.name}</h1>
          <p>
            Explore where images appear across legally accessible, publicly indexed web records. Your searches are processed strictly in volatile memory.
          </p>
          <div style="display: flex; gap: 14px; margin-top: 24px; flex-wrap: wrap;">
            <button class="btn btn-primary btn-lg" id="overview-new-search-btn">
              ${renderIcon('search', 'w-5 h-5', 20)}
              Start New Search
            </button>
            <button class="btn btn-secondary btn-lg" id="overview-view-history-btn">
              ${renderIcon('history', 'w-5 h-5', 20)}
              Review Search History
            </button>
          </div>
        </div>

        <div style="display: none; @media(min-width: 900px){display: block;}">
          <div class="radar-scanner-box" style="width: 130px; height: 130px; margin: 0;">
            <div class="radar-ring inner"></div>
            <div class="radar-ring mid"></div>
            <div class="radar-sweep-beam"></div>
            <img src="/demo/elena.jpg" alt="Active Index" class="radar-target-thumb" style="width: 50px; height: 50px;" />
          </div>
        </div>
      </div>

      <!-- Quick Metrics Grid -->
      <div class="stats-grid">
        <!-- Metric 1: Searches Remaining -->
        <div class="stat-card">
          <div class="stat-card-top">
            <span style="font-size: 0.85rem; font-weight: 600;">Evaluation Quota</span>
            ${renderIcon('zap', 'w-4 h-4', 18)}
          </div>
          <div class="stat-val" style="color: ${remaining > 0 ? 'var(--accent-emerald)' : 'var(--accent-rose)'};">
            ${remaining} / ${user.searchesLimit}
          </div>
          <div class="stat-desc">
            ${remaining} complimentary public-source searches remaining.
          </div>
          <div style="margin-top: 6px; display: flex; justify-content: space-between; align-items: center;">
            <button class="btn btn-ghost btn-sm" id="overview-reset-quota-btn" style="padding: 2px 0; font-size: 0.75rem; color: var(--primary);">
              Reset Demo Quota
            </button>
            <button class="btn btn-ghost btn-sm" id="overview-upgrade-btn" style="padding: 2px 0; font-size: 0.75rem; color: var(--accent-cyan);">
              Upgrade Pro →
            </button>
          </div>
        </div>

        <!-- Metric 2: Completed Searches -->
        <div class="stat-card">
          <div class="stat-card-top">
            <span style="font-size: 0.85rem; font-weight: 600;">Total Queries</span>
            ${renderIcon('activity', 'w-4 h-4', 18)}
          </div>
          <div class="stat-val">
            ${user.searchesUsed}
          </div>
          <div class="stat-desc">
            All stored locally with one-click full history purge.
          </div>
        </div>

        <!-- Metric 3: Saved Findings -->
        <div class="stat-card">
          <div class="stat-card-top">
            <span style="font-size: 0.85rem; font-weight: 600;">Saved Findings</span>
            ${renderIcon('folder-heart', 'w-4 h-4', 18)}
          </div>
          <div class="stat-val">
            ${savedResults.length}
          </div>
          <div class="stat-desc">
            Organized across 3 verified public collections.
          </div>
        </div>

        <!-- Metric 4: Privacy Boundary Status -->
        <div class="stat-card">
          <div class="stat-card-top">
            <span style="font-size: 0.85rem; font-weight: 600;">Index Boundary</span>
            ${renderIcon('shield-check', 'w-4 h-4', 18)}
          </div>
          <div class="stat-val" style="font-size: 1.6rem; color: var(--accent-cyan); display: flex; align-items: center; gap: 8px;">
            <span>Public Web</span>
          </div>
          <div class="stat-desc">
            Zero private logins, zero surveillance feeds, zero identity claims.
          </div>
        </div>
      </div>

      <!-- Main Columns: Recent Searches & Saved Results -->
      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(360px, 1fr)); gap: 28px;">
        <!-- Left: Recent Searches -->
        <div class="glass-panel" style="padding: 24px;">
          <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px;">
            <div style="display: flex; align-items: center; gap: 8px;">
              ${renderIcon('history', 'w-5 h-5', 20)}
              <h3 style="font-size: 1.15rem;">Recent Searches</h3>
            </div>
            <button class="btn btn-ghost btn-sm" id="overview-all-history-link" style="color: var(--primary); font-size: 0.825rem;">
              View all (${searchHistory.length})
            </button>
          </div>

          ${
            recentSearches.length === 0
              ? `
              <div style="text-align: center; padding: 36px 16px; color: var(--text-muted);">
                ${renderIcon('scan', 'w-10 h-10', 40)}
                <p style="margin-top: 12px; font-size: 0.9rem;">No search history yet.</p>
                <button class="btn btn-primary btn-sm" id="empty-start-search-btn" style="margin-top: 14px;">
                  Launch First Search
                </button>
              </div>
            `
              : `
              <div style="display: flex; flex-direction: column; gap: 12px;">
                ${recentSearches
                  .map(
                    (s) => `
                  <div class="history-item-row" style="padding: 12px 14px;">
                    <div style="display: flex; align-items: center; gap: 12px; min-width: 0;">
                      <img src="${s.image}" alt="${s.name}" class="history-thumb" style="width: 44px; height: 44px;" />
                      <div style="min-width: 0;">
                        <h4 style="font-size: 0.88rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                          ${s.name}
                        </h4>
                        <div style="display: flex; align-items: center; gap: 8px; font-size: 0.75rem; color: var(--text-muted); margin-top: 2px;">
                          <span>${s.date}</span>
                          <span>•</span>
                          <span style="color: var(--accent-cyan);">${s.resultCount} results</span>
                        </div>
                      </div>
                    </div>
                    <button class="btn btn-secondary btn-sm open-history-btn" data-history-id="${s.id}" title="Reopen Search">
                      ${renderIcon('arrow-right', 'w-3.5 h-3.5', 14)}
                    </button>
                  </div>
                `
                  )
                  .join('')}
              </div>
            `
          }
        </div>

        <!-- Right: Recently Saved Findings -->
        <div class="glass-panel" style="padding: 24px;">
          <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px;">
            <div style="display: flex; align-items: center; gap: 8px;">
              ${renderIcon('bookmark', 'w-5 h-5', 20)}
              <h3 style="font-size: 1.15rem;">Recently Saved</h3>
            </div>
            <button class="btn btn-ghost btn-sm" id="overview-all-saved-link" style="color: var(--primary); font-size: 0.825rem;">
              View all (${savedResults.length})
            </button>
          </div>

          ${
            recentSaved.length === 0
              ? `
              <div style="text-align: center; padding: 36px 16px; color: var(--text-muted);">
                ${renderIcon('folder-heart', 'w-10 h-10', 40)}
                <p style="margin-top: 12px; font-size: 0.9rem;">No saved results yet.</p>
                <p style="font-size: 0.8rem; color: var(--text-muted); margin-top: 4px;">
                  Bookmark interesting findings directly from search result cards.
                </p>
              </div>
            `
              : `
              <div style="display: flex; flex-direction: column; gap: 12px;">
                ${recentSaved
                  .map(
                    (item) => `
                  <div class="history-item-row" style="padding: 12px 14px;">
                    <div style="display: flex; align-items: center; gap: 12px; min-width: 0;">
                      <img src="${item.image}" alt="${item.title}" class="history-thumb" style="width: 44px; height: 44px;" />
                      <div style="min-width: 0;">
                        <h4 style="font-size: 0.88rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                          ${item.title}
                        </h4>
                        <div style="display: flex; align-items: center; gap: 8px; font-size: 0.75rem; color: var(--text-muted); margin-top: 2px;">
                          <span>${item.domain}</span>
                          <span>•</span>
                          <span style="color: var(--accent-emerald);">${item.similarity}% match</span>
                        </div>
                      </div>
                    </div>
                    <button class="btn btn-secondary btn-sm open-saved-detail-btn" data-saved-id="${item.id}" title="Inspect Details">
                      ${renderIcon('external-link', 'w-3.5 h-3.5', 14)}
                    </button>
                  </div>
                `
                  )
                  .join('')}
              </div>
            `
          }
        </div>
      </div>

      <!-- Prototype Environment & Responsible Framing Notice -->
      <div style="background: rgba(245, 158, 11, 0.08); border: 1px solid rgba(245, 158, 11, 0.25); border-radius: var(--radius-lg); padding: 20px 24px; display: flex; align-items: flex-start; gap: 16px;">
        <div style="color: var(--accent-amber); margin-top: 2px;">
          ${renderIcon('alert-circle', 'w-5 h-5', 22)}
        </div>
        <div>
          <h4 style="font-size: 0.95rem; color: var(--accent-amber); margin-bottom: 4px;">
            Prototype Environment Notice & Ethical Boundary
          </h4>
          <p style="font-size: 0.85rem; color: var(--text-secondary); line-height: 1.5;">
            DIGITAL YOUR is a public-source reverse image discovery prototype. Results are simulated using representative publicly indexed articles, institutional directories, and open archives. Visual similarity percentages reflect algorithmic feature proximity and must never be interpreted as verified personal identity, legal affiliation, or ownership.
          </p>
        </div>
      </div>

      <!-- Coming Soon Preview Cards -->
      <div>
        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 18px;">
          <h3 style="font-size: 1.25rem;">Upcoming Platform Capabilities</h3>
          <span style="font-size: 0.8rem; color: var(--text-muted);">Roadmap Q4 2026 – 2027</span>
        </div>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 18px;">
          ${COMING_SOON_FEATURES.slice(0, 3)
            .map(
              (f) => `
            <div class="glass-card" style="padding: 20px; cursor: pointer;" class="overview-cs-card" data-cs-id="${f.id}">
              <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px;">
                <span class="badge" style="background: rgba(139, 92, 246, 0.15); color: var(--accent-purple);">
                  ${f.badge}
                </span>
                ${renderIcon('sparkle', 'w-4 h-4', 16)}
              </div>
              <h4 style="font-size: 1rem; margin-bottom: 6px;">${f.title}</h4>
              <p style="font-size: 0.825rem; color: var(--text-muted); line-height: 1.5;">
                ${f.description}
              </p>
              <button class="btn btn-ghost btn-sm" style="margin-top: 14px; padding: 0; color: var(--primary); font-size: 0.8rem;">
                Preview Capability ${renderIcon('chevron-right', 'w-3 h-3', 12)}
              </button>
            </div>
          `
            )
            .join('')}
        </div>
      </div>
    </div>
  `;
}

export function attachOverviewEvents() {
  const newSearchBtn = document.getElementById('overview-new-search-btn');
  if (newSearchBtn) {
    newSearchBtn.addEventListener('click', () => {
      store.setDashboardTab('search');
    });
  }

  const emptyStartBtn = document.getElementById('empty-start-search-btn');
  if (emptyStartBtn) {
    emptyStartBtn.addEventListener('click', () => {
      store.setDashboardTab('search');
    });
  }

  const viewHistoryBtn = document.getElementById('overview-view-history-btn');
  if (viewHistoryBtn) {
    viewHistoryBtn.addEventListener('click', () => {
      store.setDashboardTab('history');
    });
  }

  const allHistoryLink = document.getElementById('overview-all-history-link');
  if (allHistoryLink) {
    allHistoryLink.addEventListener('click', () => {
      store.setDashboardTab('history');
    });
  }

  const allSavedLink = document.getElementById('overview-all-saved-link');
  if (allSavedLink) {
    allSavedLink.addEventListener('click', () => {
      store.setDashboardTab('saved');
    });
  }

  const resetQuotaBtn = document.getElementById('overview-reset-quota-btn');
  if (resetQuotaBtn) {
    resetQuotaBtn.addEventListener('click', () => {
      store.resetSearchQuota();
    });
  }

  const upgradeBtn = document.getElementById('overview-upgrade-btn');
  if (upgradeBtn) {
    upgradeBtn.addEventListener('click', () => {
      store.openModal('upgrade');
    });
  }

  // History item buttons
  const openHistoryBtns = document.querySelectorAll('.open-history-btn');
  openHistoryBtns.forEach((btn) => {
    btn.addEventListener('click', (e) => {
      const id = e.currentTarget.getAttribute('data-history-id');
      const item = store.state.searchHistory.find((h) => h.id === id);
      if (item) {
        store.openHistoryItem(item);
      }
    });
  });

  // Saved item details
  const openSavedBtns = document.querySelectorAll('.open-saved-detail-btn');
  openSavedBtns.forEach((btn) => {
    btn.addEventListener('click', (e) => {
      const id = e.currentTarget.getAttribute('data-saved-id');
      const item = store.state.savedResults.find((s) => s.id === id);
      if (item) {
        store.openResultDetail(item);
      }
    });
  });

  // Coming soon cards
  const csCards = document.querySelectorAll('.overview-cs-card');
  csCards.forEach((card) => {
    card.addEventListener('click', (e) => {
      const id = e.currentTarget.getAttribute('data-cs-id');
      const feature = COMING_SOON_FEATURES.find((f) => f.id === id);
      if (feature) {
        store.openModal('comingSoon', feature);
      }
    });
  });
}
