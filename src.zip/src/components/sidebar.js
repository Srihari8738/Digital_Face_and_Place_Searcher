// src/components/sidebar.js
// Application shell sidebar with Main views and Coming Soon feature drawers

import { store } from '../state.js';
import { renderIcon } from '../utils/icons.js';
import { COMING_SOON_FEATURES } from '../data/mockData.js';

export function renderSidebar() {
  const { dashboardTab, user } = store.state;
  const remaining = store.remainingSearches;
  const usagePercent = Math.min(100, Math.round((user.searchesUsed / user.searchesLimit) * 100));

  return `
    <aside class="app-sidebar">
      <div class="sidebar-header">
        <div class="nav-brand" id="sidebar-brand-btn" style="cursor: pointer;">
          <div class="nav-logo-icon" style="width: 34px; height: 34px;">
            ${renderIcon('scan', 'w-4 h-4', 20)}
          </div>
          <div class="nav-brand-text">
            <span style="font-size: 1.05rem;">DIGITAL YOUR</span>
            <span class="nav-brand-sub">Platform MVP</span>
          </div>
        </div>
      </div>

      <div class="sidebar-scroll">
        <!-- Main Navigation -->
        <div>
          <div class="sidebar-group-title">MAIN</div>
          <ul class="sidebar-nav">
            <li>
              <button class="btn sidebar-item-btn ${dashboardTab === 'overview' ? 'active' : ''}" data-tab="overview">
                ${renderIcon('dashboard', 'w-4 h-4', 18)}
                <span>Overview</span>
              </button>
            </li>
            <li>
              <button class="btn sidebar-item-btn ${dashboardTab === 'search' ? 'active' : ''}" data-tab="search">
                ${renderIcon('search', 'w-4 h-4', 18)}
                <span>New Search</span>
                <span class="sidebar-badge" style="background: rgba(59, 130, 246, 0.15); color: var(--primary);">
                  Core
                </span>
              </button>
            </li>
            <li>
              <button class="btn sidebar-item-btn ${dashboardTab === 'history' ? 'active' : ''}" data-tab="history">
                ${renderIcon('history', 'w-4 h-4', 18)}
                <span>Search History</span>
                <span class="sidebar-badge" style="background: var(--bg-tertiary); color: var(--text-muted);">
                  ${store.state.searchHistory.length}
                </span>
              </button>
            </li>
            <li>
              <button class="btn sidebar-item-btn ${dashboardTab === 'saved' ? 'active' : ''}" data-tab="saved">
                ${renderIcon('folder-heart', 'w-4 h-4', 18)}
                <span>Saved Results</span>
                <span class="sidebar-badge" style="background: var(--bg-tertiary); color: var(--text-muted);">
                  ${store.state.savedResults.length}
                </span>
              </button>
            </li>
            <li>
              <button class="btn sidebar-item-btn ${dashboardTab === 'settings' ? 'active' : ''}" data-tab="settings">
                ${renderIcon('settings', 'w-4 h-4', 18)}
                <span>Settings</span>
              </button>
            </li>
          </ul>
        </div>

        <!-- Coming Soon -->
        <div>
          <div class="sidebar-group-title">COMING SOON</div>
          <ul class="sidebar-nav">
            ${COMING_SOON_FEATURES.map(
              (f) => `
              <li>
                <button class="btn sidebar-item-btn coming-soon-btn" data-feature-id="${f.id}">
                  ${renderIcon(getFeatureIcon(f.id), 'w-4 h-4', 18)}
                  <span>${f.title}</span>
                  <span class="sidebar-badge" style="background: rgba(139, 92, 246, 0.12); color: var(--accent-purple); font-size: 0.65rem;">
                    ${f.badge}
                  </span>
                </button>
              </li>
            `
            ).join('')}
          </ul>
        </div>
      </div>

      <!-- Sidebar Footer: Usage Counter -->
      <div class="sidebar-footer">
        <div class="sidebar-usage-card">
          <div style="display: flex; justify-content: space-between; font-size: 0.8rem; font-weight: 600;">
            <span style="color: var(--text-secondary);">Free Searches</span>
            <span style="color: var(--text-primary);">${remaining} of ${user.searchesLimit} left</span>
          </div>
          <div class="usage-bar-track">
            <div class="usage-bar-fill" style="width: ${usagePercent}%;"></div>
          </div>
          <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 6px;">
            <span style="font-size: 0.72rem; color: var(--text-muted);">Evaluation Tier</span>
            <button class="btn btn-ghost btn-sm" id="sidebar-upgrade-btn" style="padding: 2px 6px; font-size: 0.72rem; color: var(--primary); font-weight: 700;">
              Upgrade Pro ${renderIcon('chevron-right', 'w-3 h-3', 12)}
            </button>
          </div>
        </div>

        <button class="btn btn-ghost btn-sm" id="sidebar-back-landing-btn" style="width: 100%; font-size: 0.78rem; color: var(--text-muted); justify-content: center;">
          ${renderIcon('arrow-left', 'w-3 h-3', 12)} Return to Landing Page
        </button>
      </div>
    </aside>
  `;
}

function getFeatureIcon(id) {
  switch (id) {
    case 'cs-digital-identity':
      return 'shield-check';
    case 'cs-ai-assistant':
      return 'sparkles';
    case 'cs-timeline':
      return 'history';
    case 'cs-source-graph':
      return 'layers';
    case 'cs-reports':
      return 'terminal';
    case 'cs-connected-platforms':
      return 'globe';
    default:
      return 'sparkle';
  }
}

export function attachSidebarEvents() {
  const brandBtn = document.getElementById('sidebar-brand-btn');
  if (brandBtn) {
    brandBtn.addEventListener('click', () => {
      store.setDashboardTab('overview');
    });
  }

  const tabBtns = document.querySelectorAll('.sidebar-item-btn[data-tab]');
  tabBtns.forEach((btn) => {
    btn.addEventListener('click', (e) => {
      const tab = e.currentTarget.getAttribute('data-tab');
      store.setDashboardTab(tab);
      // Close mobile sidebar if open
      const sidebar = document.querySelector('.app-sidebar');
      if (sidebar) sidebar.classList.remove('mobile-open');
    });
  });

  const comingSoonBtns = document.querySelectorAll('.coming-soon-btn');
  comingSoonBtns.forEach((btn) => {
    btn.addEventListener('click', (e) => {
      const featureId = e.currentTarget.getAttribute('data-feature-id');
      const feature = COMING_SOON_FEATURES.find((f) => f.id === featureId);
      if (feature) {
        store.openModal('comingSoon', feature);
      }
    });
  });

  const upgradeBtn = document.getElementById('sidebar-upgrade-btn');
  if (upgradeBtn) {
    upgradeBtn.addEventListener('click', () => {
      store.openModal('upgrade');
    });
  }

  const backLandingBtn = document.getElementById('sidebar-back-landing-btn');
  if (backLandingBtn) {
    backLandingBtn.addEventListener('click', () => {
      store.navigate('landing');
    });
  }
}
