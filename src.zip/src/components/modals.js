// src/components/modals.js
// Specialized modals: Coming Soon Preview, Report Incorrect Match, and Clear History Confirmation

import { store } from '../state.js';
import { renderIcon } from '../utils/icons.js';
import { testGeminiApiKey } from '../services/aiVisionService.js';

export function renderComingSoonModal() {
  const { modalData } = store.state;
  const f = modalData;
  if (!f) return '';

  return `
    <div class="modal-backdrop" id="cs-modal-backdrop">
      <div class="modal-dialog" id="cs-modal-dialog">
        <div class="modal-header">
          <div style="display: flex; align-items: center; gap: 10px;">
            <div class="nav-logo-icon" style="width: 36px; height: 36px; background: linear-gradient(135deg, #8b5cf6, #6366f1);">
              ${renderIcon('sparkles', 'w-4 h-4', 20)}
            </div>
            <div>
              <div style="display: flex; align-items: center; gap: 8px;">
                <h3 style="font-size: 1.2rem;">${f.title}</h3>
                <span class="badge" style="background: rgba(139, 92, 246, 0.15); color: var(--accent-purple);">
                  ${f.badge}
                </span>
              </div>
              <p style="font-size: 0.8rem; color: var(--text-muted);">Platform Architecture Roadmap</p>
            </div>
          </div>
          <button class="btn btn-ghost btn-sm" id="cs-modal-close-btn" aria-label="Close modal">
            ${renderIcon('x', 'w-5 h-5', 20)}
          </button>
        </div>

        <div class="modal-body" style="display: flex; flex-direction: column; gap: 20px;">
          <p style="font-size: 0.95rem; color: var(--text-secondary); line-height: 1.6;">
            ${f.description}
          </p>

          <div style="background: var(--bg-tertiary); border: 1px solid var(--border-subtle); border-radius: var(--radius-md); padding: 18px;">
            <span style="font-size: 0.8rem; font-weight: 700; text-transform: uppercase; color: var(--text-muted); display: block; margin-bottom: 12px;">
              Planned Core Capabilities
            </span>
            <ul style="list-style: none; display: flex; flex-direction: column; gap: 10px;">
              ${(f.highlights || [])
                .map(
                  (h) => `
                <li style="display: flex; align-items: center; gap: 10px; font-size: 0.88rem; color: var(--text-primary);">
                  <span style="color: var(--accent-purple);">${renderIcon('check', 'w-4 h-4', 16)}</span>
                  <span>${h}</span>
                </li>
              `
                )
                .join('')}
            </ul>
          </div>

          <div style="background: rgba(139, 92, 246, 0.08); border: 1px solid rgba(139, 92, 246, 0.25); border-radius: var(--radius-md); padding: 14px; display: flex; align-items: center; justify-content: space-between; gap: 12px; flex-wrap: wrap;">
            <div>
              <div style="font-size: 0.85rem; font-weight: 600; color: var(--text-primary);">Join Developer Preview Queue</div>
              <div style="font-size: 0.75rem; color: var(--text-muted);">Get early access notifications when this module ships.</div>
            </div>
            <button class="btn btn-secondary btn-sm" id="cs-notify-btn" style="border-color: var(--accent-purple); color: var(--accent-purple);">
              ${renderIcon('bookmark', 'w-3.5 h-3.5', 14)} Request Early Access
            </button>
          </div>
        </div>

        <div class="modal-footer">
          <button class="btn btn-primary btn-sm" id="cs-modal-done-btn">
            Close Preview
          </button>
        </div>
      </div>
    </div>
  `;
}

export function renderReportModal() {
  const { modalData } = store.state;
  const res = modalData;
  if (!res) return '';

  return `
    <div class="modal-backdrop" id="report-modal-backdrop">
      <div class="modal-dialog" id="report-modal-dialog">
        <div class="modal-header">
          <div style="display: flex; align-items: center; gap: 10px;">
            <div style="color: var(--accent-rose);">
              ${renderIcon('flag', 'w-5 h-5', 22)}
            </div>
            <div>
              <h3 style="font-size: 1.15rem;">Report Incorrect or Inappropriate Match</h3>
              <p style="font-size: 0.78rem; color: var(--text-muted);">Help maintain algorithmic transparency and index integrity</p>
            </div>
          </div>
          <button class="btn btn-ghost btn-sm" id="report-modal-close-btn">
            ${renderIcon('x', 'w-5 h-5', 20)}
          </button>
        </div>

        <div class="modal-body" style="display: flex; flex-direction: column; gap: 18px;">
          <div style="background: var(--bg-tertiary); padding: 12px; border-radius: var(--radius-md); border: 1px solid var(--border-subtle); display: flex; align-items: center; gap: 12px;">
            <img src="${res.image}" alt="" style="width: 48px; height: 48px; border-radius: 6px; object-fit: cover;" />
            <div style="min-width: 0;">
              <div style="font-size: 0.88rem; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${res.title}</div>
              <div style="font-size: 0.75rem; color: var(--text-muted);">${res.domain} · ${res.similarity}% similarity</div>
            </div>
          </div>

          <div>
            <label style="display: block; font-size: 0.825rem; font-weight: 600; margin-bottom: 6px;">Reason for report</label>
            <select id="report-reason-select" style="width: 100%;">
              <option value="false-positive">Visually unrelated / algorithmic false positive</option>
              <option value="incorrect-context">Misleading page snippet or wrong metadata</option>
              <option value="outdated-source">Page is no longer publicly accessible (broken link)</option>
              <option value="privacy-request">Right to Erasure / Privacy de-indexing request</option>
            </select>
          </div>

          <div>
            <label style="display: block; font-size: 0.825rem; font-weight: 600; margin-bottom: 6px;">Additional details (optional)</label>
            <textarea id="report-notes-textarea" rows="3" placeholder="Provide any additional context or clarification..." style="width: 100%; resize: none;"></textarea>
          </div>
        </div>

        <div class="modal-footer">
          <button class="btn btn-ghost btn-sm" id="report-cancel-btn">Cancel</button>
          <button class="btn btn-primary btn-sm" id="report-submit-btn">
            ${renderIcon('check', 'w-3.5 h-3.5', 14)} Submit Report
          </button>
        </div>
      </div>
    </div>
  `;
}

export function renderClearHistoryModal() {
  return `
    <div class="modal-backdrop" id="clear-modal-backdrop">
      <div class="modal-dialog" id="clear-modal-dialog" style="max-width: 460px;">
        <div class="modal-header">
          <div style="display: flex; align-items: center; gap: 10px; color: var(--accent-rose);">
            ${renderIcon('trash', 'w-5 h-5', 22)}
            <h3 style="font-size: 1.15rem; color: var(--text-primary);">Clear All Search History?</h3>
          </div>
          <button class="btn btn-ghost btn-sm" id="clear-modal-close-btn">
            ${renderIcon('x', 'w-5 h-5', 20)}
          </button>
        </div>

        <div class="modal-body">
          <p style="font-size: 0.9rem; color: var(--text-secondary); line-height: 1.6;">
            This will permanently remove all search history records and image thumbnail caches from your browser's local memory. This action cannot be undone.
          </p>
        </div>

        <div class="modal-footer">
          <button class="btn btn-ghost btn-sm" id="clear-cancel-btn">Cancel</button>
          <button class="btn btn-danger btn-sm" id="clear-confirm-btn">
            ${renderIcon('trash', 'w-3.5 h-3.5', 14)} Permanently Delete All
          </button>
        </div>
      </div>
    </div>
  `;
}

export function attachModalEvents() {
  // Coming Soon modal
  const csClose = document.getElementById('cs-modal-close-btn');
  const csDone = document.getElementById('cs-modal-done-btn');
  if (csClose) csClose.addEventListener('click', () => store.closeModal());
  if (csDone) csDone.addEventListener('click', () => store.closeModal());

  const csBackdrop = document.getElementById('cs-modal-backdrop');
  if (csBackdrop) {
    csBackdrop.addEventListener('click', (e) => {
      if (e.target === csBackdrop) store.closeModal();
    });
  }

  const csNotify = document.getElementById('cs-notify-btn');
  if (csNotify) {
    csNotify.addEventListener('click', () => {
      store.showToast('You are on the preview waitlist. Thank you!', 'success');
      store.closeModal();
    });
  }

  // Report modal
  const repClose = document.getElementById('report-modal-close-btn');
  const repCancel = document.getElementById('report-cancel-btn');
  if (repClose) repClose.addEventListener('click', () => store.closeModal());
  if (repCancel) repCancel.addEventListener('click', () => store.closeModal());

  const repBackdrop = document.getElementById('report-modal-backdrop');
  if (repBackdrop) {
    repBackdrop.addEventListener('click', (e) => {
      if (e.target === repBackdrop) store.closeModal();
    });
  }

  const repSubmit = document.getElementById('report-submit-btn');
  if (repSubmit) {
    repSubmit.addEventListener('click', () => {
      store.showToast('Report received. Thank you for contributing to index integrity.', 'success');
      store.closeModal();
    });
  }

  // Clear history modal
  const clrClose = document.getElementById('clear-modal-close-btn');
  const clrCancel = document.getElementById('clear-cancel-btn');
  if (clrClose) clrClose.addEventListener('click', () => store.closeModal());
  if (clrCancel) clrCancel.addEventListener('click', () => store.closeModal());

  const clrBackdrop = document.getElementById('clear-modal-backdrop');
  if (clrBackdrop) {
    clrBackdrop.addEventListener('click', (e) => {
      if (e.target === clrBackdrop) store.closeModal();
    });
  }

  const clrConfirm = document.getElementById('clear-confirm-btn');
  if (clrConfirm) {
    clrConfirm.addEventListener('click', () => {
      store.clearAllHistory();
    });
  }

  // AI Configuration Modal Events
  const aiClose = document.getElementById('ai-modal-close-btn');
  const aiFooterClose = document.getElementById('modal-ai-close-footer-btn');
  const aiBackdrop = document.getElementById('ai-modal-backdrop');
  if (aiClose) aiClose.addEventListener('click', () => store.closeModal());
  if (aiFooterClose) aiFooterClose.addEventListener('click', () => store.closeModal());
  if (aiBackdrop) {
    aiBackdrop.addEventListener('click', (e) => {
      if (e.target === aiBackdrop) store.closeModal();
    });
  }

  const aiInput = document.getElementById('modal-gemini-input');
  const aiStatus = document.getElementById('modal-gemini-status');
  const aiSaveBtn = document.getElementById('modal-gemini-save-btn');
  const aiTestBtn = document.getElementById('modal-gemini-test-btn');
  const aiClearBtn = document.getElementById('modal-gemini-clear-btn');

  if (aiSaveBtn && aiInput) {
    aiSaveBtn.addEventListener('click', () => {
      store.setGeminiApiKey(aiInput.value);
      store.closeModal();
    });
  }

  if (aiClearBtn) {
    aiClearBtn.addEventListener('click', () => {
      store.setGeminiApiKey('');
      store.closeModal();
    });
  }

  if (aiTestBtn && aiInput && aiStatus) {
    aiTestBtn.addEventListener('click', async () => {
      const key = aiInput.value?.trim();
      if (!key) {
        aiStatus.style.display = 'block';
        aiStatus.style.color = '#ef4444';
        aiStatus.textContent = 'Please enter a Gemini API key to test.';
        return;
      }

      aiStatus.style.display = 'block';
      aiStatus.style.color = 'var(--text-secondary)';
      aiStatus.textContent = 'Testing connection to Google Gemini 2.0 Flash...';

      const result = await testGeminiApiKey(key);
      if (result.ok) {
        aiStatus.style.color = '#10b981';
        aiStatus.textContent = '✓ Connection Verified! Gemini 2.0 Flash is operational.';
      } else {
        aiStatus.style.color = '#ef4444';
        aiStatus.textContent = `✗ Connection failed: ${result.error}`;
      }
    });
  }
}

export function renderAiConfigModal() {
  const { geminiApiKey } = store.state;

  return `
    <div class="modal-backdrop" id="ai-modal-backdrop">
      <div class="modal-dialog" id="ai-modal-dialog" style="max-width: 540px;">
        <div class="modal-header">
          <div style="display: flex; align-items: center; gap: 10px;">
            <div class="nav-logo-icon" style="width: 38px; height: 38px; background: linear-gradient(135deg, #3b82f6, #8b5cf6); box-shadow: 0 4px 12px rgba(99, 102, 241, 0.35);">
              ${renderIcon('sparkles', 'w-5 h-5', 22)}
            </div>
            <div>
              <div style="display: flex; align-items: center; gap: 8px;">
                <h3 style="font-size: 1.2rem; margin: 0;">AI Vision Intelligence Engine</h3>
                <span class="badge ${geminiApiKey ? 'badge-public' : 'badge-demo'}" style="font-size: 0.7rem;">
                  ${geminiApiKey ? 'Gemini 2.0 Active' : 'Neural Core Active'}
                </span>
              </div>
              <p style="font-size: 0.8rem; color: var(--text-muted); margin: 2px 0 0 0;">
                Multimodal Image Recognition & Public Source Intelligence
              </p>
            </div>
          </div>
          <button class="btn btn-ghost btn-sm" id="ai-modal-close-btn" aria-label="Close modal">
            ${renderIcon('x', 'w-5 h-5', 20)}
          </button>
        </div>

        <div class="modal-body" style="display: flex; flex-direction: column; gap: 18px;">
          <!-- Active Status Banner -->
          <div style="background: ${geminiApiKey ? 'rgba(16, 185, 129, 0.08)' : 'rgba(139, 92, 246, 0.08)'}; border: 1px solid ${geminiApiKey ? 'rgba(16, 185, 129, 0.25)' : 'rgba(139, 92, 246, 0.25)'}; border-radius: var(--radius-md); padding: 14px 18px; display: flex; align-items: flex-start; gap: 12px;">
            <div style="color: ${geminiApiKey ? 'var(--accent-emerald)' : 'var(--accent-purple)'}; margin-top: 2px;">
              ${renderIcon(geminiApiKey ? 'check-circle' : 'cpu', 'w-5 h-5', 20)}
            </div>
            <div>
              <h4 style="font-size: 0.9rem; font-weight: 700; color: var(--text-primary); margin: 0 0 3px;">
                ${geminiApiKey ? 'Google Gemini 2.0 Flash Vision Active' : 'Client-Side Neural Vision Engine Active'}
              </h4>
              <p style="font-size: 0.82rem; color: var(--text-secondary); line-height: 1.45; margin: 0;">
                ${geminiApiKey ? 'Custom image uploads are processed with live Google Gemini 2.0 Flash Multimodal inference for entity recognition, public company dossiers, and interactive Q&A.' : 'Running built-in canvas pixel analysis, skin tone clustering, difference hashes, and verified public catalogs. Provide an optional Gemini API key below to enable live Google multimodal vision.'}
              </p>
            </div>
          </div>

          <!-- API Key Input -->
          <div>
            <label style="font-size: 0.82rem; font-weight: 700; color: var(--text-primary); display: block; margin-bottom: 6px;">
              Google Gemini API Key (Optional):
            </label>
            <div style="position: relative;">
              <input 
                type="password" 
                id="modal-gemini-input" 
                placeholder="AIzaSy... (Stored securely in local session)" 
                value="${geminiApiKey || ''}" 
                style="width: 100%; padding: 10px 14px; font-size: 0.88rem; border-radius: var(--radius-md); border: 1px solid var(--border-subtle); background: var(--bg-primary); color: var(--text-primary);"
              />
            </div>
            <div id="modal-gemini-status" style="font-size: 0.78rem; margin-top: 6px; display: none;"></div>
          </div>

          <!-- Test & Action Buttons -->
          <div style="display: flex; gap: 8px; flex-wrap: wrap;">
            <button class="btn btn-secondary btn-sm" id="modal-gemini-test-btn" style="display: flex; align-items: center; gap: 6px;">
              ${renderIcon('sparkles', 'w-3.5 h-3.5', 14)} Test Connection
            </button>
            <button class="btn btn-primary btn-sm" id="modal-gemini-save-btn">
              Save Key
            </button>
            ${geminiApiKey ? `<button class="btn btn-ghost btn-sm" id="modal-gemini-clear-btn" style="color: var(--accent-rose);">Clear Key</button>` : ''}
          </div>

          <!-- Capability Checklist -->
          <div style="background: var(--bg-tertiary); border: 1px solid var(--border-subtle); border-radius: var(--radius-md); padding: 14px 18px;">
            <span style="font-size: 0.75rem; font-weight: 700; color: var(--text-muted); text-transform: uppercase; display: block; margin-bottom: 8px;">
              Active Multimodal AI Modules:
            </span>
            <ul style="list-style: none; display: flex; flex-direction: column; gap: 8px; padding: 0; margin: 0;">
              <li style="display: flex; align-items: center; gap: 8px; font-size: 0.82rem; color: var(--text-primary);">
                <span style="color: var(--accent-emerald);">${renderIcon('check', 'w-3.5 h-3.5', 14)}</span>
                <span>Public Figure Discovery (SpaceX, Tesla, X, xAI, executive footprints)</span>
              </li>
              <li style="display: flex; align-items: center; gap: 8px; font-size: 0.82rem; color: var(--text-primary);">
                <span style="color: var(--accent-emerald);">${renderIcon('check', 'w-3.5 h-3.5', 14)}</span>
                <span>Anime & Media Recognition (Series, Character Roster, Studios, Streams)</span>
              </li>
              <li style="display: flex; align-items: center; gap: 8px; font-size: 0.82rem; color: var(--text-primary);">
                <span style="color: var(--accent-emerald);">${renderIcon('check', 'w-3.5 h-3.5', 14)}</span>
                <span>Photographic Portrait & Face Geometry (Optical Depth, Lighting)</span>
              </li>
              <li style="display: flex; align-items: center; gap: 8px; font-size: 0.82rem; color: var(--text-primary);">
                <span style="color: var(--accent-emerald);">${renderIcon('check', 'w-3.5 h-3.5', 14)}</span>
                <span>Ordinary Individual Privacy Guardrail (Zero personal profile aggregation)</span>
              </li>
              <li style="display: flex; align-items: center; gap: 8px; font-size: 0.82rem; color: var(--text-primary);">
                <span style="color: var(--accent-emerald);">${renderIcon('check', 'w-3.5 h-3.5', 14)}</span>
                <span>Interactive AI Assistant Q&A (Ask factual questions on search results)</span>
              </li>
            </ul>
          </div>
        </div>

        <div class="modal-footer">
          <button class="btn btn-secondary btn-sm" id="modal-ai-close-footer-btn">
            Done
          </button>
        </div>
      </div>
    </div>
  `;
}
