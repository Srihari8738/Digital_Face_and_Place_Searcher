// src/components/upgradeModal.js
// Quota limit reached and tier upgrade modal with ethical commitments and instant test reset

import { store } from '../state.js';
import { renderIcon } from '../utils/icons.js';

export function renderUpgradeModal() {
  const { modalData } = store.state;
  const reason = modalData?.reason || 'You have reached your 3 complimentary public searches limit.';

  return `
    <div class="modal-backdrop" id="upgrade-modal-backdrop">
      <div class="modal-dialog modal-wide" id="upgrade-modal-dialog">
        <!-- Header -->
        <div class="modal-header">
          <div style="display: flex; align-items: center; gap: 10px;">
            <div class="nav-logo-icon" style="width: 36px; height: 36px; background: linear-gradient(135deg, #f59e0b, #d97706);">
              ${renderIcon('zap', 'w-4 h-4', 20)}
            </div>
            <div>
              <h3 style="font-size: 1.25rem;">Upgrade to DIGITAL YOUR Pro</h3>
              <p style="font-size: 0.8rem; color: var(--text-muted);">
                Expand discovery volume while maintaining strict privacy-by-design standards
              </p>
            </div>
          </div>
          <button class="btn btn-ghost btn-sm" id="upgrade-modal-close-btn" aria-label="Close modal">
            ${renderIcon('x', 'w-5 h-5', 20)}
          </button>
        </div>

        <!-- Body -->
        <div class="modal-body" style="display: flex; flex-direction: column; gap: 24px;">
          <!-- Quota Alert Box -->
          <div style="background: rgba(245, 158, 11, 0.1); border: 1px solid rgba(245, 158, 11, 0.3); border-radius: var(--radius-md); padding: 14px 18px; display: flex; align-items: center; justify-content: space-between; gap: 14px; flex-wrap: wrap;">
            <div style="display: flex; align-items: center; gap: 10px;">
              <span style="color: var(--accent-amber);">${renderIcon('alert-circle', 'w-5 h-5', 20)}</span>
              <span style="font-size: 0.88rem; color: var(--text-primary); font-weight: 600;">
                ${reason}
              </span>
            </div>
            <button class="btn btn-secondary btn-sm" id="upgrade-quick-reset-btn" style="background: var(--bg-primary); border-color: var(--accent-amber); color: var(--accent-amber);">
              ${renderIcon('refresh', 'w-3 h-3', 12)} Reset Demo Quota (3 Free)
            </button>
          </div>

          <!-- Tier Comparison Grid -->
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px;">
            <!-- Free Explorer Tier -->
            <div class="glass-card" style="padding: 24px; display: flex; flex-direction: column; opacity: 0.75;">
              <span style="font-size: 0.8rem; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Current Plan</span>
              <h4 style="font-size: 1.3rem; margin: 4px 0 12px;">Free Explorer</h4>
              <div style="font-size: 1.8rem; font-weight: 800; margin-bottom: 16px;">
                $0 <span style="font-size: 0.85rem; font-weight: 500; color: var(--text-muted);">/ lifetime</span>
              </div>
              <ul class="pricing-features" style="font-size: 0.85rem;">
                <li>${renderIcon('check', 'w-3.5 h-3.5', 14)} 3 complimentary searches</li>
                <li>${renderIcon('check', 'w-3.5 h-3.5', 14)} Standard bounding box detection</li>
                <li>${renderIcon('check', 'w-3.5 h-3.5', 14)} Basic public web sources</li>
              </ul>
              <div style="font-size: 0.8rem; color: var(--accent-rose); font-weight: 600; text-align: center; margin-top: auto;">
                Quota Fully Consumed
              </div>
            </div>

            <!-- Pro Researcher Tier -->
            <div class="glass-card" style="padding: 24px; display: flex; flex-direction: column; border-color: var(--primary); box-shadow: 0 0 25px rgba(59, 130, 246, 0.25);">
              <span class="badge badge-public" style="align-self: flex-start; margin-bottom: 6px;">Recommended</span>
              <h4 style="font-size: 1.3rem; margin: 4px 0 12px;">Researcher Pro</h4>
              <div style="font-size: 1.8rem; font-weight: 800; margin-bottom: 16px; color: var(--primary);">
                $29 <span style="font-size: 0.85rem; font-weight: 500; color: var(--text-muted);">/ month</span>
              </div>
              <ul class="pricing-features" style="font-size: 0.85rem;">
                <li>${renderIcon('check', 'w-3.5 h-3.5', 14)} <strong>Unlimited</strong> public web searches</li>
                <li>${renderIcon('check', 'w-3.5 h-3.5', 14)} Priority queue & sub-second hashing</li>
                <li>${renderIcon('check', 'w-3.5 h-3.5', 14)} Unlimited saved collections & tags</li>
                <li>${renderIcon('check', 'w-3.5 h-3.5', 14)} CSV & JSON dossier export</li>
                <li>${renderIcon('check', 'w-3.5 h-3.5', 14)} High-resolution zoom inspection</li>
              </ul>
              <button class="btn btn-primary" id="upgrade-confirm-pro-btn" style="margin-top: auto; padding: 12px;">
                ${renderIcon('zap', 'w-4 h-4', 16)} Upgrade Now
              </button>
            </div>
          </div>

          <!-- Ethical Guarantee -->
          <div style="border-top: 1px solid var(--border-subtle); padding-top: 16px; display: flex; align-items: center; gap: 12px; font-size: 0.78rem; color: var(--text-muted);">
            <div style="color: var(--accent-emerald);">
              ${renderIcon('shield-check', 'w-4 h-4', 16)}
            </div>
            <span>
              All plans operate under our strict Responsible Use framework. DIGITAL YOUR does not sell surveillance access or scrape private accounts at any tier.
            </span>
          </div>
        </div>
      </div>
    </div>
  `;
}

export function attachUpgradeEvents() {
  const closeBtn = document.getElementById('upgrade-modal-close-btn');
  if (closeBtn) closeBtn.addEventListener('click', () => store.closeModal());

  const backdrop = document.getElementById('upgrade-modal-backdrop');
  if (backdrop) {
    backdrop.addEventListener('click', (e) => {
      if (e.target === backdrop) store.closeModal();
    });
  }

  const quickResetBtn = document.getElementById('upgrade-quick-reset-btn');
  if (quickResetBtn) {
    quickResetBtn.addEventListener('click', () => {
      store.resetSearchQuota();
      store.closeModal();
    });
  }

  const confirmProBtn = document.getElementById('upgrade-confirm-pro-btn');
  if (confirmProBtn) {
    confirmProBtn.addEventListener('click', () => {
      store.state.user.plan = 'Researcher Pro';
      store.state.user.searchesLimit = 999;
      store.state.user.searchesUsed = 0;
      store.showToast('Upgraded to Researcher Pro! Enjoy unlimited public searches.', 'success');
      store.closeModal();
    });
  }
}
