// src/components/heroAiVision.js
// Sophisticated Computer-Vision Hero Interface & Floating Analysis Card

import { renderIcon } from '../utils/icons.js';

export function renderHeroAiVision() {
  return `
    <div class="dy-hero-ai-stage" id="dy-hero-ai-stage">
      <div class="dy-vision-frame" id="dy-vision-frame">
        <!-- Fictional High-Res Portrait -->
        <img 
          src="/demo/alex_carter.jpg" 
          alt="Alex Carter - Fictional AI Analysis Subject" 
          class="dy-vision-portrait" 
          id="dy-vision-portrait"
        />

        <!-- Computer Vision Overlay Layers -->
        <div class="dy-vision-cv-layer">
          <!-- Laser Scanning Light Beam -->
          <div class="dy-cv-scanline"></div>

          <!-- Bounding Box -->
          <div class="dy-cv-bounding-box" style="top: 14%; left: 33%; width: 34%; height: 38%;">
            <span class="dy-cv-corner tl"></span>
            <span class="dy-cv-corner tr"></span>
            <span class="dy-cv-corner bl"></span>
            <span class="dy-cv-corner br"></span>
            
            <div style="position: absolute; top: -20px; left: 0; background: rgba(79, 70, 229, 0.9); backdrop-filter: blur(8px); color: #fff; font-size: 0.62rem; font-family: 'JetBrains Mono', monospace; padding: 2px 7px; border-radius: 4px; font-weight: 600; letter-spacing: 0.04em;">
              SUBJECT_01 [CONF: 96.4%]
            </div>
          </div>

          <!-- Eye Tracking Crosshairs -->
          <div class="dy-cv-eye-target" style="top: 25.5%; left: 44.5%;" title="Left Ocular Tracker"></div>
          <div class="dy-cv-eye-target" style="top: 25%; left: 54.5%;" title="Right Ocular Tracker"></div>

          <!-- Subtle Mathematical Facial Mesh & 68 Landmark Points -->
          <svg class="dy-cv-mesh-svg" viewBox="0 0 540 567" fill="none" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <filter id="meshGlow" x="-20%" y="-20%" width="140%" height="140%">
                <feGaussianBlur stdDeviation="1.5" result="blur" />
                <feMerge>
                  <feMergeNode in="blur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
            </defs>

            <!-- Triangular Mesh Lines across Facial Geometry -->
            <g stroke="rgba(99, 102, 241, 0.28)" stroke-width="0.8" stroke-dasharray="2 2">
              <!-- Forehead & Eyebrows to Nose Bridge -->
              <path d="M 215 130 L 250 142 L 270 144 L 290 142 L 325 130" />
              <path d="M 230 144 L 270 170 L 310 144" />
              <!-- Eye Sockets -->
              <polygon points="230,144 255,140 262,148 245,152 230,144" fill="rgba(6, 182, 212, 0.03)" />
              <polygon points="278,148 285,140 310,144 300,152 278,148" fill="rgba(6, 182, 212, 0.03)" />
              <!-- Nose Bridge & Tip -->
              <path d="M 270 144 L 270 185 L 260 195 L 270 198 L 280 195 L 270 185" />
              <path d="M 255 188 L 260 195 L 270 198 L 280 195 L 285 188" />
              <!-- Cheeks & Zygomatic Arches -->
              <path d="M 215 160 L 255 188 L 245 220 L 210 200 Z" />
              <path d="M 325 160 L 285 188 L 295 220 L 330 200 Z" />
              <!-- Mouth & Lips -->
              <polygon points="252,216 270,212 288,216 280,226 270,228 260,226" fill="rgba(124, 58, 237, 0.04)" stroke="rgba(124, 58, 237, 0.4)" stroke-width="0.9" />
              <line x1="252" y1="216" x2="288" y2="216" stroke="rgba(124, 58, 237, 0.5)" />
              <!-- Jawline & Chin Contour -->
              <path d="M 210 175 L 215 210 L 230 242 L 252 265 L 270 270 L 288 265 L 310 242 L 325 210 L 330 175" />
              <path d="M 260 226 L 270 270 L 280 226" />
            </g>

            <!-- 68 Key Landmark Vector Nodes -->
            <g fill="#06b6d4" filter="url(#meshGlow)">
              <!-- Eyebrows -->
              <circle cx="218" cy="132" r="2.2" />
              <circle cx="232" cy="130" r="2.2" />
              <circle cx="248" cy="134" r="2.2" />
              <circle cx="260" cy="142" r="2.2" />
              <circle cx="280" cy="142" r="2.2" />
              <circle cx="292" cy="134" r="2.2" />
              <circle cx="308" cy="130" r="2.2" />
              <circle cx="322" cy="132" r="2.2" />

              <!-- Eyes Contour & Pupils -->
              <circle cx="230" cy="144" r="2" />
              <circle cx="245" cy="142" r="2.8" fill="#4f46e5" />
              <circle cx="258" cy="146" r="2" />
              <circle cx="245" cy="151" r="2" />
              <circle cx="282" cy="146" r="2" />
              <circle cx="295" cy="142" r="2.8" fill="#4f46e5" />
              <circle cx="310" cy="144" r="2" />
              <circle cx="295" cy="151" r="2" />

              <!-- Nose -->
              <circle cx="270" cy="155" r="2" />
              <circle cx="270" cy="170" r="2" />
              <circle cx="270" cy="185" r="2.4" />
              <circle cx="260" cy="195" r="2" />
              <circle cx="270" cy="198" r="2.6" fill="#7c3aed" />
              <circle cx="280" cy="195" r="2" />

              <!-- Lips -->
              <circle cx="252" cy="216" r="2" />
              <circle cx="262" cy="213" r="2" />
              <circle cx="270" cy="212" r="2.2" />
              <circle cx="278" cy="213" r="2" />
              <circle cx="288" cy="216" r="2" />
              <circle cx="280" cy="226" r="2" />
              <circle cx="270" cy="228" r="2.2" />
              <circle cx="260" cy="226" r="2" />

              <!-- Chin & Jaw -->
              <circle cx="210" cy="180" r="2" />
              <circle cx="216" cy="210" r="2" />
              <circle cx="230" cy="242" r="2" />
              <circle cx="250" cy="264" r="2.4" />
              <circle cx="270" cy="270" r="3" fill="#4f46e5" />
              <circle cx="290" cy="264" r="2.4" />
              <circle cx="310" cy="242" r="2" />
              <circle cx="324" cy="210" r="2" />
              <circle cx="330" cy="180" r="2" />
            </g>
          </svg>

          <!-- Floating Data Particles (Subtle Motion) -->
          <div class="dy-floating-particles-wrap" id="dy-particles-wrap">
            <span class="dy-micro-particle" style="top: 18%; left: 15%; animation: dyParticleFloat 5s infinite ease-in-out;"></span>
            <span class="dy-micro-particle" style="top: 28%; right: 18%; animation: dyParticleFloat 6.2s infinite ease-in-out 1s;"></span>
            <span class="dy-micro-particle" style="bottom: 30%; left: 22%; animation: dyParticleFloat 4.8s infinite ease-in-out 0.5s;"></span>
            <span class="dy-micro-particle" style="top: 65%; right: 12%; animation: dyParticleFloat 7s infinite ease-in-out 2s;"></span>
            <span class="dy-micro-particle" style="bottom: 15%; right: 28%; animation: dyParticleFloat 5.5s infinite ease-in-out 1.5s;"></span>
          </div>

          <!-- Bottom HUD Readout -->
          <div class="dy-cv-coords-hud">
            <div class="dy-cv-hud-left">
              <span class="dy-cv-hud-pulse"></span>
              <span>LIVE RECOGNITION MATRIX</span>
            </div>
            <div style="display: flex; gap: 14px; opacity: 0.85;">
              <span>X: 421.4</span>
              <span>Y: 298.1</span>
              <span style="color: #6ee7b7;">CONF: 96.4%</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Floating AI Analysis Card Beside Portrait -->
      <div class="dy-floating-analysis-card" id="dy-analysis-card">
        <div class="dy-card-header-row">
          <span class="dy-card-title">AI Analysis</span>
          <div class="dy-status-pill" id="dy-hero-status-pill">
            <span class="dy-dot"></span>
            <span id="dy-status-text">Identity detected</span>
          </div>
        </div>

        <div class="dy-card-profile">
          <div>
            <div class="dy-card-subject-name">Alex Carter</div>
            <div class="dy-card-subject-role">Software Engineer</div>
          </div>

          <!-- Confidence Meter -->
          <div class="dy-confidence-bar-wrap">
            <div class="dy-confidence-meta">
              <span>Confidence</span>
              <span style="font-weight: 700; color: var(--dy-indigo);">96%</span>
            </div>
            <div class="dy-confidence-track">
              <div class="dy-confidence-fill"></div>
            </div>
          </div>

          <div class="dy-card-field-row">
            <span class="dy-card-field-label">Known For</span>
            <span class="dy-card-field-value">Open-source contributor & AI tooling</span>
          </div>

          <div class="dy-card-field-row">
            <span class="dy-card-field-label">Public Information</span>
            <div class="dy-card-sources-list">
              <span class="dy-source-pill">GitHub</span>
              <span class="dy-source-pill">ArXiv</span>
              <span class="dy-source-pill">TechCrunch</span>
              <span class="dy-source-pill">OpenWeb</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `;
}

export function attachHeroAiVisionEvents() {
  const stage = document.getElementById('dy-hero-ai-stage');
  const frame = document.getElementById('dy-vision-frame');
  const card = document.getElementById('dy-analysis-card');

  if (!stage || !frame) return;

  // Gentle physics-based mouse parallax (shifts 4-8px)
  stage.addEventListener('mousemove', (e) => {
    const rect = stage.getBoundingClientRect();
    const x = e.clientX - rect.left - rect.width / 2;
    const y = e.clientY - rect.top - rect.height / 2;

    const tiltX = (y / (rect.height / 2)) * -4;
    const tiltY = (x / (rect.width / 2)) * 4;

    frame.style.transform = `rotateX(${tiltX}deg) rotateY(${tiltY}deg) translateZ(8px)`;

    if (card) {
      const cardShiftX = (x / (rect.width / 2)) * -8;
      const cardShiftY = (y / (rect.height / 2)) * -6;
      card.style.transform = `translate(${cardShiftX}px, ${cardShiftY}px)`;
    }
  });

  stage.addEventListener('mouseleave', () => {
    frame.style.transform = 'rotateX(0deg) rotateY(0deg) translateZ(0px)';
    if (card) {
      card.style.transform = 'translate(0px, 0px)';
    }
  });

  // Cycle status indicator smoothly for realistic AI process feel
  const statusPill = document.getElementById('dy-hero-status-pill');
  const statusText = document.getElementById('dy-status-text');
  if (statusPill && statusText) {
    const statuses = [
      { text: 'Scanning...', color: '#6366f1', bg: 'rgba(99, 102, 241, 0.1)' },
      { text: 'Face detected', color: '#06b6d4', bg: 'rgba(6, 182, 212, 0.1)' },
      { text: 'Analyzing...', color: '#8b5cf6', bg: 'rgba(139, 92, 246, 0.1)' },
      { text: 'Identity detected', color: '#10b981', bg: 'rgba(16, 185, 129, 0.1)' }
    ];
    let idx = 3;
    setInterval(() => {
      idx = (idx + 1) % statuses.length;
      statusText.textContent = statuses[idx].text;
      statusPill.style.color = statuses[idx].color;
      statusPill.style.background = statuses[idx].bg;
      const dot = statusPill.querySelector('.dy-dot');
      if (dot) dot.style.background = statuses[idx].color;
    }, 4200);
  }
}
