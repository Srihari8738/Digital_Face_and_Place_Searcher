// src/components/landingPage.js
// Master AI SaaS Landing Page for DIGITAL YOUR
// Art Direction: Apple + Linear + Perplexity + Stripe

import { store } from '../state.js';
import { renderIcon } from '../utils/icons.js';
import { renderHeroAiVision, attachHeroAiVisionEvents } from './heroAiVision.js';
import { renderPlaceRecognitionCard, attachPlaceEvents } from './placeRecognitionCard.js';

export function renderLandingPage() {
  return `
    <div class="landing-view" id="home">
      <!-- Ambient Lighting Atmosphere -->
      <div class="dy-ambient-light-1"></div>
      <div class="dy-ambient-light-2"></div>

      <!-- ====================================================================
           1. HERO SECTION
           ==================================================================== -->
      <section class="dy-master-hero">
        <div class="dy-hero-container">
          <!-- Left Column: Copy & Actions -->
          <div class="dy-hero-content">
            <div class="dy-hero-eyebrow">
              <span class="dy-eyebrow-dot"></span>
              <span>AI-POWERED PEOPLE & PLACE RECOGNITION</span>
            </div>

            <h1 class="dy-hero-headline">
              Discover Who You're <span class="dy-gradient-text">Looking At.</span>
            </h1>

            <p class="dy-hero-subtext">
              Upload a photo. Let AI reveal the story.
            </p>

            <div class="dy-hero-actions">
              <button class="dy-btn-primary-cta" id="hero-primary-cta">
                <span>Analyze Image</span>
                <span class="dy-cta-arrow">→</span>
              </button>
              <a href="#how-it-works" class="dy-btn-secondary-cta" id="hero-secondary-demo">
                <span>Explore Demo</span>
              </a>
            </div>

            <!-- 3 Subtle Minimal Capabilities -->
            <div class="dy-hero-capabilities">
              <div class="dy-capability-item">
                <span class="dy-capability-indicator"></span>
                <span>People & Faces</span>
              </div>
              <div class="dy-capability-item">
                <span class="dy-capability-indicator"></span>
                <span>Places & Landmarks</span>
              </div>
              <div class="dy-capability-item">
                <span class="dy-capability-indicator"></span>
                <span>Public Information</span>
              </div>
            </div>
          </div>

          <!-- Right Column: Sophisticated AI Vision System -->
          <div class="dy-hero-right-col">
            ${renderHeroAiVision()}
          </div>
        </div>
      </section>

      <!-- ====================================================================
           2. SECTION: HOW IT WORKS
           ==================================================================== -->
      <section class="dy-section dy-section-warm" id="how-it-works">
        <div class="dy-section-container">
          <div class="dy-section-header-center">
            <span class="dy-section-eyebrow">HOW IT WORKS</span>
            <h2 class="dy-section-title">Powerful AI. Real Insights.</h2>
            <p class="dy-section-desc">
              Our AI models analyze images and connect the dots from publicly available information to help you understand people and places.
            </p>
          </div>

          <!-- 3 Large Cards Grid with Interactive Visualizations -->
          <div class="dy-how-grid">
            <!-- 01 IDENTIFY -->
            <div class="dy-how-card" id="card-identify">
              <div class="dy-how-card-num">01</div>
              <h3 class="dy-how-card-title">IDENTIFY</h3>
              <p class="dy-how-card-text">Turn an image into meaningful information.</p>
              <div class="dy-how-visual-canvas">
                <!-- Animated Face Mesh Visualization -->
                <svg viewBox="0 0 200 120" style="width: 100%; height: 100%;">
                  <defs>
                    <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stop-color="#4f46e5" stop-opacity="0.8" />
                      <stop offset="100%" stop-color="#06b6d4" stop-opacity="0.8" />
                    </linearGradient>
                  </defs>
                  <polygon points="100,20 130,45 125,85 100,105 75,85 70,45" fill="none" stroke="url(#grad1)" stroke-width="1.2" />
                  <line x1="100" y1="20" x2="100" y2="105" stroke="rgba(79, 70, 229, 0.3)" stroke-dasharray="2 2" />
                  <line x1="70" y1="45" x2="130" y2="45" stroke="rgba(79, 70, 229, 0.3)" stroke-dasharray="2 2" />
                  <line x1="75" y1="85" x2="125" y2="85" stroke="rgba(79, 70, 229, 0.3)" stroke-dasharray="2 2" />
                  <circle cx="100" cy="20" r="3" fill="#4f46e5" />
                  <circle cx="130" cy="45" r="3" fill="#06b6d4" />
                  <circle cx="125" cy="85" r="3" fill="#7c3aed" />
                  <circle cx="100" cy="105" r="3.5" fill="#4f46e5" />
                  <circle cx="75" cy="85" r="3" fill="#7c3aed" />
                  <circle cx="70" cy="45" r="3" fill="#06b6d4" />
                  <circle cx="100" cy="60" r="2.5" fill="#10b981" />
                </svg>
              </div>
            </div>

            <!-- 02 UNDERSTAND -->
            <div class="dy-how-card" id="card-understand">
              <div class="dy-how-card-num">02</div>
              <h3 class="dy-how-card-title">UNDERSTAND</h3>
              <p class="dy-how-card-text">Go beyond recognition with contextual AI.</p>
              <div class="dy-how-visual-canvas">
                <!-- Dynamically Connecting Information Cards / Knowledge Graph -->
                <svg viewBox="0 0 200 120" style="width: 100%; height: 100%;">
                  <g stroke="rgba(79, 70, 229, 0.25)" stroke-width="1.2">
                    <line x1="60" y1="40" x2="100" y2="60" />
                    <line x1="100" y1="60" x2="140" y2="40" />
                    <line x1="100" y1="60" x2="100" y2="95" />
                  </g>
                  <!-- Node Pills -->
                  <rect x="35" y="28" width="50" height="24" rx="6" fill="#ffffff" stroke="rgba(15,23,42,0.1)" />
                  <text x="60" y="44" font-size="8" font-family="system-ui" fill="#4f46e5" font-weight="700" text-anchor="middle">ENTITY</text>

                  <rect x="115" y="28" width="50" height="24" rx="6" fill="#ffffff" stroke="rgba(15,23,42,0.1)" />
                  <text x="140" y="44" font-size="8" font-family="system-ui" fill="#06b6d4" font-weight="700" text-anchor="middle">SOURCE</text>

                  <rect x="75" y="83" width="50" height="24" rx="6" fill="#ffffff" stroke="rgba(15,23,42,0.1)" />
                  <text x="100" y="99" font-size="8" font-family="system-ui" fill="#7c3aed" font-weight="700" text-anchor="middle">CONTEXT</text>

                  <!-- Central Hub -->
                  <circle cx="100" cy="60" r="5" fill="#4f46e5" />
                  <circle cx="100" cy="60" r="8" fill="none" stroke="#4f46e5" stroke-opacity="0.4" />
                </svg>
              </div>
            </div>

            <!-- 03 EXPLORE -->
            <div class="dy-how-card" id="card-explore">
              <div class="dy-how-card-num">03</div>
              <h3 class="dy-how-card-title">EXPLORE</h3>
              <p class="dy-how-card-text">Discover people, places and stories.</p>
              <div class="dy-how-visual-canvas">
                <!-- Location Points Appearing on World Map -->
                <svg viewBox="0 0 200 120" style="width: 100%; height: 100%;">
                  <!-- Simplified Geographic Grid lines -->
                  <path d="M 20 60 Q 100 30 180 60" fill="none" stroke="rgba(79, 70, 229, 0.15)" stroke-width="1" />
                  <path d="M 20 60 Q 100 90 180 60" fill="none" stroke="rgba(79, 70, 229, 0.15)" stroke-width="1" />
                  <circle cx="100" cy="60" r="38" fill="none" stroke="rgba(79, 70, 229, 0.12)" stroke-dasharray="2 2" />

                  <!-- Pulsing Location Markers -->
                  <circle cx="75" cy="52" r="3.5" fill="#ef4444" />
                  <circle cx="75" cy="52" r="8" fill="none" stroke="#ef4444" stroke-opacity="0.3" />

                  <circle cx="125" cy="48" r="3.5" fill="#4f46e5" />
                  <circle cx="125" cy="48" r="8" fill="none" stroke="#4f46e5" stroke-opacity="0.3" />

                  <circle cx="100" cy="74" r="3" fill="#10b981" />
                </svg>
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- ====================================================================
           3. SECTION: PEOPLE RECOGNITION DEMO
           ==================================================================== -->
      <section class="dy-section" id="people">
        <div class="dy-section-container">
          <div class="dy-section-header-center">
            <span class="dy-section-eyebrow">PEOPLE INTELLIGENCE</span>
            <h2 class="dy-section-title">Contextual Recognition of Public Figures</h2>
            <p class="dy-section-desc">
              Understand the background, work, and public footprint of creators, engineers, and historical figures from open sources.
            </p>
          </div>

          <div class="dy-people-stage">
            <!-- Left: Fictional Portrait -->
            <div class="dy-people-preview-wrap">
              <img src="/demo/alex_carter.jpg" alt="Alex Carter - Software Engineer" class="dy-people-preview-img" />
              <div style="position: absolute; bottom: 16px; left: 16px; background: rgba(11, 17, 32, 0.8); backdrop-filter: blur(12px); color: #fff; padding: 6px 14px; border-radius: 999px; font-size: 0.76rem; font-weight: 600; display: flex; align-items: center; gap: 8px;">
                <span style="width: 6px; height: 6px; border-radius: 50%; background: #10b981; box-shadow: 0 0 6px #10b981;"></span>
                <span>Fictional Subject · AI Evaluation Sample</span>
              </div>
            </div>

            <!-- Right: Information Panel & Processing Pipeline -->
            <div class="dy-people-info-panel">
              <!-- Timeline-like AI Processing Indicator: Image → Face → Context → Information -->
              <div class="dy-people-pipeline-bar">
                <div class="dy-pipeline-step active">
                  <span class="dy-pipeline-step-dot"></span>
                  <span>Image</span>
                </div>
                <span class="dy-pipeline-arrow">→</span>
                <div class="dy-pipeline-step active">
                  <span class="dy-pipeline-step-dot"></span>
                  <span>Face</span>
                </div>
                <span class="dy-pipeline-arrow">→</span>
                <div class="dy-pipeline-step active">
                  <span class="dy-pipeline-step-dot"></span>
                  <span>Context</span>
                </div>
                <span class="dy-pipeline-arrow">→</span>
                <div class="dy-pipeline-step active">
                  <span class="dy-pipeline-step-dot"></span>
                  <span>Information</span>
                </div>
              </div>

              <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px;">
                <div class="dy-status-pill">
                  <span class="dy-dot"></span>
                  <span>Identity detected</span>
                </div>
                <span style="font-size: 0.78rem; font-family: 'JetBrains Mono', monospace; color: var(--dy-indigo); font-weight: 700;">
                  Confidence: 96%
                </span>
              </div>

              <h3 style="font-size: 2.1rem; font-weight: 800; letter-spacing: -0.03em; color: var(--dy-text-primary); margin-bottom: 4px;">
                Alex Carter
              </h3>
              <p style="font-size: 1rem; color: var(--dy-indigo); font-weight: 600; margin-bottom: 24px;">
                Software Engineer & Open-Source AI Contributor
              </p>

              <div style="display: flex; flex-direction: column; gap: 14px; margin-bottom: 28px;">
                <div class="dy-card-field-row">
                  <span class="dy-card-field-label">Known For</span>
                  <span class="dy-card-field-value">Pioneering open-source AI tooling, multimodal computer vision architectures, and developer frameworks.</span>
                </div>

                <div class="dy-card-field-row">
                  <span class="dy-card-field-label">Public Footprint</span>
                  <span class="dy-card-field-value">Over 40 public GitHub repositories, speaker at Open Source Summit, and featured technical author.</span>
                </div>

                <div class="dy-card-field-row">
                  <span class="dy-card-field-label">Verified Public Citations</span>
                  <div class="dy-card-sources-list">
                    <span class="dy-source-pill">github.com/alexcarter</span>
                    <span class="dy-source-pill">arxiv.org/abs/2401</span>
                    <span class="dy-source-pill">techcrunch.com/article</span>
                  </div>
                </div>
              </div>

              <button class="dy-btn-primary-cta" id="dy-people-try-btn" style="padding: 12px 26px; font-size: 0.95rem;">
                <span>Analyze Any Person / Photo</span>
                <span class="dy-cta-arrow">→</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      <!-- ====================================================================
           4. SECTION: PLACE RECOGNITION DEMO
           ==================================================================== -->
      <section class="dy-section dy-section-warm" id="places">
        <div class="dy-section-container">
          <div class="dy-section-header-center">
            <span class="dy-section-eyebrow">DESTINATION INTELLIGENCE</span>
            <h2 class="dy-section-title">Recognize the world around you.</h2>
            <p class="dy-section-desc">
              Identify geographic landmarks, historical architecture, and natural wonders with deep contextual insights.
            </p>
          </div>

          ${renderPlaceRecognitionCard()}
        </div>
      </section>

      <!-- ====================================================================
           5. SECTION: AI PROCESSING FLOW VISUALIZATION
           ==================================================================== -->
      <section class="dy-section" id="technology">
        <div class="dy-section-container">
          <div class="dy-section-header-center">
            <span class="dy-section-eyebrow">SYSTEM ARCHITECTURE</span>
            <h2 class="dy-section-title">The Multimodal Intelligence Pipeline</h2>
            <p class="dy-section-desc">
              A high-precision sequence transforming raw pixels into actionable, verified knowledge.
            </p>
          </div>

          <!-- Flowchart: UPLOAD -> VISION MODEL -> CONTEXT ENGINE -> PUBLIC INFORMATION -> INSIGHT -->
          <div class="dy-pipeline-flow-container">
            <!-- Node 1: UPLOAD -->
            <div class="dy-flow-node">
              <div class="dy-flow-node-icon">
                ${renderIcon('upload', 'w-6 h-6', 24)}
              </div>
              <span class="dy-flow-node-label">Upload</span>
              <span class="dy-flow-node-sub">Secure Ingestion</span>
            </div>

            <div class="dy-flow-connector">
              <span class="dy-flow-particle" style="animation-delay: 0s;"></span>
            </div>

            <!-- Node 2: VISION MODEL -->
            <div class="dy-flow-node">
              <div class="dy-flow-node-icon">
                ${renderIcon('scan', 'w-6 h-6', 24)}
              </div>
              <span class="dy-flow-node-label">Vision Model</span>
              <span class="dy-flow-node-sub">Feature Extraction</span>
            </div>

            <div class="dy-flow-connector">
              <span class="dy-flow-particle" style="animation-delay: 0.6s;"></span>
            </div>

            <!-- Node 3: CONTEXT ENGINE -->
            <div class="dy-flow-node">
              <div class="dy-flow-node-icon">
                ${renderIcon('sparkles', 'w-6 h-6', 24)}
              </div>
              <span class="dy-flow-node-label">Context Engine</span>
              <span class="dy-flow-node-sub">Neural Synthesis</span>
            </div>

            <div class="dy-flow-connector">
              <span class="dy-flow-particle" style="animation-delay: 1.2s;"></span>
            </div>

            <!-- Node 4: PUBLIC INFORMATION -->
            <div class="dy-flow-node">
              <div class="dy-flow-node-icon">
                ${renderIcon('globe', 'w-6 h-6', 24)}
              </div>
              <span class="dy-flow-node-label">Public Sources</span>
              <span class="dy-flow-node-sub">Indexed Web Pages</span>
            </div>

            <div class="dy-flow-connector">
              <span class="dy-flow-particle" style="animation-delay: 1.8s;"></span>
            </div>

            <!-- Node 5: INSIGHT -->
            <div class="dy-flow-node">
              <div class="dy-flow-node-icon" style="background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%); color: #ffffff;">
                ${renderIcon('check-circle', 'w-6 h-6', 24)}
              </div>
              <span class="dy-flow-node-label" style="color: var(--dy-indigo);">Insight</span>
              <span class="dy-flow-node-sub">Actionable Dossier</span>
            </div>
          </div>
        </div>
      </section>

      <!-- ====================================================================
           6. SECTION: TRUST & PRIVACY PILLARS
           ==================================================================== -->
      <section class="dy-section dy-section-warm" id="privacy">
        <div class="dy-section-container">
          <div class="dy-section-header-center">
            <span class="dy-section-eyebrow">ETHICAL INTELLIGENCE</span>
            <h2 class="dy-section-title">Built for useful discovery.</h2>
            <p class="dy-section-desc">
              We uphold uncompromising privacy standards. DIGITAL YOUR is designed for ethical discovery, not surveillance.
            </p>
          </div>

          <div class="dy-trust-grid">
            <!-- Pillar 1 -->
            <div class="dy-trust-card">
              <div class="dy-trust-icon-box">
                ${renderIcon('globe', 'w-5 h-5', 20)}
              </div>
              <h4 class="dy-trust-title">Public information only</h4>
              <p class="dy-trust-desc">
                We search exclusively open, publicly indexed internet sources. We never access private accounts, behind-the-wall social feeds, or credentials.
              </p>
            </div>

            <!-- Pillar 2 -->
            <div class="dy-trust-card">
              <div class="dy-trust-icon-box">
                ${renderIcon('sparkles', 'w-5 h-5', 20)}
              </div>
              <h4 class="dy-trust-title">Transparent AI insights</h4>
              <p class="dy-trust-desc">
                Every result is accompanied by probabilistic confidence ratings and direct citations, allowing you to independently verify all discoveries.
              </p>
            </div>

            <!-- Pillar 3 -->
            <div class="dy-trust-card">
              <div class="dy-trust-icon-box">
                ${renderIcon('shield-check', 'w-5 h-5', 20)}
              </div>
              <h4 class="dy-trust-title">Privacy-conscious design</h4>
              <p class="dy-trust-desc">
                Images are analyzed in ephemeral in-memory sessions. We do not maintain biometric identification tracking databases.
              </p>
            </div>

            <!-- Pillar 4 -->
            <div class="dy-trust-card">
              <div class="dy-trust-icon-box">
                ${renderIcon('book-open', 'w-5 h-5', 20)}
              </div>
              <h4 class="dy-trust-title">Human-readable results</h4>
              <p class="dy-trust-desc">
                Complex visual vectors and semantic correlations are synthesized into clean, concise language designed for human researchers.
              </p>
            </div>
          </div>
        </div>
      </section>

      <!-- ====================================================================
           7. FOOTER
           ==================================================================== -->
      <footer class="dy-footer">
        <div class="dy-footer-top">
          <div class="dy-footer-brand-wrap">
            <div class="dy-nav-brand" style="margin-bottom: 4px;">
              <div class="dy-brand-icon-d">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M6 3h6a6 6 0 0 1 6 6v6a6 6 0 0 1-6 6H6V3z"/>
                  <path d="M12 9v6" stroke="rgba(255,255,255,0.7)" stroke-width="2"/>
                </svg>
              </div>
              <span class="dy-brand-title">DIGITAL YOUR</span>
            </div>
            <p class="dy-footer-tagline">
              See more. Understand more.<br />
              The quiet luxury standard in visual intelligence.
            </p>
          </div>

          <div>
            <h5 class="dy-footer-col-title">Product</h5>
            <ul class="dy-footer-links">
              <li><a href="#how-it-works" class="dy-footer-link">How It Works</a></li>
              <li><a href="#people" class="dy-footer-link">People Recognition</a></li>
              <li><a href="#places" class="dy-footer-link">Place Discovery</a></li>
              <li><a href="#technology" class="dy-footer-link">Vision Engine</a></li>
            </ul>
          </div>

          <div>
            <h5 class="dy-footer-col-title">Technology</h5>
            <ul class="dy-footer-links">
              <li><a href="#technology" class="dy-footer-link">Computer Vision</a></li>
              <li><a href="#technology" class="dy-footer-link">Perceptual Hashing</a></li>
              <li><a href="#technology" class="dy-footer-link">Contextual AI</a></li>
              <li><a href="#technology" class="dy-footer-link">API Integration</a></li>
            </ul>
          </div>

          <div>
            <h5 class="dy-footer-col-title">Privacy & Trust</h5>
            <ul class="dy-footer-links">
              <li><a href="#privacy" class="dy-footer-link">Privacy Architecture</a></li>
              <li><a href="#privacy" class="dy-footer-link">Public Source Policy</a></li>
              <li><a href="#privacy" class="dy-footer-link">Terms of Service</a></li>
              <li><a href="#privacy" class="dy-footer-link">Responsible Disclosure</a></li>
            </ul>
          </div>

          <div>
            <h5 class="dy-footer-col-title">Connect</h5>
            <ul class="dy-footer-links">
              <li><a href="https://twitter.com" target="_blank" rel="noopener" class="dy-footer-link">Twitter / X</a></li>
              <li><a href="https://github.com" target="_blank" rel="noopener" class="dy-footer-link">GitHub</a></li>
              <li><a href="https://linkedin.com" target="_blank" rel="noopener" class="dy-footer-link">LinkedIn</a></li>
              <li><a href="mailto:contact@digitalyour.ai" class="dy-footer-link">Contact Team</a></li>
            </ul>
          </div>
        </div>

        <div class="dy-footer-bottom">
          <span>&copy; 2026 DIGITAL YOUR Technologies, Inc. All rights reserved.</span>
          <span>Designed with Apple-level refinement & Linear-level UI.</span>
        </div>
      </footer>
    </div>
  `;
}

export function attachLandingEvents() {
  // Attach Hero AI Vision Events (mouse parallax & live status cycling)
  attachHeroAiVisionEvents();

  // Attach Place Events
  attachPlaceEvents();

  // Wire Primary CTA to open search/upload flow
  const primaryCta = document.getElementById('hero-primary-cta');
  if (primaryCta) {
    primaryCta.addEventListener('click', () => {
      if (store.state.isAuthenticated) {
        store.navigate('dashboard', 'search');
      } else {
        store.openModal('auth', { nextTab: 'search' });
      }
    });
  }

  // Wire People Section CTA to open search/upload flow
  const peopleTryBtn = document.getElementById('dy-people-try-btn');
  if (peopleTryBtn) {
    peopleTryBtn.addEventListener('click', () => {
      if (store.state.isAuthenticated) {
        store.navigate('dashboard', 'search');
      } else {
        store.openModal('auth', { nextTab: 'search' });
      }
    });
  }
}
